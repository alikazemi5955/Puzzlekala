# Puzzle Kala — Handoff Notes (1.9.4)

## Scope
This is a continuation of the existing project. It is not a greenfield rewrite. As requested, deployment/host testing is deferred until the project is moved to the host. No claim is made that build or automated tests have passed.

## New in 1.9.4
- Order creation can use a saved address-book entry by `addressId`; the server verifies that it belongs to the authenticated customer and stores an immutable snapshot. If no one-off address is supplied, the account default address (or first saved address) is used.
- Admin cancellation requires a reason, including cancellation via the general order update endpoint.
- General order updates validate status values and cannot alter immutable identity, item, address, pricing, payment, refund, or archive fields.
- Added a controlled manual financial reconciliation endpoint: `POST /api/admin/orders/:id/financial-action`. It requires an explicit `confirmed: true` and a reason. Actions are `confirm_manual_payment` and `confirm_manual_refund`; the actor, note, reference and timestamp are stored and audit logged. This is an administrative record of a real manual action, not a gateway integration.
- Added `X-Frame-Options: DENY` and `Cache-Control: no-store` for API responses.
- Registration validates the Iranian national-code checksum, rejects duplicate email addresses, and does not mark the phone as verified.
- Login identifier matching no longer accepts only a partial phone suffix; phone identifiers must match the normalized last ten digits.
- Bulk sync protects the saved order address snapshot from being overwritten.

## Existing 1.9.3 additions retained
- Server-side order quote and order total calculation, coupon eligibility and usage-limit checks.
- Customer address book endpoints and return-request endpoints.
- Existing order audit events and archive instead of hard deletion.
- Product stock validation and prevention of auto-discovered products becoming purchasable before review.

## Known incomplete integrations / launch blockers
- SMS OTP provider and safe identity linking are not implemented. `phoneVerified` remains false until actual verification.
- No real payment gateway callback/signature verification is connected. Browser return is not payment confirmation.
- Manual financial action route only records an explicitly confirmed real-world manual action by an administrator; it must not be used as a substitute for a verified gateway callback.
- The checkout UI is served from a legacy bundled asset; the original editable source for that bundle is not present in the repository. The new quote endpoint must be wired into the editable checkout source or the legacy UI before production.
- Supplier integrations still depend on real supplier access methods and credentials. Sync errors must remain distinct from confirmed stock-outs, and last valid supplier values must be retained.
- Shipping tariffs and eligible shipping methods must be configured from real business rules; no unverified delivery promises should be displayed.
- Data remains JSON-file based for compatibility. This does not provide multi-process transaction safety or a substitute for durable database and backup/restore design.
- Role-based staff access, deduplicated SMS notifications, full return/refund UI, and complete requirement-by-requirement acceptance coverage remain incomplete.

## Test status
Per the user's request, do not perform host/deployment tests at this stage. This archive is a code-completion package, not a test report. Verify installation/build and end-to-end flows after deployment to the chosen host, before accepting real customer orders or payments.
