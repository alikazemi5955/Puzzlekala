// دریافت، بررسی و ذخیره عکس‌های محصول (زمینه سفید، حداقل کیفیت، حذف تکراری). sharp اختیاری است.
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

export interface Candidate { url: string; source: string; rank: number }
export interface Analyzed extends Candidate { buf: Buffer; format: 'jpeg' | 'png' | 'webp' | 'gif' | 'avif'; w: number; h: number; whiteRatio: number | null; hash: string | null }
export interface ImageDeps { fetchBuffer?: (url: string) => Promise<Buffer | null>; sharp?: any | null }

function rasterFormat(buf: Buffer): Analyzed['format'] | null {
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpeg';
  if (buf.length >= 8 && buf.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) return 'png';
  if (buf.length >= 12 && buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return 'webp';
  if (buf.length >= 6 && ['GIF87a', 'GIF89a'].includes(buf.toString('ascii', 0, 6))) return 'gif';
  if (buf.length >= 12 && buf.toString('ascii', 4, 8) === 'ftyp' && /avif|avis/.test(buf.toString('ascii', 8, 12))) return 'avif';
  return null;
}

export function isSafeUrl(u: string): boolean {
  try {
    const x = new URL(u);
    if (x.protocol !== 'https:' || x.username || x.password) return false;
    const h = x.hostname.toLowerCase().replace(/^\[|\]$/g, '').replace(/\.$/, '');
    if (!h || h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.local') || h.endsWith('.internal') || h.endsWith('.test')) return false;
    // This fetcher is intentionally limited to public DNS names. IPv6 literals are
    // rejected entirely because checking every special-use IPv6 range correctly is
    // easy to get wrong; supplier/product evidence does not need literal IP URLs.
    if (h.includes(':')) return false;
    if (/^(\d{1,3}\.){3}\d{1,3}$/.test(h)) {
      const octets = h.split('.').map(Number);
      if (octets.some((n) => n < 0 || n > 255)) return false;
      const [a, b] = octets;
      if (a === 0 || a === 10 || a === 127 || a >= 224 || (a === 169 && b === 254) ||
          (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) ||
          (a === 100 && b >= 64 && b <= 127) || (a === 192 && b === 0) ||
          (a === 198 && (b === 18 || b === 19)) || (a === 198 && b === 51) ||
          (a === 203 && b === 0)) return false;
    }
    return true;
  } catch { return false; }
}

export async function defaultFetchBuffer(url: string): Promise<Buffer | null> {
  if (!isSafeUrl(url)) return null;
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 9000);
  try {
    // Never follow redirects here: a public image URL could redirect to a private-network endpoint (SSRF).
    const r = await fetch(url, { signal: ctl.signal, redirect: 'error', headers: { 'User-Agent': 'Mozilla/5.0 PuzzleKalaBot' } });
    const contentType = String(r.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
    if (!r.ok || !['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif'].includes(contentType)) return null;
    // Stream with a hard cap instead of buffering an arbitrarily large response first.
    if (!r.body) return null;
    const reader = r.body.getReader(); const chunks: Uint8Array[] = []; let size = 0;
    try {
      while (true) {
        const { done, value } = await reader.read(); if (done) break;
        size += value.byteLength; if (size > 8e6) { await reader.cancel(); return null; }
        chunks.push(value);
      }
    } finally { reader.releaseLock(); }
    if (size < 4000) return null;
    const buf = Buffer.concat(chunks.map((chunk) => Buffer.from(chunk)));
    return rasterFormat(buf) ? buf : null;
  } catch { return null; } finally { clearTimeout(t); }
}

export async function loadSharp(): Promise<any | null> { try { const name = 'sharp'; const m: any = await import(name); return m.default || m; } catch { return null; } }

export async function analyze(c: Candidate, buf: Buffer, sharp: any | null): Promise<Analyzed | null> {
  const format = rasterFormat(buf);
  if (!format) return null;
  if (!sharp) return { ...c, buf, format, w: 0, h: 0, whiteRatio: null, hash: null };
  try {
    const meta = await sharp(buf).metadata();
    const { data, info } = await sharp(buf).flatten({ background: '#fff' }).resize(32, 32, { fit: 'fill' }).greyscale().raw().toBuffer({ resolveWithObject: true });
    const px = info.width, border: number[] = [];
    for (let i = 0; i < px; i++) { border.push(data[i], data[(px - 1) * px + i], data[i * px], data[i * px + px - 1]); }
    const whiteRatio = border.filter((v) => v >= 238).length / border.length;
    const avg = data.reduce((a: number, v: number) => a + v, 0) / data.length;
    const hash = Array.from(data as Uint8Array).map((v) => (v >= avg ? '1' : '0')).join('');
    return { ...c, buf, format, w: meta.width || 0, h: meta.height || 0, whiteRatio, hash };
  } catch { return null; }
}

const hamming = (a: string, b: string) => { let d = 0; for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) d++; return d; };

/** انتخاب ۴ تا ۶ عکس: فقط زمینه سفید و کیفیت کافی، بدون تکراری؛ کاور = بهترین رتبه (دیجی‌کالا/کسری) */
export function selectImages(list: Analyzed[], opts: { min?: number; max?: number } = {}) {
  const min = opts.min ?? 4, max = opts.max ?? 6, warnings: string[] = [];
  const hasSharp = list.some((x) => x.whiteRatio !== null);
  let ok = list.filter((x) => (!hasSharp || (x.whiteRatio! >= 0.9 && Math.min(x.w, x.h) >= 500)));
  ok.sort((a, b) => a.rank - b.rank);
  const out: Analyzed[] = [];
  for (const c of ok) { if (c.hash && out.some((o) => o.hash && hamming(o.hash, c.hash!) <= 4)) continue; out.push(c); if (out.length >= max) break; }
  if (!hasSharp) warnings.push('کتابخانه sharp نصب نیست؛ زمینه سفید و کیفیت عکس‌ها بررسی نشد (npm i sharp).');
  if (out.length < min) warnings.push(`فقط ${out.length} عکس معتبر با زمینه سفید پیدا شد (هدف ${min} تا ${max}).`);
  return { selected: out, warnings };
}

const PROJECT_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
export async function saveImages(slug: string, sel: Analyzed[], sharp: any | null, root = path.join(PROJECT_ROOT, 'public', 'uploads', 'products')) {
  const safe = slug.toLowerCase().replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80) || 'product';
  const dir = path.join(root, safe); fs.mkdirSync(dir, { recursive: true });
  const urls: string[] = [];
  for (let i = 0; i < sel.length; i++) {
    const extension = sharp ? 'jpg' : (sel[i].format === 'jpeg' ? 'jpg' : sel[i].format);
    const file = `img-${i + 1}.${extension}`;
    const out = sharp ? await sharp(sel[i].buf).flatten({ background: '#fff' }).resize(1000, 1000, { fit: 'contain', background: '#fff' }).jpeg({ quality: 88 }).toBuffer() : sel[i].buf;
    fs.writeFileSync(path.join(dir, file), out); urls.push(`/uploads/products/${safe}/${file}`);
  }
  return urls;
}
