// تحلیل ورودی مدیر (نام فارسی/انگلیسی یا لینک) با همان موتور هویت کالا که قوانین تأمین‌کننده استفاده می‌کنند؛
// بنابراین «A57 8/256» در ثبت هوشمند و در تطبیق قیمت دقیقاً یک معنی دارد.
import { identityFromText, type Identity } from '../identity.js';

export interface ParsedQuery {
  raw: string; normalized: string; url?: string;
  brandEn?: string; brandFa?: string;
  /** عبارت مدل بدون رم/حافظه (برای جستجو) */
  modelText: string;
  ram?: number; storage?: number;
  identity: Identity;
  variantHints: string[];
}

// برند هویت (token کوچک) → [نام انگلیسی، نام فارسی]
export const BRAND_NAMES: Record<string, [string, string]> = {
  samsung: ['Samsung', 'سامسونگ'], apple: ['Apple', 'اپل'], xiaomi: ['Xiaomi', 'شیائومی'], realme: ['Realme', 'ریلمی'],
  honor: ['Honor', 'آنر'], huawei: ['Huawei', 'هوآوی'], nokia: ['Nokia', 'نوکیا'], motorola: ['Motorola', 'موتورولا'],
  google: ['Google', 'گوگل'], oneplus: ['OnePlus', 'وان‌پلاس'], tecno: ['Tecno', 'تکنو'], infinix: ['Infinix', 'اینفینیکس'],
  oppo: ['Oppo', 'اوپو'], vivo: ['Vivo', 'ویوو'], nothing: ['Nothing', 'ناتینگ'], sony: ['Sony', 'سونی'],
  lenovo: ['Lenovo', 'لنوو'], asus: ['ASUS', 'ایسوس'], hp: ['HP', 'اچ‌پی'], dell: ['Dell', 'دل'], acer: ['Acer', 'ایسر'],
  msi: ['MSI', 'ام‌اس‌آی'], microsoft: ['Microsoft', 'مایکروسافت'], nintendo: ['Nintendo', 'نینتندو'], lg: ['LG', 'ال‌جی'],
};
export const brandNames = (b: string): [string, string] => BRAND_NAMES[b] || [b ? b[0].toUpperCase() + b.slice(1) : '', ''];

const FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';
export const toLatinDigits = (s: string) => s.replace(/[۰-۹]/g, (c) => String(FA_DIGITS.indexOf(c))).replace(/[٠-٩]/g, (c) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(c)));

export function parseQuery(raw: string): ParsedQuery {
  const input = String(raw || '');
  const url = input.match(/https?:\/\/[^\s]+/i)?.[0];
  const text = toLatinDigits(input.replace(/https?:\/\/[^\s]+/gi, ' ')).replace(/[‌_]/g, ' ').replace(/\s+/g, ' ').trim();
  const identity = identityFromText(text, { loose: true });
  // نام مدل به‌تنهایی (مثل «A57») برند را هم مشخص می‌کند
  if (!identity.brand && identity.model) {
    if (/^(a|m|f|s|z)\d{2}[a-z]?$/.test(identity.model) || /^(galaxy|tab)/.test(identity.model)) identity.brand = 'samsung';
    else if (/^iphone|^ipad/.test(identity.model)) identity.brand = 'apple';
    else if (/^(redmi|poco|mi)\b/.test(identity.model)) identity.brand = 'xiaomi';
  }
  const [brandEn, brandFa] = brandNames(identity.brand);
  const modelText = [identity.model, ...identity.modifiers, identity.network || ''].filter(Boolean).join(' ').trim();
  return {
    raw: input, normalized: text, url, brandEn: brandEn || undefined, brandFa: brandFa || undefined, modelText,
    ram: identity.ram ?? undefined, storage: identity.storage ?? undefined, identity, variantHints: identity.modifiers,
  };
}
