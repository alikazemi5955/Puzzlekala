// تطبیق هر شاهد با درخواست مدیر. فقط شاهدی که برند، مدل، نسخه (Pro/Ultra/FE ...)، رم، حافظه و شبکه‌اش
// با درخواست نمی‌خواند «رد» می‌شود؛ مشخصه‌ی ننوشته‌شده در درخواست (مثلاً رم) رد نمی‌کند ولی بعداً باید روشن شود.
import { canonicalLabel, identityFromText, type Identity } from '../identity.js';
import type { ParsedQuery } from './queryParser.js';
import type { Evidence } from './sources.js';

export interface Verified { ev: Evidence; identity: Identity }
export interface Rejected { ev: Evidence; reasons: string[] }

const CPU_LIKE = /^(i[3579]|r[3579]|ryzen.*|core.*)$/;
const words = (s: string) => s.toLowerCase().split(/[^a-z0-9؀-ۿ]+/).filter((w) => w.length > 1);

/**
 * مشخصات ساختاریافته‌ی منبع (مثلاً جدول HTML) هم بخشی از هویت شاهدند.
 * فقط فیلدهایی اضافه می‌شوند که برچسبشان صریحاً رم/حافظه باشد؛ از اعداد
 * عمومی مثل اندازه نمایشگر یا باتری برای حدس ظرفیت استفاده نمی‌کنیم.
 */
export function identityFromEvidence(ev: Evidence): Identity {
  const explicitSpecs = (ev.specs || [])
    .filter((s) => ['ram', 'storage'].includes(canonicalLabel(String(s.label || ''))))
    .map((s) => `${s.label} ${s.value}`);
  return identityFromText([ev.title, ...explicitSpecs].join(' '));
}

export function verifyEvidence(q: ParsedQuery, ev: Evidence): { ok: true; identity: Identity } | { ok: false; reasons: string[] } {
  const qi = q.identity, e = identityFromEvidence(ev);
  const why: string[] = [];
  if (e.category === 'accessory' && qi.category !== 'accessory') why.push('کالای پیداشده لوازم جانبی/قاب/قطعه است');
  if (qi.brand && e.brand && qi.brand !== e.brand) why.push(`برند متفاوت: ${e.brand}`);
  if (qi.model && !CPU_LIKE.test(qi.model)) {
    if (!e.model) why.push('مدل در عنوان شاهد قابل تشخیص نیست');
    else if (e.model !== qi.model) why.push(`مدل متفاوت: ${e.model}`);
    else if (qi.modifiers.join() !== e.modifiers.join()) why.push(`نسخه‌ی مدل متفاوت: «${e.modifiers.join(' ') || 'استاندارد'}» به‌جای «${qi.modifiers.join(' ') || 'استاندارد'}»`);
  } else {
    // مدلِ قابل‌اتکا نداریم (مثلاً لپ‌تاپ): همه‌ی واژه‌های معنی‌دار درخواست باید در عنوان باشد
    const tw = words(ev.title).join(' '); const want = words(q.normalized).filter((w) => !/^\d+$/.test(w) && !/^(گیگ|گیگابایت|gb|رم|ram|لپ|تاپ|لپتاپ)$/.test(w));
    const miss = want.filter((w) => !tw.includes(w));
    if (want.length && miss.length / want.length > 0.34) why.push('عنوان شاهد با عبارت درخواستی نمی‌خواند');
  }
  for (const f of ['ram', 'storage', 'network'] as const) {
    const fa = f === 'ram' ? 'رم' : f === 'storage' ? 'حافظه' : 'شبکه';
    if (qi[f] !== null && e[f] !== null && qi[f] !== e[f]) {
      why.push(`${fa} متفاوت: ${e[f]} به‌جای ${qi[f]}`);
    } else if ((f === 'ram' || f === 'storage') && qi[f] !== null && e[f] === null) {
      // وقتی مدیر نسخه مشخصی خواسته، عنوان/مشخصات شاهد باید همان فیلد را صریحاً ثابت کند.
      // در غیر این صورت، شاهد عمومی نباید منبع رنگ/عکس/مشخصات نسخه‌ای دیگر شود.
      why.push(`در شاهد، ${fa} نسخه‌ی درخواستی مشخص نیست`);
    }
  }
  return why.length ? { ok: false, reasons: why } : { ok: true, identity: e };
}
