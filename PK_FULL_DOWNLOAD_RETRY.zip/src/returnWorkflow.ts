/** Return-request workflow transitions. A repeated status is idempotent. */
const transitions: Record<string, readonly string[]> = {
  pending: ['approved', 'rejected'],
  approved: ['received', 'rejected'],
  received: ['refund_pending', 'closed'],
  refund_pending: ['closed'],
  rejected: [],
  closed: [],
};

export function canTransitionReturnStatus(from: string, to: string): boolean {
  if (from === to) return true;
  return (transitions[from] || []).includes(to);
}
