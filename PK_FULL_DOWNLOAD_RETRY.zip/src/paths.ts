// مسیر پوشه‌ی داده‌ها در یک نقطه تعریف می‌شود.
// برای میزبانی روی سرویسی که با هر دیپلوی فایل‌ها را پاک می‌کند، PUZZLEKALA_DATA_DIR را روی یک دیسک پایدار بگذارید.
import path from 'path';
import { fileURLToPath } from 'url';

try { (process as any).loadEnvFile?.('.env'); } catch { /* .env وجود ندارد */ }

export const PROJECT_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const DATA_DIR = process.env.PUZZLEKALA_DATA_DIR ? path.resolve(process.env.PUZZLEKALA_DATA_DIR) : path.join(PROJECT_ROOT, 'data');
