// هسته‌ی تشخیص هویت کالا (برند، مدل، نسخه، رم، حافظه، شبکه، پارت‌نامبر، رنگ و ...).
// تابع‌های خالص و بدون ورودی/خروجی؛ فقط بر اساس «توکن‌ها» کار می‌کند، نه جستجوی زیررشته
// (تا مثلاً «Aluminum» به‌عنوان mini یا «Frame» به‌عنوان me/امارات شناخته نشود).
// قاعده‌ی اصلی: هر مشخصه‌ی ننوشته «نامعلوم» است، نه «برابر». نامعلوم هرگز قیمت را تغییر نمی‌دهد.

export type Category = 'phone' | 'tablet' | 'laptop' | 'console' | 'accessory' | 'other';

export interface Identity {
  brand: string;
  model: string;
  modifiers: string[];
  ram: number | null; // GB
  storage: number | null; // GB
  network: '5G' | '4G' | null;
  sim: 'dual' | 'single' | null;
  part: string | null;
  region: string | null;
  cpu: string | null;
  gpu: string | null;
  screen: string | null;
  colorPhrase: string | null;
  attrs: Record<string, string>;
  conflicts: string[];
  category: Category;
}

export type FieldName = 'brand' | 'model' | 'modifiers' | 'ram' | 'storage' | 'network' | 'sim' | 'part' | 'region' | 'cpu' | 'gpu' | 'screen';

export const FIELD_FA: Record<string, string> = {
  brand: 'برند', model: 'مدل', modifiers: 'نسخه‌ی مدل', ram: 'رم', storage: 'حافظه', network: 'شبکه',
  sim: 'تعداد سیم‌کارت', part: 'پارت‌نامبر', region: 'کشور/ریجن', cpu: 'پردازنده', gpu: 'کارت گرافیک', screen: 'اندازه‌ی صفحه',
};

export interface MatchingRules {
  /** اگر کالای خود مدیر این مشخصه را دارد، کالای تأمین‌کننده هم باید آن را صراحتاً بنویسد و برابر باشد */
  requiredIfMasterHas: FieldName[];
  /** مشخصه‌هایی که اگر تأمین‌کننده ننوشته باشد، فقط وقتی «نامعلوم» است که ردیف هم‌خانواده‌ی متفاوتی در کاتالوگ او باشد */
  softFields: FieldName[];
  /** مشخصه‌های لازم برای هر دسته (حتی اگر در کالای مدیر ننوشته باشد) */
  requiredByCategory: Record<string, FieldName[]>;
  /** برچسب‌های مشخصات ساختاریافته که در صورت اختلاف، تطبیق را رد می‌کنند (علاوه بر موارد بالا) */
  identityLabels: string[];
}

export const DEFAULT_RULES: MatchingRules = {
  requiredIfMasterHas: ['ram', 'storage', 'part', 'region', 'cpu', 'gpu', 'screen'],
  softFields: ['network', 'sim'],
  requiredByCategory: {
    phone: ['ram', 'storage'],
    tablet: ['ram', 'storage'],
    laptop: ['ram', 'storage', 'cpu'],
    console: ['storage'],
  },
  identityLabels: [],
};

// ----------------------------------------------------------------------------
// نرمال‌سازی و توکن‌سازی
// ----------------------------------------------------------------------------

export function fold(text: unknown): string {
  return String(text ?? '')
    .toLowerCase()
    .replace(/[يى]/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 1776))
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 1632))
    .replace(/[‌‍‎‏ً-ْـ]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

const PART_APPLE = /\b(ch|zp|za|ll|th|hn|ja|kh|zd|bz|ae|qn|ip|je)\s*\/\s*a\b/i;
const PART_SAMSUNG = /\bsm[\s-]*([a-z]\d{3,4}[a-z0-9]{0,3})\b/i;
const PART_CFI = /\bcfi[\s-]*(\d{3,4}[a-z]?)\b/i;

function extractPart(raw: string): { part: string | null; rest: string } {
  let rest = raw;
  let part: string | null = null;
  const a = rest.match(PART_APPLE);
  if (a) { part = `${a[1].toUpperCase()}/A`; rest = rest.replace(PART_APPLE, ' '); }
  const s = rest.match(PART_SAMSUNG);
  if (s) { part = part || `SM-${s[1].toUpperCase()}`; rest = rest.replace(PART_SAMSUNG, ' '); }
  const c = rest.match(PART_CFI);
  if (c) { part = part || `CFI-${c[1].toUpperCase()}`; rest = rest.replace(PART_CFI, ' '); }
  return { part, rest };
}

const CPU_RE = /\b(?:core\s*)?(i[3579])[\s-]*(\d{4,5}[a-z]{0,2})\b|\bryzen\s*([3579])\s*(\d{4}[a-z]{0,2})\b|\bcore\s*ultra\s*([3579])\s*(\d{3}[a-z]?)\b/i;
const GPU_RE = /\b(rtx|gtx|rx)\s*(\d{3,4})(\s*ti|\s*super)?\b/i;
const SCREEN_RE = /(\d{1,2}(?:\.\d{1,2})?)\s*(?:inch|inches|اینچ|"|”)/i;

function extractCpuGpuScreen(raw: string) {
  let rest = raw;
  let cpu: string | null = null, gpu: string | null = null, screen: string | null = null;
  const c = rest.match(CPU_RE);
  if (c) {
    cpu = c[1] ? `${c[1]}-${c[2]}` : c[3] ? `ryzen${c[3]}-${c[4]}` : `ultra${c[5]}-${c[6]}`;
    cpu = cpu.toLowerCase();
    rest = rest.replace(CPU_RE, ' ');
  }
  const g = rest.match(GPU_RE);
  if (g) { gpu = `${g[1]}${g[2]}${(g[3] || '').replace(/\s+/g, '')}`.toLowerCase(); rest = rest.replace(GPU_RE, ' '); }
  const s = rest.match(SCREEN_RE);
  if (s) { screen = String(Number(s[1])); rest = rest.replace(SCREEN_RE, ' '); }
  return { cpu, gpu, screen, rest };
}

const LETTER_NAMES: Record<string, string> = { 'ای': 'a', 'اس': 's', 'ام': 'm', 'اف': 'f', 'ایکس': 'x', 'سی': 'c', 'جی': 'g', 'وای': 'y', 'بی': 'b', 'دی': 'd', 'پی': 'p', 'وی': 'v', 'ان': 'n' };

export function tokenize(text: string): string[] {
  let s = fold(text);
  s = s.replace(/\bاف\s*ای\b/g, ' fe ').replace(/\bاس\s*ای\b/g, ' se ');
  // «ای 57» → a57 ، «ایکس 7» → x7 ، «اس 24» → s24 (فقط وقتی بلافاصله عدد بیاید)
  s = s.replace(/(^|\s)(ایکس|وای|ای|اس|ام|اف|سی|جی|بی|دی|پی|وی|ان)\s*(\d{1,3})([a-z]{0,2})(?=\s|$|\/)/g, (_m, pre, l, num, suf) => `${pre}${LETTER_NAMES[l]}${num}${suf} `);
  s = s.replace(/(?:playstation|پلی\s*استیشن)\s*(\d)/g, 'ps$1 ');
  s = s.replace(/([a-z]{1,4}\d{0,3})\+(?=\s|$)/g, (m, w) => (/^(gb|tb)$/.test(w) ? m : `${w} plus `));
  s = s.replace(/([\/+])/g, ' $1 ');
  s = s.replace(/(\d)(gb|tb|mah|mp|hz|inch|گیگابایت|گیگ|ترابایت)/g, '$1 $2');
  s = s.replace(/[^a-z0-9؀-ۿ\/+.\s]/g, ' ');
  s = s.replace(/(?<![0-9])\.|\.(?![0-9])/g, ' ');
  return s.split(/\s+/).filter(Boolean);
}

// ----------------------------------------------------------------------------
// واژه‌نامه‌ها
// ----------------------------------------------------------------------------

const BRAND_WORDS: Record<string, string> = {
  samsung: 'samsung', 'سامسونگ': 'samsung', 'سامسونج': 'samsung', galaxy: 'samsung', 'گلکسی': 'samsung',
  apple: 'apple', 'اپل': 'apple', iphone: 'apple', 'آیفون': 'apple', 'ایفون': 'apple', 'ایپون': 'apple', ipad: 'apple', macbook: 'apple', airpods: 'apple',
  xiaomi: 'xiaomi', 'شیائومی': 'xiaomi', 'شیایومی': 'xiaomi', 'شیاومی': 'xiaomi', redmi: 'xiaomi', 'ردمی': 'xiaomi', 'ریدمی': 'xiaomi', poco: 'xiaomi', 'پوکو': 'xiaomi',
  honor: 'honor', 'آنر': 'honor', 'هونر': 'honor', huawei: 'huawei', 'هوآوی': 'huawei', 'هواوی': 'huawei',
  realme: 'realme', 'ریلمی': 'realme', 'رئلمی': 'realme', nokia: 'nokia', 'نوکیا': 'nokia', motorola: 'motorola', 'موتورولا': 'motorola',
  google: 'google', 'گوگل': 'google', pixel: 'google', 'پیکسل': 'google', oneplus: 'oneplus', 'وانپلاس': 'oneplus',
  tecno: 'tecno', 'تکنو': 'tecno', infinix: 'infinix', 'اینفینیکس': 'infinix', oppo: 'oppo', 'اوپو': 'oppo', vivo: 'vivo', 'ویوو': 'vivo',
  nothing: 'nothing', 'ناتینگ': 'nothing', sony: 'sony', 'سونی': 'sony', playstation: 'sony', 'پلی': 'sony', asus: 'asus', 'ایسوس': 'asus',
  lenovo: 'lenovo', 'لنوو': 'lenovo', microsoft: 'microsoft', 'مایکروسافت': 'microsoft', hp: 'hp', dell: 'dell', 'دل': 'dell', acer: 'acer', 'ایسر': 'acer', msi: 'msi',
  anker: 'anker', 'انکر': 'anker', baseus: 'baseus', 'بیسوس': 'baseus', jbl: 'jbl', logitech: 'logitech', 'لاجیتک': 'logitech', amazfit: 'amazfit', 'آمازفیت': 'amazfit',
  nillkin: 'nillkin', 'نیلکین': 'nillkin', spigen: 'spigen', 'اسپیگن': 'spigen', nintendo: 'nintendo', 'نینتندو': 'nintendo', lg: 'lg',
};

/** واژه‌های خانواده که بخشی از نام مدل‌اند و حفظ می‌شوند. مقدار = شکل استاندارد. */
const FAMILY_KEEP: Record<string, string> = {
  iphone: 'iphone', 'آیفون': 'iphone', 'ایفون': 'iphone', 'ایپون': 'iphone',
  redmi: 'redmi', 'ردمی': 'redmi', 'ریدمی': 'redmi', note: 'note', 'نوت': 'note',
  poco: 'poco', 'پوکو': 'poco', pixel: 'pixel', 'پیکسل': 'pixel', nova: 'nova', 'نوا': 'nova', mate: 'mate', magic: 'magic', reno: 'reno', 'رنو': 'reno',
  find: 'find', nord: 'nord', spark: 'spark', camon: 'camon', hot: 'hot', pova: 'pova', zero: 'zero', edge: 'edge', razr: 'razr',
  fold: 'fold', 'فولد': 'fold', flip: 'flip', 'فلیپ': 'flip', ipad: 'ipad', macbook: 'macbook', watch: 'watch',
};
/** واژه‌های خانواده که حذف می‌شوند (فقط بازاریابی) */
const FAMILY_DROP = new Set(['galaxy', 'گلکسی', 'z', 'xiaomi', 'شیائومی', 'mi']);

const MODIFIER_WORDS: Record<string, string> = {
  pro: 'pro', 'پرو': 'pro', max: 'max', 'مکس': 'max', plus: 'plus', 'پلاس': 'plus', ultra: 'ultra', 'اولترا': 'ultra',
  mini: 'mini', 'مینی': 'mini', lite: 'lite', 'لایت': 'lite', fe: 'fe', se: 'se', air: 'air', 'ایر': 'air', neo: 'neo', 'نئو': 'neo',
  gt: 'gt', turbo: 'turbo', 'توربو': 'turbo', slim: 'slim', 'اسلیم': 'slim', digital: 'digital', 'دیجیتال': 'digital',
  prime: 'prime', edge: 'edge', active: 'active', 'اکتیو': 'active',
};

const UNIT_GB = new Set(['gb', 'g', 'گیگ', 'گیگابایت', 'گیگا', 'giga', 'gigabyte']);
const UNIT_TB = new Set(['tb', 'ترابایت', 'ترا']);
const UNIT_OTHER = new Set(['mah', 'mp', 'hz', 'inch', 'w', 'mm', 'میلی', 'مگاپیکسل', 'اینچ', 'وات', 'هرتز', 'میلی‌آمپر']);
const RAM_LABELS = new Set(['ram', 'رم', 'memory']);
const STORAGE_LABELS = new Set(['ظرفیت', 'حافظه', 'storage', 'rom', 'ssd', 'hdd', 'internal', 'داخلی', 'capacity']);
const RAM_SET = new Set([1, 2, 3, 4, 6, 8, 10, 12, 16, 18, 24, 32, 64]);
const STORAGE_SET = new Set([16, 32, 64, 128, 256, 512, 1024, 2048, 4096]);
const IGNORE_CODE = /^(ip\d{2}|hdr\d*|ddr\d|lpddr\d\w*|ufs\d.*|wifi\d*|wi|bt\d.*|usb\d?|nfc|oled|amoled|lcd|led|x\d{1,2}hz)$/;
const NUMERIC_BRANDS = new Set(['apple', 'xiaomi', 'realme', 'oneplus', 'honor', 'google', 'huawei', 'oppo', 'vivo', 'nothing', 'tecno', 'infinix', 'motorola']);

const ACCESSORY_RE = /^(کاور|قاب|گارد|گلس|محافظ|شارژر|کابل|هندزفری|هدفون|پاوربانک|پاور|اسپیکر|بند|پایه|هولدر|case|cover|glass|charger|cable|adapter|holder|stand|strap|protector|buzzer|module|tray|battery|باتری|lcd|تاچ|ال‌سی‌دی|روکش|کیف|پک|bundle|باندل|سرویس|service|دسته|کنترلر|controller|gamepad|هدست|headset|earbuds|ایرپاد|airpods|شارژ)$/;

// ----------------------------------------------------------------------------
// رنگ‌ها
// ----------------------------------------------------------------------------

const COLOR_CANON: Record<string, string> = {
  'مشکی': 'black', 'سیاه': 'black', 'سرمهای': 'navy', 'نقرهای': 'silver', 'قهوهای': 'brown', 'فیروزهای': 'teal', 'شب': 'night', black: 'black', 'نیمه': 'midnight', midnight: 'midnight',
  'سفید': 'white', white: 'white', 'آبی': 'blue', 'ابی': 'blue', blue: 'blue', 'سرمه': 'navy', navy: 'navy',
  'خاکستری': 'gray', 'طوسی': 'gray', gray: 'gray', grey: 'gray', 'نقره': 'silver', silver: 'silver',
  'طلایی': 'gold', 'طلا': 'gold', gold: 'gold', 'سبز': 'green', green: 'green', 'نعنایی': 'mint', mint: 'mint',
  'بنفش': 'purple', purple: 'purple', 'یاسی': 'lilac', lilac: 'lilac', lavender: 'lilac', 'صورتی': 'pink', pink: 'pink',
  'رز': 'rose', rose: 'rose', 'قرمز': 'red', red: 'red', 'زرد': 'yellow', yellow: 'yellow', 'نارنجی': 'orange', orange: 'orange',
  'تیتانیوم': 'titanium', titanium: 'titanium', 'نچرال': 'natural', natural: 'natural', 'صحرایی': 'desert', desert: 'desert',
  'کرم': 'cream', cream: 'cream', 'هلویی': 'peach', peach: 'peach', 'لیمویی': 'lime', lime: 'lime', 'یخی': 'icy', icy: 'icy', ice: 'icy',
  'اقیانوسی': 'ocean', ocean: 'ocean', 'استارلایت': 'starlight', starlight: 'starlight', 'گرافیتی': 'graphite', graphite: 'graphite',
  'مرجانی': 'coral', coral: 'coral', 'قهوه': 'brown', brown: 'brown', 'فیروزه': 'teal', teal: 'teal', turquoise: 'teal',
  'روشن': 'light', light: 'light', 'تیره': 'dark', dark: 'dark', 'زیتونی': 'olive', olive: 'olive', 'مسی': 'copper', copper: 'copper',
  'فضایی': 'space', space: 'space', 'آسمانی': 'sky', sky: 'sky', 'عمیق': 'deep', deep: 'deep', 'کوهستانی': 'alpine', alpine: 'alpine',
};
/** واژه‌های توصیفی که هویت رنگ را عوض نمی‌کنند */
const COLOR_FILLER = new Set(['متالیک', 'metallic', 'کریستالی', 'crystal', 'crystalline', 'لطیف', 'soft', 'پریمیوم', 'premium', 'مات', 'matte', 'براق', 'glossy',
  'awesome', 'کلاسیک', 'classic', 'رنگ', 'color', 'colour', 'ای', 'ی', 'پلاستیکی', 'شیشه', 'glass', 'edition', 'اورجینال']);
/** «ای» در «سرمه ای / نقره ای / قهوه ای» پس از توکن‌سازی جدا می‌شود */

export function colorTokens(name: string): string[] {
  const out: string[] = [];
  for (const t of tokenize(name)) {
    if (COLOR_FILLER.has(t)) continue;
    if (t === '/' || t === '+') continue;
    out.push(COLOR_CANON[t] || t);
  }
  return [...new Set(out)];
}
export const colorKey = (name: string): string => colorTokens(name).sort().join(' ');

export interface ColorMapResult {
  /** جفت‌های [اندیس رنگ کالای مدیر، اندیس رنگ‌های تأمین‌کننده] */
  pairs: { master: number; supplier: number[]; loose: boolean }[];
  unmatchedMaster: number[];
  unmatchedSupplier: number[];
  ambiguousSupplier: { supplier: number; masters: number[] }[];
}

/** نگاشت رنگ‌های تأمین‌کننده به رنگ‌های ثبت‌شده‌ی کالا؛ فقط اگر یکتا و بدون ابهام باشد. */
export function mapColors(masterNames: string[], supplierNames: string[]): ColorMapResult {
  const mk = masterNames.map(colorTokens);
  const sk = supplierNames.map(colorTokens);
  const equal = (a: string[], b: string[]) => a.length === b.length && a.every((x) => b.includes(x));
  const subset = (a: string[], b: string[]) => a.length > 0 && a.length < b.length && a.every((x) => b.includes(x));

  // رنگ‌های هم‌کلید تأمین‌کننده (مثلاً «Navy» و «سرمه ای») یک رنگ‌اند
  const groups: { tokens: string[]; members: number[] }[] = [];
  sk.forEach((t, i) => {
    const g = groups.find((x) => equal(x.tokens, t));
    if (g) g.members.push(i); else groups.push({ tokens: t, members: [i] });
  });

  const pairsByMaster = new Map<number, { supplier: number[]; loose: boolean }>();
  const usedGroup = new Set<number>();
  const take = (mi: number, gi: number, loose: boolean) => {
    pairsByMaster.set(mi, { supplier: groups[gi].members, loose });
    usedGroup.add(gi);
  };

  // ۱) برابری کامل
  groups.forEach((g, gi) => {
    const hits = mk.map((m, mi) => (equal(g.tokens, m) ? mi : -1)).filter((x) => x >= 0);
    if (hits.length === 1 && !pairsByMaster.has(hits[0])) take(hits[0], gi, false);
  });

  // ۲) زیرمجموعه (مثلاً «آبی» با «آبی یخی»)؛ فقط اگر دقیقاً یک جفت ممکن باشد
  const ambiguousSupplier: ColorMapResult['ambiguousSupplier'] = [];
  const freeMasters = () => mk.map((_, i) => i).filter((i) => !pairsByMaster.has(i));
  groups.forEach((g, gi) => {
    if (usedGroup.has(gi)) return;
    const hits = freeMasters().filter((mi) => subset(g.tokens, mk[mi]) || subset(mk[mi], g.tokens));
    const rivals = groups.filter((o, oi) => oi !== gi && !usedGroup.has(oi) && hits.some((mi) => subset(o.tokens, mk[mi]) || subset(mk[mi], o.tokens))).length;
    if (hits.length === 1 && rivals === 0) { take(hits[0], gi, true); return; }
    if (hits.length > 0) for (const si of g.members) ambiguousSupplier.push({ supplier: si, masters: hits });
  });

  const pairs = [...pairsByMaster.entries()].map(([master, v]) => ({ master, supplier: v.supplier, loose: v.loose }));
  const ambSet = new Set(ambiguousSupplier.map((a) => a.supplier));
  const usedSup = new Set(pairs.flatMap((p) => p.supplier));
  return {
    pairs,
    unmatchedMaster: mk.map((_, i) => i).filter((i) => !pairsByMaster.has(i)),
    unmatchedSupplier: sk.map((_, i) => i).filter((i) => !usedSup.has(i) && !ambSet.has(i)),
    ambiguousSupplier,
  };
}

const COLOR_VOCAB = new Set([...Object.keys(COLOR_CANON), ...COLOR_FILLER]);
/** آخرین دنباله‌ی پیوسته‌ی واژه‌های رنگ در عنوان */
export function colorFromTokens(tokens: string[]): string | null {
  let best: string[] = [];
  let cur: string[] = [];
  for (const t of tokens) {
    if (COLOR_VOCAB.has(t)) cur.push(t);
    else { if (cur.length) best = cur; cur = []; }
  }
  if (cur.length) best = cur;
  const words = best.filter((t) => !COLOR_FILLER.has(t) || best.length > 1);
  return words.length ? words.join(' ') : null;
}

// ----------------------------------------------------------------------------
// استخراج هویت از یک متن
// ----------------------------------------------------------------------------

const emptyIdentity = (): Identity => ({
  brand: '', model: '', modifiers: [], ram: null, storage: null, network: null, sim: null, part: null, region: null,
  cpu: null, gpu: null, screen: null, colorPhrase: null, attrs: {}, conflicts: [], category: 'other',
});

const REGION_WORDS: Record<string, string> = {
  'ویتنام': 'vietnam', vietnam: 'vietnam', vn: 'vietnam', 'هند': 'india', 'هندوستان': 'india', india: 'india',
  'چین': 'china', china: 'china', cn: 'china', 'اروپا': 'europe', europe: 'europe', eu: 'europe',
  'امارات': 'uae', 'دبی': 'uae', uae: 'uae', dubai: 'uae', 'ترکیه': 'turkey', turkey: 'turkey', 'اندونزی': 'indonesia', indonesia: 'indonesia',
};

function isCodeToken(t: string, brand: string, afterFamily: boolean): boolean {
  if (IGNORE_CODE.test(t)) return false;
  if (/^[345]g$/.test(t)) return false;
  if (/^[a-z]{1,2}\d{1,3}[a-z]{0,2}$/.test(t) && !/^(mah|mp|hz|gb|tb)$/.test(t)) return true;
  if (/^(fold|flip)\d$/.test(t)) return true;
  if (/^\d{1,2}[a-z]?$/.test(t) && !/^[345]g$/.test(t) && (afterFamily || NUMERIC_BRANDS.has(brand))) return true;
  if (/^\d{3,4}$/.test(t) && brand === 'nokia') return true;
  return false;
}

/** هویت را از یک رشته‌ی متن می‌خواند (عنوان کالا یا ورودی کاربر). */
export function identityFromText(text: string, opts: { loose?: boolean } = {}): Identity {
  const id = emptyIdentity();
  const folded = fold(text);
  const p = extractPart(folded);
  id.part = p.part;
  const g = extractCpuGpuScreen(p.rest);
  id.cpu = g.cpu; id.gpu = g.gpu; id.screen = g.screen;
  const tokens = tokenize(g.rest);

  // برند
  for (const t of tokens) { if (BRAND_WORDS[t]) { id.brand = BRAND_WORDS[t]; break; } }

  if (!id.brand && tokens.some((t) => /^ps\d$/.test(t))) id.brand = 'sony';

  // مدل
  let i = 0;
  const family: string[] = [];
  let code = '';
  let codeIdx = -1;
  let afterFamily = false;
  for (; i < tokens.length; i++) {
    const t = tokens[i];
    if (FAMILY_KEEP[t]) { family.push(FAMILY_KEEP[t]); afterFamily = true; continue; }
    if (FAMILY_DROP.has(t) || BRAND_WORDS[t]) { continue; }
    if (isCodeToken(t, id.brand, afterFamily)) {
      // عددی که بلافاصله جلوی «/» یا واحد است رم/حافظه است، نه مدل
      const nxt = tokens[i + 1];
      if (/^\d+$/.test(t) && (nxt === '/' || nxt === '+' || UNIT_GB.has(nxt) || UNIT_TB.has(nxt) || UNIT_OTHER.has(nxt))) { continue; }
      code = t; codeIdx = i; break;
    }
    // فاصله‌ی «z fold 6» و «galaxy s 24»
    if (family.length && /^\d{1,2}$/.test(t)) { code = t; codeIdx = i; break; }
  }
  const fm = code.match(/^(fold|flip)(\d)$/);
  if (fm) { family.push(fm[1]); code = fm[2]; }
  // خانواده‌ی بدون کد (مثلاً «pixel fold») مدل نیست
  if (code) id.model = [...new Set(family)].concat(code).join(' ');

  // نسخه‌ی مدل: واژه‌های بسته‌ی بلافاصله بعد از کد (با پرش از 5G/4G)
  const mods = new Set<string>();
  if (codeIdx >= 0) {
    for (let k = codeIdx + 1; k < tokens.length && k <= codeIdx + 6; k++) {
      const t = tokens[k];
      if (MODIFIER_WORDS[t]) mods.add(MODIFIER_WORDS[t]);
      else if (/^[345]g$/.test(t) || t === 'lte') continue;
      else break;
    }
  } else if (id.brand === 'sony' || /ps\d/.test(tokens.join(' '))) {
    for (const t of tokens) if (MODIFIER_WORDS[t]) mods.add(MODIFIER_WORDS[t]);
  }
  id.modifiers = [...mods].sort();

  // شبکه / سیم‌کارت / ریجن
  for (let k = 0; k < tokens.length; k++) {
    const t = tokens[k];
    if (/^5g$/.test(t)) id.network = '5G';
    else if ((t === '4g' || t === 'lte') && id.network !== '5G') id.network = '4G';
    if ((t === 'دو' || t === 'dual' || t === '2') && /^(سیم|سیمکارت|سیم‌کارت|sim|simcard)$/.test(tokens[k + 1] || '')) id.sim = 'dual';
    if (t === 'دوسیم' || t === 'dualsim' || t === 'dual-sim') id.sim = 'dual';
    if ((t === 'تک' || t === 'single' || t === '1') && /^(سیم|سیمکارت|sim|simcard)$/.test(tokens[k + 1] || '')) id.sim = 'single';
    if (REGION_WORDS[t] && !id.region) id.region = REGION_WORDS[t];
  }

  // رم و حافظه (فقط از توکن‌هایی که بخشی از کد مدل نیستند)
  const skip = new Set<number>();
  if (codeIdx >= 0) skip.add(codeIdx);
  const nums: { n: number; idx: number; unit: 'gb' | 'tb' | null; endIdx: number }[] = [];
  for (let k = 0; k < tokens.length; k++) {
    if (skip.has(k) || !/^\d+$/.test(tokens[k])) continue;
    const u = tokens[k + 1];
    const unit = UNIT_GB.has(u) ? 'gb' : UNIT_TB.has(u) ? 'tb' : null;
    nums.push({ n: Number(tokens[k]), idx: k, unit, endIdx: unit ? k + 1 : k });
  }
  const used = new Set<number>();
  let ram: number | null = null, storage: number | null = null;
  const setRam = (v: number) => { if (ram !== null && ram !== v) id.conflicts.push('ram'); else ram = v; };
  const setStorage = (v: number) => { if (storage !== null && storage !== v) id.conflicts.push('storage'); else storage = v; };
  const toGb = (x: { n: number; unit: 'gb' | 'tb' | null }) => (x.unit === 'tb' ? x.n * 1024 : x.n);

  // الف) جفت «A / B» یا «A + B»
  for (let k = 0; k < nums.length; k++) {
    const a = nums[k];
    const sepIdx = a.endIdx + 1;
    if (tokens[sepIdx] !== '/' && tokens[sepIdx] !== '+') continue;
    const b = nums.find((x) => x.idx === sepIdx + 1);
    if (!b) continue;
    const va = toGb(a), vb = toGb(b);
    const lo = Math.min(va, vb), hi = Math.max(va, vb);
    if (RAM_SET.has(lo) && STORAGE_SET.has(hi) && lo < hi && (a.unit || b.unit || opts.loose || (RAM_SET.has(va) && STORAGE_SET.has(vb)) || (RAM_SET.has(vb) && STORAGE_SET.has(va)))) {
      setRam(lo); setStorage(hi);
      used.add(a.idx); used.add(b.idx);
    }
  }
  // ب) برچسب‌دار: «رم 8» ، «8 گیگ رم» ، «ظرفیت 256» ، «256 گیگابایت ظرفیت»
  for (const x of nums) {
    if (used.has(x.idx)) continue;
    const before = tokens[x.idx - 1] || '';
    const after = tokens[x.endIdx + 1] || '';
    const beforeUnit = tokens[x.idx - 2] || '';
    const v = toGb(x);
    if (RAM_LABELS.has(before) || RAM_LABELS.has(after)) { if (RAM_SET.has(v)) { setRam(v); used.add(x.idx); } continue; }
    if (STORAGE_LABELS.has(before) || STORAGE_LABELS.has(after) || (STORAGE_LABELS.has(beforeUnit) && before === 'داخلی')) {
      if (STORAGE_SET.has(v)) { setStorage(v); used.add(x.idx); }
      continue;
    }
  }
  // ج) اعداد دارای واحد ولی بدون برچسب
  const leftovers = nums.filter((x) => !used.has(x.idx) && x.unit);
  if (leftovers.length >= 2 && ram === null && storage === null) {
    const vals = leftovers.map(toGb).sort((a, b) => a - b);
    const lo = vals[0], hi = vals[vals.length - 1];
    if (RAM_SET.has(lo) && STORAGE_SET.has(hi)) { setRam(lo); setStorage(hi); }
  } else {
    for (const x of leftovers) {
      const v = toGb(x);
      if (x.unit === 'tb') { if (storage === null) setStorage(v); else if (storage !== v) id.conflicts.push('storage'); continue; }
      if (v >= 64 && STORAGE_SET.has(v)) { if (storage === null) setStorage(v); else if (storage !== v) id.conflicts.push('storage'); }
      else if (v === 32 && ram !== null) { if (storage === null) setStorage(v); }
      // اعداد کوچک بدون برچسب (مثلاً «8GB») مبهم‌اند: رم فرض نمی‌شوند
    }
  }
  // د) حالت ورودی کاربر: «8 256» بدون هیچ واحد/جداکننده
  if (opts.loose && ram === null && storage === null) {
    const bare = nums.filter((x) => !x.unit && !used.has(x.idx));
    if (bare.length >= 2) {
      const [a, b] = [bare[bare.length - 2], bare[bare.length - 1]];
      if (RAM_SET.has(a.n) && STORAGE_SET.has(b.n) && a.n < b.n) { setRam(a.n); setStorage(b.n); }
    } else if (bare.length === 1 && STORAGE_SET.has(bare[0].n) && bare[0].n >= 64) { setStorage(bare[0].n); }
  }
  id.ram = id.conflicts.includes('ram') ? null : ram;
  id.storage = id.conflicts.includes('storage') ? null : storage;

  id.colorPhrase = colorFromTokens(tokens);

  // دسته
  const joined = tokens.join(' ');
  const accEnd = codeIdx >= 0 ? codeIdx : Math.min(tokens.length, 12);
  let accWindow = tokens.slice(0, accEnd);
  if (codeIdx >= 0) { for (let k = codeIdx + 1; k < tokens.length && k <= codeIdx + 6; k++) { if (/^\d/.test(tokens[k]) || tokens[k] === '/' || tokens[k] === '+') break; accWindow.push(tokens[k]); } }
  if (accWindow.some((t) => ACCESSORY_RE.test(t))) id.category = 'accessory';
  else if (id.cpu || /\b(laptop|notebook)\b|لپ تاپ|لپتاپ|لپ‌تاپ|macbook/.test(joined)) id.category = 'laptop';
  else if (/\b(tablet|ipad)\b|تبلت|\bpad\b/.test(joined)) id.category = 'tablet';
  else if (/\bps[345]\b|playstation|پلی استیشن|xbox|nintendo|کنسول|\bswitch\b/.test(joined)) id.category = 'console';
  else if (id.model || id.ram || id.storage) id.category = 'phone';
  return id;
}

// ----------------------------------------------------------------------------
// مشخصات ساختاریافته‌ی عمومی (هر برچسبی)
// ----------------------------------------------------------------------------

const LABEL_ALIASES: [RegExp, string][] = [
  [/(حافظه\s*ی?\s*رم|^رم$|\bram\b|حافظه\s*موقت|memory\s*ram)/i, 'ram'],
  [/(حافظه\s*ی?\s*داخلی|ظرفیت|\bstorage\b|\brom\b|\bssd\b|internal)/i, 'storage'],
  [/(شبکه|نسل|\bnetwork\b|connectivity|5g|4g)/i, 'network'],
  [/(تعداد\s*سیم|نوع\s*سیم|\bsim\b)/i, 'sim'],
  [/(پارت\s*نامبر|part\s*number|کد\s*مدل|model\s*code|\bsku\b)/i, 'part'],
  [/(کشور\s*(سازنده|تولید)|ساخت|region|origin)/i, 'region'],
  [/(پردازنده|\bcpu\b|processor|chipset)/i, 'cpu'],
  [/(کارت\s*گرافیک|\bgpu\b|graphics)/i, 'gpu'],
  [/(اندازه\s*ی?\s*(صفحه|نمایشگر)|screen\s*size|display\s*size)/i, 'screen'],
];

export function canonicalLabel(label: string): string {
  const l = fold(label);
  for (const [re, name] of LABEL_ALIASES) if (re.test(l)) return name;
  return l;
}

const ATTR_KEYS = ['attributes', 'specifications', 'specs', 'properties', 'features', 'details', 'technicalSpecs', 'spec', 'attrs'];

/** فهرست {برچسب، مقدار} را از هر شکل رایج مشخصات ساختاریافته می‌خواند. */
export function readAttributes(item: any): { label: string; value: string }[] {
  const out: { label: string; value: string }[] = [];
  const push = (label: any, value: any) => {
    const l = String(label ?? '').trim();
    const v = Array.isArray(value) ? value.map(String).join('، ') : String(value ?? '').trim();
    if (l && v) out.push({ label: l, value: v });
  };
  const walk = (node: any, depth: number) => {
    if (!node || depth > 3) return;
    if (Array.isArray(node)) {
      for (const e of node) {
        if (e && typeof e === 'object') {
          if (('label' in e || 'title' in e || 'name' in e || 'key' in e) && ('value' in e || 'values' in e || 'text' in e)) push(e.label ?? e.title ?? e.name ?? e.key, e.value ?? e.values ?? e.text);
          else if (Array.isArray(e.items) || Array.isArray(e.attributes)) walk(e.items || e.attributes, depth + 1);
        }
      }
    } else if (typeof node === 'object') {
      for (const [k, v] of Object.entries(node)) if (typeof v === 'string' || typeof v === 'number') push(k, v);
    }
  };
  for (const key of ATTR_KEYS) if (item && item[key]) walk(item[key], 0);
  return out;
}

const parseCapacity = (v: string): number | null => {
  const t = tokenize(v);
  for (let k = 0; k < t.length; k++) {
    if (/^\d+$/.test(t[k])) {
      const u = t[k + 1];
      if (UNIT_TB.has(u)) return Number(t[k]) * 1024;
      if (UNIT_GB.has(u) || !u) return Number(t[k]);
    }
  }
  return null;
};

function applyAttributes(id: Identity, attrs: { label: string; value: string }[], src: Partial<Record<FieldName, number | string | null>>) {
  for (const a of attrs) {
    const key = canonicalLabel(a.label);
    const v = a.value;
    if (key === 'ram') { const n = parseCapacity(v); if (n && RAM_SET.has(n)) src.ram = n; }
    else if (key === 'storage') { const n = parseCapacity(v); if (n && STORAGE_SET.has(n)) src.storage = n; }
    else if (key === 'network') { const f = fold(v); if (/\b5g\b|5 g/.test(f)) src.network = '5G'; else if (/\b4g\b|lte/.test(f)) src.network = '4G'; }
    else if (key === 'sim') { const f = tokenize(v).join(' '); if (/دو|dual|2/.test(f)) src.sim = 'dual'; else if (/تک|single|1/.test(f)) src.sim = 'single'; }
    else if (key === 'part') { const p = extractPart(fold(v)).part; if (p) src.part = p; }
    else if (key === 'region') { for (const t of tokenize(v)) if (REGION_WORDS[t]) { src.region = REGION_WORDS[t]; break; } }
    else if (key === 'cpu') { const m = extractCpuGpuScreen(fold(v)).cpu; if (m) src.cpu = m; }
    else if (key === 'gpu') { const m = extractCpuGpuScreen(fold(v)).gpu; if (m) src.gpu = m; }
    else if (key === 'screen') { const m = extractCpuGpuScreen(fold(v) + ' inch').screen || String(parseFloat(v) || '') ; if (m) src.screen = m; }
    id.attrs[key] = fold(v);
  }
}

/** ادغام چند منبع هویت: اگر دو منبع مقدار متفاوت بدهند، آن مشخصه «متناقض» و نامعلوم می‌شود. */
function mergeIdentities(parts: Identity[], explicit: Partial<Record<FieldName, number | string | null>>, attrs: { label: string; value: string }[]): Identity {
  const out = emptyIdentity();
  const fields: FieldName[] = ['brand', 'model', 'ram', 'storage', 'network', 'sim', 'part', 'region', 'cpu', 'gpu', 'screen'];
  const attrVals: Partial<Record<FieldName, number | string | null>> = {};
  applyAttributes(out, attrs, attrVals);
  for (const f of fields) {
    const vals: (string | number)[] = [];
    for (const src of [explicit[f], attrVals[f]]) if (src !== undefined && src !== null && src !== '') vals.push(src);
    for (const p of parts) { const v = (p as any)[f]; if (v !== null && v !== undefined && v !== '') vals.push(v); }
    const uniq = [...new Set(vals.map(String))];
    if (uniq.length > 1) { out.conflicts.push(f); (out as any)[f] = f === 'ram' || f === 'storage' ? null : ''; if (f === 'part' || f === 'region' || f === 'network' || f === 'sim' || f === 'cpu' || f === 'gpu' || f === 'screen') (out as any)[f] = null; }
    else if (uniq.length === 1) (out as any)[f] = vals[0];
    for (const p of parts) if (p.conflicts.includes(f) && !out.conflicts.includes(f)) { out.conflicts.push(f); (out as any)[f] = f === 'model' || f === 'brand' ? '' : null; }
  }
  // نسخه‌ی مدل: از منبع هم‌مدل
  const modParts = parts.filter((p) => p.model === out.model && p.model);
  const modSets = [...new Set(modParts.map((p) => p.modifiers.join(',')))];
  if (modSets.length > 1) {
    // اگر یکی زیرمجموعه‌ی دیگری باشد (مثلاً «Air» و «Air Ultra-Slim» که دومی تبلیغاتی است)، منبع اول (نام فارسی) ملاک است
    const sets = modParts.map((p) => p.modifiers);
    const nested = sets.every((a) => sets.every((b) => a.every((x) => b.includes(x)) || b.every((x) => a.includes(x))));
    if (nested) out.modifiers = modParts[0].modifiers;
    else { out.conflicts.push('modifiers'); out.model = ''; }
  } else if (modParts.length) out.modifiers = modParts[0].modifiers;
  out.colorPhrase = parts.map((p) => p.colorPhrase).find(Boolean) || null;
  const cats = parts.map((p) => p.category).filter((c) => c !== 'other');
  out.category = cats.includes('accessory') ? 'accessory' : cats[0] || 'other';
  return out;
}

const num = (v: any): number | null => {
  if (v === undefined || v === null || v === '') return null;
  const n = parseCapacity(String(v));
  return n && n > 0 ? n : null;
};

/** هویت یک ردیف کاتالوگ تأمین‌کننده (چند فیلد عنوان + مشخصات ساختاریافته). */
export function identityFromItem(item: any, opts: { loose?: boolean } = {}): Identity {
  const titles = [item?.title, item?.name, item?.persianName, item?.product_name, item?.product_name_en, item?.short_name, item?.model]
    .map((x) => (x ? String(x) : '')).filter(Boolean);
  const uniqTitles = [...new Set(titles)];
  const parts = uniqTitles.map((t) => identityFromText(t, opts));
  const explicit: Partial<Record<FieldName, number | string | null>> = { ram: num(item?.ram), storage: num(item?.storage) };
  const sku = item?.model_code || item?.modelCode;
  if (sku) { const p = extractPart(fold(sku)).part; if (p) explicit.part = p; }
  const id = mergeIdentities(parts, explicit, readAttributes(item));
  return id;
}

/** هویت کالای ثبت‌شده‌ی خود مدیر. */
export function identityFromProduct(p: any): Identity {
  const titles = [p?.persianName, p?.name, p?.title, p?.model, p?.modelCode]
    .map((x) => (x ? String(x) : '')).filter(Boolean);
  const parts = [...new Set(titles)].map((t) => identityFromText(t));
  const explicit: Partial<Record<FieldName, number | string | null>> = { ram: num(p?.ram), storage: num(p?.storage) };
  if (p?.partNumber) { const pp = extractPart(fold(p.partNumber)).part; if (pp) explicit.part = pp; }
  if (p?.modelCode) { const pp = extractPart(fold(p.modelCode)).part; if (pp) explicit.part = pp; }
  const specs: { label: string; value: string }[] = [];
  for (const g of Array.isArray(p?.specifications) ? p.specifications : []) for (const it of g?.items || []) if (it?.label && it?.value) specs.push({ label: String(it.label), value: String(it.value) });
  for (const s of Array.isArray(p?.specsList) ? p.specsList : []) if (s?.label && s?.value) specs.push({ label: String(s.label), value: String(s.value) });
  for (const s of Array.isArray(p?.technicalSpecs) ? p.technicalSpecs : []) if (s?.label && s?.value) specs.push({ label: String(s.label), value: String(s.value) });
  return mergeIdentities(parts, explicit, specs);
}

// ----------------------------------------------------------------------------
// مقایسه
// ----------------------------------------------------------------------------

export interface CompareResult {
  verdict: 'match' | 'mismatch' | 'unknown';
  mismatches: string[];
  unknowns: string[];
  /** مشخصه‌های «نرم» (شبکه/سیم) که تأمین‌کننده ننوشته؛ با بررسی هم‌خانواده‌ها در کاتالوگ حل می‌شود */
  soft: string[];
  reasons: string[];
}

const has = (v: unknown) => v !== null && v !== undefined && v !== '';

export function compareIdentity(master: Identity, cand: Identity, rules: MatchingRules = DEFAULT_RULES): CompareResult {
  const mismatches: string[] = [], unknowns: string[] = [], soft: string[] = [], reasons: string[] = [];
  const fa = (f: string) => FIELD_FA[f] || f;

  if (master.category !== 'accessory' && cand.category === 'accessory') {
    return { verdict: 'mismatch', mismatches: ['category'], unknowns, soft, reasons: ['کالای تأمین‌کننده لوازم جانبی/قطعه است، نه خود دستگاه'] };
  }
  if (master.conflicts.length) {
    for (const f of master.conflicts) reasons.push(`مشخصات کالای شما در ${fa(f)} متناقض است (نام و توضیحات یکی نیستند)`);
    return { verdict: 'unknown', mismatches, unknowns: [...master.conflicts], soft, reasons };
  }
  const check = (f: FieldName, mv: unknown, cv: unknown, cmp: (a: any, b: any) => boolean = (a, b) => a === b) => {
    const required = rules.requiredIfMasterHas.includes(f) || (rules.requiredByCategory[master.category] || []).includes(f);
    const isSoft = rules.softFields.includes(f);
    if (cand.conflicts.includes(f)) { unknowns.push(f); reasons.push(`در عنوان/مشخصات تأمین‌کننده ${fa(f)} متناقض است`); return; }
    if (has(mv) && has(cv)) { if (!cmp(mv, cv)) { mismatches.push(f); reasons.push(`${fa(f)} برابر نیست: ${mv} ≠ ${cv}`); } return; }
    if (has(mv) && !has(cv)) {
      if (isSoft) { soft.push(f); return; }
      if (required || f === 'brand' || f === 'model') { unknowns.push(f); reasons.push(`تأمین‌کننده ${fa(f)} را ننوشته است`); }
      return;
    }
    if (!has(mv) && has(cv)) {
      if ((rules.requiredByCategory[master.category] || []).includes(f)) { unknowns.push(f); reasons.push(`${fa(f)} کالای شما ثبت/تشخیص داده نشد`); }
      return;
    }
    if (!has(mv) && !has(cv) && (rules.requiredByCategory[master.category] || []).includes(f)) { soft.push(f); }
  };

  check('brand', master.brand, cand.brand);
  if (!has(master.model)) { unknowns.push('model'); reasons.push('مدل کالای شما از نام آن قابل تشخیص نیست'); }
  else check('model', master.model, cand.model);
  if (has(master.model) && has(cand.model) && master.model === cand.model) {
    if (master.modifiers.join(',') !== cand.modifiers.join(',')) {
      mismatches.push('modifiers');
      reasons.push(`نسخه‌ی مدل برابر نیست: «${master.modifiers.join(' ') || 'استاندارد'}» ≠ «${cand.modifiers.join(' ') || 'استاندارد'}»`);
    }
  }
  check('ram', master.ram, cand.ram);
  check('storage', master.storage, cand.storage);
  check('network', master.network, cand.network);
  check('sim', master.sim, cand.sim);
  check('part', master.part, cand.part, (a, b) => String(a).toUpperCase() === String(b).toUpperCase());
  check('region', master.region, cand.region);
  check('cpu', master.cpu, cand.cpu);
  check('gpu', master.gpu, cand.gpu);
  check('screen', master.screen, cand.screen);

  // برچسب‌های ساختاریافته‌ی دلخواه (هر مشخصه‌ای که مدیر در قوانین معرفی کرده)
  for (const raw of rules.identityLabels) {
    const label = canonicalLabel(raw);
    if (['ram', 'storage', 'network', 'sim', 'part', 'region', 'cpu', 'gpu', 'screen'].includes(label)) continue;
    const a = master.attrs[label], b = cand.attrs[label];
    if (has(a) && has(b) && a !== b) { mismatches.push(label); reasons.push(`«${raw}» برابر نیست: ${a} ≠ ${b}`); }
    else if (has(a) && !has(b)) { unknowns.push(label); reasons.push(`تأمین‌کننده «${raw}» را ننوشته است`); }
  }

  const verdict = mismatches.length ? 'mismatch' : unknowns.length ? 'unknown' : 'match';
  return { verdict, mismatches, unknowns, soft, reasons };
}

/** یک شناسه‌ی پایدار از هویت (برای کش و گروه‌بندی) */
export const identityKey = (id: Identity): string =>
  [id.brand, id.model, id.modifiers.join('+'), id.ram ?? '', id.storage ?? '', id.network ?? '', id.sim ?? '', id.part ?? '', id.region ?? '', id.cpu ?? '', id.gpu ?? '', id.screen ?? ''].join('|');
