import { scrubSensitiveFields } from './securitySanitizers.js';

// These fields describe supplier-side pricing/matching and must never be exposed
// in customer-facing product JSON, including when nested inside color variants.
const INTERNAL_SUPPLIER_FIELDS = new Set([
  'sourceprice', 'syncedprice', 'approvedsourceprice', 'referencesupplierid',
  'referencesuppliername', 'suppliername', 'suppliermatches', 'pricejumpheldsource',
  'supplierid', 'supplierproductid', 'supplierprice', 'usedforsiteprice',
]);

function removeInternalSupplierFields(value: any): any {
  if (Array.isArray(value)) return value.map(removeInternalSupplierFields);
  if (!value || typeof value !== 'object') return value;
  const out: Record<string, any> = {};
  for (const [key, item] of Object.entries(value)) {
    const normalizedKey = key.replace(/[^a-z0-9]/gi, '').toLowerCase();
    if (INTERNAL_SUPPLIER_FIELDS.has(normalizedKey)) continue;
    out[key] = removeInternalSupplierFields(item);
  }
  return out;
}

/** Safe product projection for public APIs and assistant responses. */
export function publicProductView(product: any, adminView = false): any {
  if (!product || typeof product !== 'object' || Array.isArray(product)) return null;
  const copy = scrubSensitiveFields(product);
  return adminView ? copy : removeInternalSupplierFields(copy);
}
