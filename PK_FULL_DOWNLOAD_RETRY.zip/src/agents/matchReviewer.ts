// ایجنت تطبیق محلی: deterministic، قابل ممیزی و بدون سرویس هوش مصنوعی خارجی.
import { identityOfProduct, identityOfItem, loadMatchingRules } from '../supplierEngine.js';
import { compareIdentity } from '../identity.js';
import { readJson, loadCatalogs, saveReport } from './common.js';
import type { AgentAlert } from './common.js';

const itemText = (i: any) => i.title || i.name || i.product_name_en || i.persianName || i.product_name || '';

// پیشنهاد فقط برای ردیف‌هایی که مدل/نسخه/رم/حافظه‌شان با کالای ما نمی‌خواند «ردّ» نشده باشد.
// verdict=match یعنی همه‌ی مشخصات برابر؛ unknown یعنی مشخصه‌ای در عنوان تأمین‌کننده نیست (نیازمند بررسی انسان).
function scoreCandidate(master: any, item: any, rules: ReturnType<typeof loadMatchingRules>) {
  const cmp = compareIdentity(identityOfProduct(master), identityOfItem(item), rules);
  const score = cmp.verdict === 'match' ? 0.95 : cmp.verdict === 'unknown' ? 0.6 : 0;
  return { cmp, score };
}

export async function runMatchReviewer(opts: { productIds?: string[]; catalogs?: Awaited<ReturnType<typeof loadCatalogs>> } = {}) {
  const products = readJson<any[]>('products.json', []).filter((p) => p.active !== false && (!opts.productIds || opts.productIds.includes(p.id)));
  const catalogs = opts.catalogs ?? (await loadCatalogs());
  const alerts: AgentAlert[] = [], suggestions: any[] = [];

  for (const p of products) for (const { supplier, adapter, items, error } of catalogs) {
    if (error || !items.length) continue;
    const current = adapter.matchProduct(p, items);
    const rules = loadMatchingRules();
    if (current && (current.confidence === 'exact' || current.confidence === 'high')) continue;
    const cands = items.map((item) => ({ item, ...scoreCandidate(p, item, rules) }))
      .filter((c) => c.score > 0)
      .sort((a, b) => b.score - a.score).slice(0, 5);
    if (!cands.length) continue;
    const pick = cands[0];
    const status = pick.score >= 0.9 ? 'high_confidence_review' : 'needs_review';
    const s = { productId: p.id, productName: p.name, supplierId: supplier.id, supplierName: supplier.name, candidate: itemText(pick.item), candidateId: pick.item.id ?? null,
      confidence: Number(pick.score.toFixed(2)), method: 'local-rule-engine', reason: pick.cmp.reasons.join('؛ ') || 'همه‌ی مشخصات هم‌خوان است', status };
    suggestions.push(s);
    alerts.push({ key: `match:${p.id}:${supplier.id}`, type: 'match_suggestion', severity: status === 'high_confidence_review' ? 'warning' : 'info', message: `برای «${p.name}» در ${supplier.name} پیشنهاد: «${s.candidate}» (اطمینان ${Math.round(s.confidence * 100)}٪، موتور قاعده‌ای)`, data: s });
  }
  return saveReport({ agent: 'matchReviewer', summary: suggestions.length ? `${suggestions.length} پیشنهاد تطبیق برای بازبینی` : 'تطبیق مبهمی پیدا نشد.', alerts, data: { suggestions } });
}
