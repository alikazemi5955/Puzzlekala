import fs from 'fs';
import path from 'path';
import https from 'https';
import http from 'http';
import {
  identityFromItem, identityFromProduct, compareIdentity, mapColors, colorKey, colorFromTokens, tokenize,
  DEFAULT_RULES, FIELD_FA,
} from './identity.js';
import type { Identity, MatchingRules } from './identity.js';

import { DATA_DIR } from './paths.js';
import { classifyProduct } from './productClassifier.js';
import { createHash } from 'crypto';

// ============================================================================
// 1. Types & Interfaces (Multi-Supplier Architecture)
// ============================================================================

export interface Supplier {
  id: string;
  name: string;
  enabled: boolean;
  baseUrl: string;
  connectionType: 'api_feed' | 'rest_api' | 'json_feed' | 'graphql';
  lastSyncAt: string | null;
  lastSuccessAt: string | null;
  lastError: string | null;
  status: 'connected' | 'disconnected' | 'error' | 'unavailable';
  sourceTotalProducts?: number;
  sourceInStockProducts?: number;
  sourceOutOfStockProducts?: number;
  matchedCount: number;
  ambiguousCount: number;
  variantsCount: number;
  inStockColorsCount: number;
  username?: string;
  password?: string;
  apiKey?: string;
}

export interface SupplierVariant {
  sourceVariantId?: string | number;
  colorName: string;
  normalizedColorName: string;
  sourcePrice: number;
  inStock: boolean;
  stock?: number;
  sourceUpdatedAt?: string;
}

export interface SupplierProductMatch {
  supplierId: string;
  supplierProductId?: string | number;
  sku?: string;
  barcode?: string;
  modelCode?: string;
  normalizedIdentity: string;
  variants: SupplierVariant[];
  confidence: 'exact' | 'high' | 'ambiguous' | 'none';
  matchReason?: string;
  /** شناسه‌ی همه‌ی ردیف‌های تأمین‌کننده که در این تطبیق مصرف شده‌اند */
  itemIds?: string[];
  candidates?: { id?: string | number; title: string; price?: number; color?: string; variants?: any[]; why?: string }[];
}

export interface SupplierAdapter {
  id: string;
  name: string;
  fetchCatalog(supplier: Supplier): Promise<{ success: boolean; items: any[]; error?: string }>;
  matchProduct(masterProduct: any, supplierItems: any[], index?: SupplierCatalogIndex): SupplierProductMatch | null;
}

export interface AuditLogEntry {
  id: string;
  action: string;
  details: string;
  actor: string;
  metadata?: any;
  timestamp: string;
}

export interface SupplierCatalogIndex {
  idMap: Map<string, any>;
  items: any[];
}



// ============================================================================
// 2. Safe JSON Helpers & Audit Log (Rule 20, 21 - Max 1000 Records, No Secrets)
// ============================================================================

export function readJsonFile<T>(filePath: string, fallback: T): T {
  if (!fs.existsSync(filePath)) return fallback;
  let content = '';
  try {
    content = fs.readFileSync(filePath, 'utf-8');
  } catch (err: any) {
    console.error(`[SupplierEngine] Failed to read JSON file ${filePath}:`, err?.message || err);
    return fallback;
  }
  if (!content.trim()) {
    // Preserve an empty file as a recoverable artifact rather than silently treating
    // it as valid empty data; the next intentional write may then create a fresh file.
    try { fs.renameSync(filePath, `${filePath}.empty.${process.pid}.${Date.now()}`); }
    catch (err: any) { console.error(`[SupplierEngine] Could not preserve empty JSON file ${filePath}:`, err?.message || err); }
    return fallback;
  }
  try {
    return JSON.parse(content) as T;
  } catch (err: any) {
    // Do not let a later read-modify-write operation silently overwrite corrupted data.
    const backupPath = `${filePath}.corrupt.${process.pid}.${Date.now()}`;
    try {
      fs.renameSync(filePath, backupPath);
      console.error(`[SupplierEngine] Invalid JSON preserved at ${backupPath}; using fallback for this read.`);
    } catch (preserveErr: any) {
      console.error(`[SupplierEngine] Invalid JSON in ${filePath}; preservation failed:`, preserveErr?.message || preserveErr);
    }
    return fallback;
  }
}

export function writeJsonFile<T>(filePath: string, data: T): boolean {
  try {
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const tempFile = `${filePath}.tmp.${process.pid}.${Date.now()}.${Math.random().toString(36).slice(2, 10)}`;
    fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), 'utf-8');
    fs.renameSync(tempFile, filePath);
    return true;
  } catch (err) {
    console.error(`[SupplierEngine] Failed to write JSON to ${filePath}:`, err);
    return false;
  }
}

export function recordAuditLog(
  action: string,
  details: string,
  actor: string = 'system',
  metadata?: any
): void {
  try {
    const auditFile = path.join(DATA_DIR, 'audit_logs.json');
    const logs = readJsonFile<AuditLogEntry[]>(auditFile, []);

    // Redact sensitive fields recursively; audit metadata may contain nested payloads.
    const sensitiveKey = (key: string) => /(password|passwd|salt|token|secret|api.?key|authorization|credential|cookie)/i.test(key);
    const sanitizeMeta = (value: any, depth = 0): any => {
      if (depth > 8 || value === null || typeof value !== 'object') return value;
      if (Array.isArray(value)) return value.slice(0, 500).map((item) => sanitizeMeta(item, depth + 1));
      const out: Record<string, any> = {};
      for (const [key, item] of Object.entries(value)) {
        if (sensitiveKey(key)) continue;
        out[key] = sanitizeMeta(item, depth + 1);
      }
      return out;
    };
    const sanitizedMeta = metadata && typeof metadata === 'object' ? sanitizeMeta(metadata) : metadata;

    const entry: AuditLogEntry = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      action,
      details,
      actor,
      metadata: sanitizedMeta,
      timestamp: new Date().toISOString(),
    };

    logs.unshift(entry);

    if (logs.length > 1000) {
      logs.splice(1000);
    }

    writeJsonFile(auditFile, logs);
  } catch {
    // Non-blocking
  }
}



// ============================================================================
// 3. Normalizers
// ============================================================================

export function normalizeText(text?: string | null): string {
  if (!text) return '';
  return text
    .toString()
    .toLowerCase()
    .replace(/[\u200B-\u200D\uFEFF]/g, '') // remove zero-width chars
    .replace(/[ي]/g, 'ی')
    .replace(/[ك]/g, 'ک')
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 1776))
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 1632))
    .replace(/[\/\-_,.:;+()\[\]{}|\\!@#$%^&*~`]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** رنگ را به شکل استاندارد (کلید مقایسه) برمی‌گرداند؛ برای نمایش، نام اصلی حفظ می‌شود. */
export function normalizeColor(rawColor?: string | null): string {
  if (!rawColor) return '';
  const k = colorKey(rawColor);
  return k || String(rawColor).trim();
}

/** رنگ را از عنوان کالا (آخرین دنباله‌ی واژه‌های رنگ) می‌خواند. */
export function extractColorFromTitle(title?: string | null): string | null {
  if (!title) return null;
  return colorFromTokens(tokenize(String(title)));
}


// ============================================================================
// 4. HTTP Fetcher with Independent Timeout (Rule 26)
// ============================================================================

function fetchJson<T>(url: string, timeoutMs: number = 5000): Promise<{ data: T | null; error?: string }> {
  return new Promise((resolve) => {
    try {
      const parsedUrl = new URL(url);
      if (!['https:', 'http:'].includes(parsedUrl.protocol)) return resolve({ data: null, error: 'پروتکل URL تأمین‌کننده مجاز نیست.' });
      if (parsedUrl.username || parsedUrl.password) return resolve({ data: null, error: 'URL تأمین‌کننده نباید شامل credential باشد.' });
      const isHttps = parsedUrl.protocol === 'https:';
      const client = isHttps ? https : http;

      const req = client.get(
        url,
        {
          headers: {
            'User-Agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            Accept: 'application/json, text/plain, */*',
          },
          timeout: timeoutMs,
        },
        (res) => {
          if (res.statusCode && (res.statusCode < 200 || res.statusCode >= 300)) {
            res.resume();
            return resolve({
              data: null,
              error: `HTTP ${res.statusCode} ${res.statusMessage || ''}`,
            });
          }

          let raw = '';
          let bytes = 0;
          const maxBytes = 8 * 1024 * 1024;
          res.setEncoding('utf-8');
          res.on('data', (chunk) => {
            bytes += Buffer.byteLength(String(chunk), 'utf8');
            if (bytes > maxBytes) {
              req.destroy();
              return resolve({ data: null, error: 'پاسخ تأمین‌کننده بیش از حد بزرگ است.' });
            }
            raw += chunk;
          });
          res.on('end', () => {
            try {
              const parsed = JSON.parse(raw);
              resolve({ data: parsed });
            } catch (err: any) {
              resolve({ data: null, error: `پاسخ نامعتبر JSON: ${err.message}` });
            }
          });
        }
      );

      req.on('timeout', () => {
        req.destroy();
        resolve({ data: null, error: `اتصال به تأمین‌کننده به پایان مهلت (${timeoutMs}ms) رسید` });
      });

      req.on('error', (err) => {
        resolve({ data: null, error: err.message || 'خطا در ارتباط شبکه' });
      });
    } catch (err: any) {
      resolve({ data: null, error: err.message || 'نشانی نامعتبر' });
    }
  });
}


// ============================================================================
// 5. Suppliers Management (Rule 3 & 13)
// ============================================================================

const DEFAULT_SUPPLIERS: Supplier[] = [
  {
    id: 'kasra',
    name: 'کسری پلاس (Kasra Plus)',
    enabled: true,
    baseUrl: 'https://api.kasrapars.ir/api/web/v10/product/index?per-page=100',
    connectionType: 'api_feed',
    lastSyncAt: null,
    lastSuccessAt: null,
    lastError: null,
    status: 'unavailable',
    sourceTotalProducts: 0,
    sourceInStockProducts: 0,
    sourceOutOfStockProducts: 0,
    matchedCount: 0,
    ambiguousCount: 0,
    variantsCount: 0,
    inStockColorsCount: 0,
  },
  {
    id: 'hamrahtel',
    name: 'همراه تل (Hamrah Tel)',
    enabled: true,
    baseUrl: 'https://core-api.hamrahtel.com/graphql/',
    connectionType: 'graphql',
    lastSyncAt: null,
    lastSuccessAt: null,
    lastError: null,
    status: 'unavailable',
    sourceTotalProducts: 0,
    sourceInStockProducts: 0,
    sourceOutOfStockProducts: 0,
    matchedCount: 0,
    ambiguousCount: 0,
    variantsCount: 0,
    inStockColorsCount: 0,
  },
  {
    id: 'ehadish',
    name: 'هدیش (Ehadish)',
    enabled: true,
    baseUrl: 'https://www.ehadish.com/',
    connectionType: 'api_feed',
    lastSyncAt: null,
    lastSuccessAt: null,
    lastError: null,
    status: 'unavailable',
    sourceTotalProducts: 0,
    sourceInStockProducts: 0,
    sourceOutOfStockProducts: 0,
    matchedCount: 0,
    ambiguousCount: 0,
    variantsCount: 0,
    inStockColorsCount: 0,
  },
];

export function getSuppliersList(): Supplier[] {
  const filePath = path.join(DATA_DIR, 'suppliers.json');
  let sups = readJsonFile<Supplier[]>(filePath, []);
  if (!Array.isArray(sups) || sups.length === 0) {
    saveSuppliersList(DEFAULT_SUPPLIERS);
    return DEFAULT_SUPPLIERS;
  }
  let modified = false;
  for (const def of DEFAULT_SUPPLIERS) {
    if (!sups.some((s) => s.id === def.id)) {
      sups.push({ ...def });
      modified = true;
    }
  }
  if (modified) {
    saveSuppliersList(sups);
  }
  return sups;
}

export function saveSuppliersList(suppliers: Supplier[]): void {
  const filePath = path.join(DATA_DIR, 'suppliers.json');
  writeJsonFile(filePath, suppliers);
}


// ============================================================================
// 6. Universal Supplier Adapter (تطبیق چندمشخصه‌ی دقیق بر پایه‌ی هویت کالا)
// ============================================================================

let currentRules: MatchingRules = DEFAULT_RULES;

/** قوانین تطبیق: پیش‌فرض + فایل اختیاری data/matching-rules.json */
export function loadMatchingRules(): MatchingRules {
  const f = readJsonFile<Partial<MatchingRules>>(path.join(DATA_DIR, 'matching-rules.json'), {});
  return {
    ...DEFAULT_RULES,
    ...f,
    requiredIfMasterHas: Array.isArray(f.requiredIfMasterHas) ? f.requiredIfMasterHas : DEFAULT_RULES.requiredIfMasterHas,
    softFields: Array.isArray(f.softFields) ? f.softFields : DEFAULT_RULES.softFields,
    identityLabels: Array.isArray(f.identityLabels) ? f.identityLabels : DEFAULT_RULES.identityLabels,
    requiredByCategory: { ...DEFAULT_RULES.requiredByCategory, ...(f.requiredByCategory || {}) },
  };
}

const productIdentityCache = new WeakMap<object, Identity>();
const itemIdentityCache = new WeakMap<object, Identity>();
export const identityOfProduct = (p: any): Identity => {
  let id = productIdentityCache.get(p);
  if (!id) { id = identityFromProduct(p); productIdentityCache.set(p, id); }
  return id;
};
export const identityOfItem = (it: any): Identity => {
  let id = itemIdentityCache.get(it);
  if (!id) { id = identityFromItem(it); itemIdentityCache.set(it, id); }
  return id;
};

const DEFAULT_COLOR_NAMES = new Set(['پیش‌فرض', 'پیشفرض', 'پیش فرض', 'default', 'عمومی', 'بدون رنگ', '']);
const isDefaultColor = (name: string) => DEFAULT_COLOR_NAMES.has(String(name || '').trim().toLowerCase());
const titleOf = (it: any) => String(it?.title || it?.name || it?.product_name_en || it?.product_name || it?.persianName || '').slice(0, 160);

/** واریانت‌های رنگی یک یا چند ردیف هم‌هویت تأمین‌کننده؛ رنگ خالی یعنی «قیمت برای همه‌ی رنگ‌ها» */
function buildVariants(sourceItems: any[]): SupplierVariant[] {
  const variants: SupplierVariant[] = [];
  const now = new Date().toISOString();
  for (const sourceItem of sourceItems) {
    const rawPrice = Number(sourceItem.price || sourceItem.sell_price || sourceItem.sourcePrice || (sourceItem.product_variants && sourceItem.product_variants[0]?.price) || 0);
    const itemStock = sourceItem.stock !== undefined && sourceItem.stock !== null && sourceItem.stock !== '' ? Number(sourceItem.stock) : undefined;
    const list: any[] = Array.isArray(sourceItem.variants) && sourceItem.variants.length > 0 ? sourceItem.variants
      : Array.isArray(sourceItem.colors) && sourceItem.colors.length > 0 ? sourceItem.colors : [];
    if (list.length > 0) {
      for (const v of list) {
        const colName = typeof v === 'string' ? v : v.color || v.color_name || v.name || v.title || '';
        const colPrice = Number((typeof v === 'object' && (v.price || v.sell_price || v.sourcePrice)) || rawPrice);
        const vStock = typeof v === 'object' && v.stock !== undefined && v.stock !== null && v.stock !== '' ? Number(v.stock) : undefined;
        const inStock = typeof v === 'object'
          ? (vStock !== undefined ? vStock > 0 : v.inStock !== undefined ? Boolean(v.inStock) : v.is_available !== undefined ? Boolean(v.is_available) : true)
          : true;
        variants.push({
          sourceVariantId: typeof v === 'object' ? v.id : undefined,
          colorName: isDefaultColor(colName) ? '' : String(colName),
          normalizedColorName: isDefaultColor(colName) ? '' : colorKey(String(colName)),
          sourcePrice: colPrice,
          inStock,
          stock: vStock,
          sourceUpdatedAt: now,
        });
      }
    } else if (rawPrice > 0) {
      // ردیف بدون واریانت: رنگ از عنوان خوانده می‌شود؛ اگر نبود، قیمت برای همه‌ی رنگ‌هاست
      const phrase = identityOfItem(sourceItem).colorPhrase || '';
      const inStock = itemStock !== undefined ? itemStock > 0 : sourceItem.inStock !== undefined ? Boolean(sourceItem.inStock) : sourceItem.is_available === false || sourceItem.no_longer_available === true ? false : true;
      variants.push({
        colorName: phrase,
        normalizedColorName: phrase ? colorKey(phrase) : '',
        sourcePrice: rawPrice,
        inStock,
        stock: itemStock,
        sourceUpdatedAt: now,
      });
    }
  }
  return variants;
}

function buildMatch(sourceItems: any[], supplierId: string, confidence: 'exact' | 'high' | 'ambiguous', reason?: string): SupplierProductMatch {
  const first = sourceItems[0] || {};
  return {
    supplierId,
    supplierProductId: first.id || first.product_id,
    sku: first.sku,
    barcode: first.barcode || first.gtin,
    modelCode: first.model_code,
    normalizedIdentity: normalizeText(titleOf(first)),
    variants: buildVariants(sourceItems),
    confidence,
    matchReason: reason,
    itemIds: sourceItems.map((x) => String(x.id ?? x.product_id ?? '')).filter(Boolean),
  };
}

const candidateRow = (it: any, why: string) => {
  const variants = buildVariants([it]).filter((v) => v.colorName).map((v) => ({ name: v.colorName, price: v.sourcePrice, stock: v.stock }));
  const price = Number(it.price || it.sell_price || it.sourcePrice || (it.variants && it.variants[0]?.price) || 0) || undefined;
  return { id: it.id, title: titleOf(it), price, color: identityOfItem(it).colorPhrase || variants.map((v) => v.name).join('، ') || 'پیش‌فرض / نامشخص', variants, why };
};

export const UniversalSupplierAdapter: SupplierAdapter = {
  id: 'universal',
  name: 'تأمین‌کننده عمومی استاندارد',

  async fetchCatalog(supplier: Supplier): Promise<{ success: boolean; items: any[]; error?: string }> {
    if (!supplier.enabled) {
      return { success: false, items: [], error: 'تأمین‌کننده غیرفعال است' };
    }
    const res = await fetchJson<any>(supplier.baseUrl, 5000);
    if (!res.data) {
      return { success: false, items: [], error: res.error || `خطا در استعلام از ${supplier.name}` };
    }
    let items: any[] = [];
    if (res.data.dataProvider && Array.isArray(res.data.dataProvider.items)) items = res.data.dataProvider.items;
    else if (Array.isArray(res.data.items)) items = res.data.items;
    else if (Array.isArray(res.data.products)) items = res.data.products;
    else if (Array.isArray(res.data.data)) items = res.data.data;
    else if (Array.isArray(res.data)) items = res.data;
    return { success: true, items };
  },

  matchProduct(masterProduct: any, supplierItems: any[], index?: SupplierCatalogIndex): SupplierProductMatch | null {
    if (!masterProduct || !supplierItems || supplierItems.length === 0) return null;
    const rules = currentRules;
    const master = identityOfProduct(masterProduct);
    // الف-۱) کالای ساخته‌شده‌ی خودکار از همین تأمین‌کننده (غیرگوشی): پیوند مستقیم با ردیف‌هایی که از آن ساخته شده
    const auto = masterProduct.autoCreated ? masterProduct.supplierMatches?.[this.id] : null;
    if (auto && Array.isArray(auto.itemIds)) {
      const rows = auto.itemIds.map((k: string) => (index && index.idMap.get(String(k))) || supplierItems.find((it) => String(it.id ?? it.product_id) === String(k))).filter(Boolean);
      return buildMatch(rows, this.id, 'exact', rows.length ? 'کالای ساخته‌شده‌ی خودکار از همین تأمین‌کننده' : 'ردیف تأمین‌کننده دیگر در کاتالوگ نیست');
    }

    // مدل کالای خودِ مدیر قابل تشخیص یا بدون تناقض نیست: هیچ تطبیق خودکاری انجام نمی‌شود (در فهرست «مشکل مشخصات کالا» گزارش می‌شود)
    if (!master.model || master.conflicts.length) {
      const manualOnly = masterProduct.supplierMatches?.[this.id]?.confirmedBy === 'admin';
      if (!manualOnly) return null;
    }

    // الف) تأیید دستی مدیر (از «پنل تأمین‌کنندگان ← تأیید تطبیق»): فقط اگر مشخصات صریحاً متناقض نباشد
    const manual = masterProduct.supplierMatches?.[this.id];
    if (manual && manual.confirmedBy === 'admin' && manual.supplierProductId) {
      const key = String(manual.supplierProductId).trim();
      const item = (index && index.idMap.get(key)) || supplierItems.find((it) => String(it.id ?? it.product_id) === key);
      if (item) {
        const cmp = compareIdentity(master, identityOfItem(item), rules);
        if (cmp.verdict === 'mismatch') {
          const m = buildMatch([item], this.id, 'ambiguous', `تأیید دستی مدیر با مشخصات کالا نمی‌خواند: ${cmp.reasons.join('؛ ')}`);
          m.candidates = [candidateRow(item, cmp.reasons.join('؛ '))];
          return m;
        }
        return buildMatch([item], this.id, 'exact', 'تأیید دستی مدیر');
      }
    }

    // ب) مقایسه‌ی همه‌ی مشخصات با تک‌تک ردیف‌های تأمین‌کننده
    const evals = supplierItems.map((it) => {
      const cId = identityOfItem(it);
      return { it, cId, cmp: compareIdentity(master, cId, rules) };
    });

    // مشخصه‌های «نرم» (شبکه/سیم یا رم‌ِ ننوشته‌ی هر دو طرف): فقط وقتی مشکل‌اند که تأمین‌کننده ردیف هم‌خانواده‌ی متفاوتی هم داشته باشد
    const onlyFields = (mm: string[], fields: string[]) => mm.length > 0 && mm.every((f) => fields.includes(f));
    const soft = new Set<string>(rules.softFields);
    const fullMatches: typeof evals = [];
    const nearMiss: { e: (typeof evals)[number]; why: string }[] = [];
    for (const e of evals) {
      if (e.cmp.verdict === 'unknown') { nearMiss.push({ e, why: e.cmp.reasons.join('؛ ') }); continue; }
      if (e.cmp.verdict !== 'match') continue;
      let conflict = '';
      for (const f of e.cmp.soft) {
        const key = f as keyof Identity;
        const sibling = evals.find((o) => o !== e && o.cId[key] !== null && o.cId[key] !== '' && o.cId[key] !== undefined &&
          o.cmp.mismatches.length > 0 && onlyFields(o.cmp.mismatches, [...soft, f]) && o.cmp.mismatches.includes(f));
        if (sibling) conflict = `تأمین‌کننده ${FIELD_FA[f] || f} را ننوشته و ردیف دیگری با ${FIELD_FA[f] || f} متفاوت هم دارد`;
      }
      if (conflict) nearMiss.push({ e, why: conflict }); else fullMatches.push(e);
    }

    if (fullMatches.length === 0) {
      if (nearMiss.length === 0) return null;
      const m = buildMatch([nearMiss[0].e.it], this.id, 'ambiguous', `مشخصات کالای تأمین‌کننده کامل نیست؛ برای اطمینان قیمت اعمال نشد (${nearMiss[0].why})`);
      m.candidates = nearMiss.slice(0, 5).map((n) => candidateRow(n.e.it, n.why));
      return m;
    }
    const reason = fullMatches.length === 1
      ? 'تطبیق همه‌ی مشخصات (برند، مدل، نسخه، رم، حافظه و ...)'
      : `${fullMatches.length} ردیف هم‌هویت (احتمالاً رنگ‌های جدا) ادغام شد`;
    return buildMatch(fullMatches.map((e) => e.it), this.id, 'high', reason);
  },
};


export const KasraAdapter: SupplierAdapter = {
  ...UniversalSupplierAdapter,
  id: 'kasra',
  name: 'کسری پلاس (Kasra Plus)',
  async fetchCatalog(supplier: Supplier): Promise<{ success: boolean; items: any[]; error?: string }> {
    // Kasra uses page-based pagination. Fetch the complete catalog instead of silently
    // syncing only the first 100 records. We keep a hard page cap and stop on repeated
    // pages so a broken/ignored pagination parameter cannot create an infinite loop.
    const PAGE_SIZE = 100;
    const MAX_PAGES = 1000;
    const allItems: any[] = [];
    const seenIds = new Set<string>();
    let page = 1;

    while (page <= MAX_PAGES) {
      const base = new URL(supplier.baseUrl);
      base.searchParams.set('per-page', String(PAGE_SIZE));
      base.searchParams.set('page', String(page));

      const res = await fetchJson<any>(base.toString(), 8000);
      if (!res.data) {
        return {
          success: false,
          items: [],
          error: res.error || `خطا در دریافت صفحه ${page} از ${supplier.name}`,
        };
      }

      let pageItems: any[] = [];
      if (res.data.dataProvider && Array.isArray(res.data.dataProvider.items)) {
        pageItems = res.data.dataProvider.items;
      } else if (Array.isArray(res.data.items)) {
        pageItems = res.data.items;
      } else if (Array.isArray(res.data.products)) {
        pageItems = res.data.products;
      } else if (Array.isArray(res.data.data)) {
        pageItems = res.data.data;
      } else if (Array.isArray(res.data)) {
        pageItems = res.data;
      }

      if (pageItems.length === 0) break;

      let addedThisPage = 0;
      for (const item of pageItems) {
        const key = String(item?.id ?? item?.product_id ?? item?.sku ?? JSON.stringify(item));
        if (!seenIds.has(key)) {
          seenIds.add(key);
          allItems.push(item);
          addedThisPage++;
        }
      }

      // If the source ignores `page` and keeps returning the same page, stop safely.
      if (addedThisPage === 0) break;

      // A short page is the normal end-of-catalog signal.
      if (pageItems.length < PAGE_SIZE) break;
      page++;
    }

    if (page > MAX_PAGES) {
      return {
        success: false,
        items: [],
        error: `تعداد صفحات کاتالوگ کسری از سقف ایمن ${MAX_PAGES} صفحه بیشتر شد؛ همگام‌سازی متوقف شد تا داده ناقص جایگزین نشود.`,
      };
    }

    const normalizedItems = allItems.map((it: any) => {
      // موجودی از اطلاعات ارسالی وب‌سرویس تأمین‌کننده سنجیده می‌شود
      const variantsArr = [...(Array.isArray(it.variants) ? it.variants : []), ...(Array.isArray(it.colors) ? it.colors : [])];
      const anyVariantStock = variantsArr.some((v: any) => v && (v.inStock === true || Number(v.stock) > 0));
      const isUnavailable = it.no_longer_available === true || it.is_available === false || it.is_available === 0 || it.site_visible === 0;
      const numericStock = it.stock !== undefined && it.stock !== null && it.stock !== '' ? Number(it.stock) : undefined;
      const hasNumericStock = numericStock !== undefined && !Number.isNaN(numericStock);
      const price = Number(it.price || it.sell_price || it.sourcePrice || 0);

      const isVisible: boolean = hasNumericStock
        ? (numericStock as number) > 0 && !isUnavailable
        : anyVariantStock
          ? !isUnavailable
          : (it.site_visible !== 0 && !isUnavailable);

      const name = it.product_name || it.product_name_en || it.short_name || it.name || it.title || '';
      const nameEn = it.product_name_en || it.name_en || '';
      const image = it.src || it.image || '';

      return {
        ...it,
        id: it.id,
        name,
        title: name,
        persianName: name,
        nameEn,
        inStock: isVisible,
        stock: hasNumericStock ? Math.max(0, numericStock as number) : anyVariantStock && isVisible ? 1 : 0,
        is_available: !isUnavailable,
        site_visible: it.site_visible !== undefined ? it.site_visible : isVisible ? 1 : 0,
        price,
        image,
        images: image ? [image] : [],
        supplierId: 'kasra',
        supplierName: 'کسری پلاس (Kasra Plus)',
      };
    });

    return { success: true, items: normalizedItems };
  },
};

let hamrahTelTokenCache: { token: string; expiresAt: number } | null = null;

export function clearHamrahTelTokenCache() {
  hamrahTelTokenCache = null;
}

async function getHamrahTelAuthToken(supplier?: Supplier): Promise<string | null> {
  const now = Date.now();
  if (hamrahTelTokenCache && hamrahTelTokenCache.expiresAt > now + 60000) {
    return hamrahTelTokenCache.token;
  }

  const url = supplier?.baseUrl && supplier.baseUrl.includes('graphql') ? supplier.baseUrl : 'https://core-api.hamrahtel.com/graphql/';
  const query = `
    mutation TokenCreate($phoneNumber: String!, $password: String!) {
      tokenCreate(phoneNumber: $phoneNumber, password: $password) {
        token
        errors {
          message
        }
      }
    }
  `;
  const phoneNumber = supplier?.username || process.env.HAMRAHTEL_PHONE;
  const password = supplier?.password || process.env.HAMRAHTEL_PASSWORD;
  if (!phoneNumber || !password) return null;
  const body = JSON.stringify({
    query,
    variables: { phoneNumber, password },
  });

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
      },
      body,
    });
    const data = (await res.json()) as any;
    const token = data?.data?.tokenCreate?.token;
    if (token) {
      hamrahTelTokenCache = { token, expiresAt: now + 7 * 24 * 3600 * 1000 };
      return token;
    }
  } catch (err) {
    console.error('Hamrah Tel Auth Error:', err);
  }
  return null;
}

export const HamrahTelAdapter: SupplierAdapter = {
  ...UniversalSupplierAdapter,
  id: 'hamrahtel',
  name: 'همراه تل (Hamrah Tel)',
  async fetchCatalog(supplier: Supplier) {
    if (!supplier.enabled) {
      return { success: false, items: [], error: 'تأمین‌کننده غیرفعال است' };
    }

    try {
      const token = await getHamrahTelAuthToken(supplier);
      if (!token) {
        return {
          success: false,
          items: [],
          error: 'خطا در احراز هویت با نام کاربری و رمز عبور همراه تل',
        };
      }

            // Fetch mobile category (140+ phones) + root products + targeted searches for current store products
      const queryCombined = `
        query GetCombinedProducts($first: Int!) {
          mobileCategory: category(slug: "mobile") {
            products(first: $first) {
              edges {
                node {
                  id
                  name
                  slug
                  thumbnail {
                    url
                  }
                  variants {
                    id
                    name
                    sku
                    pricing {
                      price {
                        gross {
                          amount
                          currency
                        }
                      }
                    }
                    quantityAvailable
                  }
                }
              }
            }
          }
          rootProducts: products(first: $first) {
            edges {
              node {
                id
                name
                slug
                thumbnail {
                  url
                }
                variants {
                  id
                  name
                  sku
                  pricing {
                    price {
                      gross {
                        amount
                        currency
                      }
                    }
                  }
                  quantityAvailable
                }
              }
            }
          }
        }
      `;

      const res = await fetch('https://core-api.hamrahtel.com/graphql/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `JWT ${token}`,
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
        },
        body: JSON.stringify({ query: queryCombined, variables: { first: 100 } }),
      });

      const data = (await res.json()) as any;
      const mobileEdges = data?.data?.mobileCategory?.products?.edges || [];
      const rootEdges = data?.data?.rootProducts?.edges || [];
      const nodeMap = new Map<string, any>();
      for (const e of [...mobileEdges, ...rootEdges]) {
        if (e?.node?.id) nodeMap.set(e.node.id, e.node);
      }

      // If main query yielded products, no need for hundreds of slow individual queries
      if (nodeMap.size === 0) {
        try {
          const storeProducts = readJsonFile<any[]>(path.join(DATA_DIR, 'products.json'), []);
          for (const p of storeProducts.slice(0, 15)) {
            const searchKey = p.model || (p.name || "").match(/\b(A\d+|S\d+|iPhone\s*\d+|Note\s*\d+)/i)?.[0];
          if (searchKey) {
            const searchQuery = `
              query SearchP($search: String!) {
                products(first: 10, filter: { search: $search }) {
                  edges {
                    node {
                      id
                      name
                      slug
                      variants {
                        id
                        name
                        sku
                        pricing {
                          price {
                            gross {
                              amount
                              currency
                            }
                          }
                        }
                        quantityAvailable
                      }
                    }
                  }
                }
              }
            `;
            const sRes = await fetch('https://core-api.hamrahtel.com/graphql/', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                Authorization: `JWT ${token}`,
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
              },
              body: JSON.stringify({ query: searchQuery, variables: { search: searchKey } }),
            });
            const sData = (await sRes.json()) as any;
            for (const se of sData?.data?.products?.edges || []) {
              if (se?.node?.id) nodeMap.set(se.node.id, se.node);
            }
          }
        }
      } catch (err) {
        console.warn("Targeted Hamrah Tel search error:", err);
      }
    }

      const edges = Array.from(nodeMap.values()).map(n => ({ node: n }));
      const items: any[] = [];

      for (const edge of edges) {
        const node = edge.node;
        if (!node) continue;

        const variants = (node.variants || []).map((v: any) => {
          const rawPrice = v.pricing?.price?.gross?.amount ? Math.round(Number(v.pricing.price.gross.amount)) : 0;
          const stock = Number(v.quantityAvailable || 0);
          return {
            id: v.id,
            name: v.name || 'پیش‌فرض',
            color: v.name || 'پیش‌فرض',
            color_name: v.name || 'پیش‌فرض',
            sku: v.sku,
            price: rawPrice,
            stock,
            inStock: stock > 0,
          };
        });

        const activeVariant = variants.find((v: any) => v.price > 0 && v.inStock) || variants[0];
        const defaultPrice = activeVariant ? activeVariant.price : 0;
        const totalStock = variants.reduce((sum: number, v: any) => sum + (v.stock || 0), 0);

        const img = node.thumbnail?.url || '';
        items.push({
          id: node.id,
          name: node.name,
          title: node.name,
          persianName: node.name,
          slug: node.slug,
          sku: node.variants?.[0]?.sku,
          price: defaultPrice,
          stock: totalStock,
          image: img,
          images: img ? [img] : [],
          variants,
        });
      }

      return { success: true, items };
    } catch (err: any) {
      return {
        success: false,
        items: [],
        error: `خطا در دریافت کاتالوگ همراه تل: ${err?.message || err}`,
      };
    }
  },
};

export const EhadishAdapter: SupplierAdapter = {
  ...UniversalSupplierAdapter,
  id: 'ehadish',
  name: 'هدیش (Ehadish)',
  async fetchCatalog(supplier: Supplier): Promise<{ success: boolean; items: any[]; error?: string }> {
    try {
      // کاتالوگ هدیش فقط از فایل مخصوص خودش خوانده می‌شود، نه از کالاهای فروشگاه (قاعده‌ی v1.8.1:
      // تأمین‌کننده‌ها فقط برای قیمت/موجودی‌اند و هیچ کالایی از آن‌ها وارد فروشگاه نمی‌شود).
      const catalogPath = path.join(DATA_DIR, 'ehadish_products.json');
      if (!fs.existsSync(catalogPath)) {
        return { success: false, items: [], error: 'کاتالوگ هدیش هنوز دریافت نشده است (data/ehadish_products.json)؛ قیمت‌ها تغییری نکردند.' };
      }
      const ehadishItems = readJsonFile<any[]>(catalogPath, []);

      const normalizedItems = ehadishItems.map((p) => {
        const numId = String(p.supplierMatches?.ehadish?.supplierProductId || p.id).replace('prod-eh-', '');
        const rawVariants = Array.isArray(p.variants) && p.variants[0]?.options ? p.variants[0].options : Array.isArray(p.colors) ? p.colors : [];
        return {
          id: numId,
          sku: numId,
          name: p.name,
          title: p.title || p.name,
          persianName: p.persianName || p.name,
          brand: p.brand,
          category: p.category,
          price: p.price,
          stock: p.stock !== undefined && p.stock !== null && p.stock !== '' ? Math.max(0, Number(p.stock) || 0) : 0,
          inStock: p.inStock !== false,
          image: p.image,
          images: p.images || [p.image],
          supplierId: 'ehadish',
          supplierName: 'هدیش (Ehadish)',
          variants: rawVariants.map((c: any) => ({
            id: c.id,
            name: c.name,
            color: c.name,
            colorName: c.name,
            colorCode: c.colorCode,
            price: c.price || p.price,
            stock: c.stock !== undefined && c.stock !== null && c.stock !== '' ? Math.max(0, Number(c.stock) || 0) : 0,
            inStock: c.inStock !== false,
          })),
        };
      });

      return { success: true, items: normalizedItems };
    } catch (err: any) {
      return {
        success: false,
        items: [],
        error: `خطا در کاتالوگ هدیش: ${err?.message || err}`,
      };
    }
  },
};

const ADAPTERS: Record<string, SupplierAdapter> = {
  kasra: KasraAdapter,
  hamrahtel: HamrahTelAdapter,
  ehadish: EhadishAdapter,
};

export function registerSupplierAdapter(adapter: SupplierAdapter) {
  ADAPTERS[adapter.id] = adapter;
}

export const getAdapter = (s: { id: string; name: string }): SupplierAdapter => ADAPTERS[s.id] || { ...UniversalSupplierAdapter, id: s.id, name: s.name };


// ============================================================================
// 7. Core Multi-Supplier Sync & Pricing Engine
//    قاعده‌ی ثابت: تأمین‌کننده‌ها فقط «قیمت و موجودی» کالاهای ثبت‌شده‌ی مدیر را تعیین می‌کنند.
//    قیمت هر رنگ = بالاترین قیمت تأمین‌کنندگان موجود × (۱ + درصد مصوب)  — فقط یک‌بار اضافه‌سازی.
// ============================================================================

let isSyncRunning = false;

interface SupEntry { supplierId: string; supplierName: string; colorName: string; price: number; inStock: boolean; stock?: number }
interface SyncCtx {
  details: Record<string, { matched: any[]; colors: any[]; ambiguous: any[] }>;
  markupRate: number;
  frozenSupplierIds: Set<string>;
  supplierName: (id: string) => string;
  nowIso: string;
  anyFailed: boolean;
}

const isColorGroup = (g: any) => g && (g.type === 'color' || g.name === 'رنگ' || (typeof g.title === 'string' && g.title.includes('رنگ')));
const pLabel = (p: any) => String(p.persianName || p.name || p.id);

/** اختلاف ۱۰ برابری با قیمت فعلی سایت = تقریباً قطعاً اشتباه واحد (ریال/تومان)؛ فقط همین حالت خاص نگه داشته می‌شود. */
export function looksLikeUnitMismatch(oldPrice: any, newPrice: number): boolean {
  const o = Number(oldPrice);
  if (!(o > 0) || !(newPrice > 0)) return false;
  const r = newPrice / o;
  return (r >= 8 && r <= 12.5) || (r >= 0.08 && r <= 0.125);
}

const bestOf = (es: SupEntry[]): SupEntry => es.reduce((a, b) => (b.price > a.price ? b : a), es[0]);

/** قیمت‌گذاری یک کالا بر اساس تطبیق‌های قطعی تأمین‌کنندگان؛ true یعنی چیزی تغییر کرد. */
function priceProduct(product: any, matches: SupplierProductMatch[], ctx: SyncCtx): boolean {
  const { details, markupRate, frozenSupplierIds, nowIso } = ctx;
  const label = pLabel(product);
  const review = (supplierId: string, row: any) => details[supplierId]?.ambiguous.push({ productId: product.id, productName: label, ...row });
  let changed = false;

  const entries: SupEntry[] = [];
  for (const m of matches) {
    for (const v of m.variants) {
      entries.push({ supplierId: m.supplierId, supplierName: ctx.supplierName(m.supplierId), colorName: v.colorName || '', price: Number(v.sourcePrice) || 0, inStock: v.inStock, stock: v.stock });
    }
  }
  const live = (es: SupEntry[]) => es.filter((e) => e.inStock && e.price > 0);

  const groups: any[] = Array.isArray(product.variants) ? product.variants : [];
  const colorGroup = groups.find(isColorGroup) || null;
  const options: any[] = colorGroup && Array.isArray(colorGroup.options) ? colorGroup.options : [];

  // ---------------------------------------------------------------- کالای دارای رنگ
  if (options.length > 0) {
    const colored = entries.filter((e) => e.colorName);
    const global = entries.filter((e) => !e.colorName);
    const supNames = [...new Set(colored.map((e) => e.colorName))];
    const map = mapColors(options.map((o) => `${o.name || ''} ${o.value || ''}`), supNames);
    const hasLive = (name: string) => live(colored.filter((e) => e.colorName === name)).length > 0;
    const unresolvedSup = [
      ...map.ambiguousSupplier.map((a) => supNames[a.supplier]),
      ...map.unmatchedSupplier.map((i) => supNames[i]),
    ].filter(hasLive);
    const fullyResolved = unresolvedSup.length === 0;

    for (const name of unresolvedSup) {
      for (const sid of new Set(colored.filter((e) => e.colorName === name).map((e) => e.supplierId))) {
        const amb = map.ambiguousSupplier.find((a) => supNames[a.supplier] === name);
        review(sid, {
          kind: 'color',
          reason: amb
            ? `رنگ «${name}» تأمین‌کننده با چند رنگ کالای شما شبیه است (${amb.masters.map((i) => options[i].name).join('، ')})؛ قیمت اعمال نشد`
            : `رنگ «${name}» تأمین‌کننده با هیچ رنگ ثبت‌شده‌ی کالای شما تطبیق نخورد؛ اگر این رنگ را می‌فروشید، آن را در کالا ثبت یا نام آن را اصلاح کنید`,
          candidates: [],
        });
      }
    }

    const touched = new Set<string>();
    let highest = 0, refId = '', refName = '';

    options.forEach((opt, oi) => {
      const pair = map.pairs.find((p) => p.master === oi);
      const names = pair ? pair.supplier.map((i) => supNames[i]) : [];
      const es = [...colored.filter((e) => names.includes(e.colorName)), ...global];

      if (es.length === 0) return; // در مرحله‌ی بعد (رنگ‌های بدون تطبیق) بررسی می‌شود

      touched.add(opt.id);
      const liveEs = live(es);
      if (liveEs.length === 0) {
        // همه‌ی تأمین‌کنندگانِ این رنگ صراحتاً ناموجود گفته‌اند
        if (ctx.anyFailed || (opt.referenceSupplierId && frozenSupplierIds.has(opt.referenceSupplierId))) return;
        if (opt.inStock !== false || opt.stock !== 0) { opt.inStock = false; opt.stock = 0; changed = true; }
        return;
      }
      const best = bestOf(liveEs);
      const finalPrice = Math.round(best.price * (1 + markupRate));
      for (const e of es) details[e.supplierId]?.colors.push({ productId: product.id, productName: label, color: opt.name, supplierPrice: e.price, sitePrice: finalPrice, usedForSitePrice: e === best, approximate: Boolean(pair?.loose) });

      if (looksLikeUnitMismatch(opt.price, finalPrice)) {
        review(best.supplierId, { kind: 'unit_mismatch', color: opt.name, currentPrice: opt.price, newPrice: finalPrice, newSourcePrice: best.price, supplierId: best.supplierId, reason: `قیمت جدید رنگ «${opt.name}» (${finalPrice}) حدوداً ۱۰ برابر/یک‌دهم قیمت فعلی (${opt.price}) است؛ احتمالاً اشتباه واحد ریال/تومان. اعمال نشد.`, candidates: [] });
        if (opt.price > highest) { highest = opt.price; refId = opt.referenceSupplierId || best.supplierId; refName = opt.referenceSupplierName || best.supplierName; }
        return;
      }
      if (finalPrice > highest) { highest = finalPrice; refId = best.supplierId; refName = best.supplierName; }
      const stockNow = best.stock !== undefined && Number.isFinite(Number(best.stock)) ? Math.max(0, Number(best.stock)) : (opt.stock > 0 ? opt.stock : 0);
      if (opt.sourcePrice !== best.price || opt.price !== finalPrice || opt.referenceSupplierId !== best.supplierId || opt.inStock !== true || opt.markupRate !== markupRate) {
        opt.sourcePrice = best.price;
        opt.markupRate = markupRate;
        opt.price = finalPrice;
        opt.referenceSupplierId = best.supplierId;
        opt.referenceSupplierName = best.supplierName;
        opt.inStock = true;
        opt.stock = stockNow;
        changed = true;
      }
    });

    // رنگ‌هایی از کالای شما که هیچ ردیفی از تأمین‌کننده به آن‌ها نگاشت نشد
    for (const opt of options) {
      if (touched.has(opt.id)) continue;
      if (!fullyResolved) continue; // مطمئن نیستیم ناموجود است یا فقط نام دیگری دارد → وضعیت قبلی حفظ می‌شود
      if (ctx.anyFailed || (opt.referenceSupplierId && frozenSupplierIds.has(opt.referenceSupplierId))) continue;
      if (opt.inStock !== false || opt.stock !== 0) { opt.inStock = false; opt.stock = 0; changed = true; }
    }

    // قیمت پایه و اختلاف رنگ‌ها
    const inStockOpts = options.filter((o) => o.inStock && Number(o.price) > 0);
    const base = inStockOpts.length ? Math.max(...inStockOpts.map((o) => Number(o.price))) : 0;
    if (base > 0 && highest === 0) { highest = base; }
    if (highest > 0 && product.price !== highest) {
      product.price = highest;
      product.sourcePrice = Math.round(highest / (1 + markupRate));
      product.syncedPrice = highest;
      changed = true;
    }
    for (const opt of options) {
      const delta = opt.inStock && typeof opt.price === 'number' && highest > 0 ? opt.price - highest : 0;
      if (opt.priceDelta !== delta) { opt.priceDelta = delta; changed = true; }
    }
    options.sort((a, b) => (b.inStock ? 1 : 0) - (a.inStock ? 1 : 0));
    const anyStock = options.some((o) => o.inStock === true);
    if (product.inStock !== anyStock) { product.inStock = anyStock; changed = true; }
    product.colors = options.map((o) => ({
      id: o.id, name: o.name, colorCode: o.colorCode || '#1e293b', price: o.price || product.price,
      priceDelta: o.priceDelta || 0, inStock: Boolean(o.inStock), stock: o.inStock ? (o.stock ?? null) : 0,
    }));
    if (refName && product.referenceSupplierName !== refName) {
      product.referenceSupplierId = refId; product.referenceSupplierName = refName; product.supplierName = refName; changed = true;
    }
    product.lastSyncedAt = nowIso;
    product.syncStatus = fullyResolved ? 'synced' : 'needs_review';
    return changed;
  }

  // ---------------------------------------------------------------- کالای بدون رنگ ثبت‌شده
  const liveAll = live(entries);
  const distinctPrices = new Set(liveAll.map((e) => e.price));
  if (liveAll.length === 0) {
    // تطبیق قطعی هست ولی هیچ تأمین‌کننده‌ی سالمی موجودی ندارد → ناموجود (قیمت قبلی حفظ می‌شود)
    const dependsOnFailed = ctx.anyFailed || Boolean(product.referenceSupplierId && frozenSupplierIds.has(product.referenceSupplierId));
    if (!dependsOnFailed && product.inStock !== false) { product.inStock = false; changed = true; }
    product.lastSyncedAt = nowIso; product.syncStatus = 'synced';
    return changed;
  }
  if (distinctPrices.size > 1 && entries.some((e) => e.colorName)) {
    const best0 = bestOf(liveAll);
    review(best0.supplierId, { kind: 'color', reason: 'تأمین‌کننده برای رنگ‌های مختلف قیمت متفاوت دارد، اما برای کالای شما هیچ رنگی ثبت نشده است؛ رنگ‌ها را در کالا ثبت کنید', candidates: [] });
    product.syncStatus = 'needs_review';
    return changed;
  }
  const best = bestOf(liveAll);
  const finalPrice = Math.round(best.price * (1 + markupRate));
  for (const e of liveAll) details[e.supplierId]?.colors.push({ productId: product.id, productName: label, color: 'قیمت واحد (بدون رنگ)', supplierPrice: e.price, sitePrice: finalPrice, usedForSitePrice: e === best });
  if (looksLikeUnitMismatch(product.price, finalPrice)) {
    review(best.supplierId, { kind: 'unit_mismatch', currentPrice: product.price, newPrice: finalPrice, newSourcePrice: best.price, supplierId: best.supplierId, reason: `قیمت جدید (${finalPrice}) حدوداً ۱۰ برابر/یک‌دهم قیمت فعلی (${product.price}) است؛ احتمالاً اشتباه واحد ریال/تومان. اعمال نشد.`, candidates: [] });
    return changed;
  }
  if (product.price !== finalPrice || product.sourcePrice !== best.price || product.referenceSupplierId !== best.supplierId || product.inStock !== true) {
    product.price = finalPrice;
    product.sourcePrice = best.price;
    product.syncedPrice = finalPrice;
    product.referenceSupplierId = best.supplierId;
    product.referenceSupplierName = best.supplierName;
    product.supplierName = best.supplierName;
    product.inStock = true;
    changed = true;
  }
  product.lastSyncedAt = nowIso;
  product.syncStatus = 'synced';
  return changed;
}

// ----------------------------------------------------------------------------
// ساخت خودکار کالا از تأمین‌کننده‌ها — فقط «غیرگوشی»‌ها. گوشی‌های موبایل را مدیر خودش ثبت می‌کند.
// حذف‌شده‌ها در data/supplier_ignored.json ثبت می‌شوند تا دوباره ساخته نشوند. با settings.autoCreateFromSuppliers=false خاموش می‌شود.
// ----------------------------------------------------------------------------
export const IGNORED_FILE = 'supplier_ignored.json';
const autoHash = (s: string) => createHash('sha1').update(s).digest('hex').slice(0, 10);

function autoCreateProducts(
  masters: any[], suppliers: Supplier[], catalogs: Record<string, any[]>, consumed: Record<string, Set<string>>, settings: any, nowIso: string, options: { dryRun?: boolean } = {},
): any[] {
  if (settings?.autoCreateFromSuppliers === false) return [];
  const ignored = new Set<string>(readJsonFile<string[]>(path.join(DATA_DIR, IGNORED_FILE), []));
  const existingKeys = new Set(masters.filter((p) => p?.autoKey).map((p) => String(p.autoKey)));
  const existingIds = new Set(masters.map((p) => String(p?.id)));
  const groups = new Map<string, { sup: Supplier; rows: any[]; id: Identity }>();
  for (const sup of suppliers) {
    for (const it of catalogs[sup.id] || []) {
      const itemId = String(it?.id ?? it?.product_id ?? '');
      if (!itemId || consumed[sup.id]?.has(itemId)) continue;
      const idn = identityOfItem(it);
      if (idn.category === 'phone') continue; // گوشی: فقط ثبت دستی مدیر
      const title = titleOf(it).trim();
      if (title.length < 3) continue;
      const vs = buildVariants([it]);
      if (!vs.some((v) => v.inStock && v.sourcePrice > 0)) continue; // کالای ناموجود/بدون قیمت ساخته نمی‌شود
      const textKey = normalizeText(idn.colorPhrase ? title.replace(idn.colorPhrase, ' ') : title);
      const key = `${sup.id}|${textKey}`;
      const g = groups.get(key);
      if (g) g.rows.push(it); else groups.set(key, { sup, rows: [it], id: idn });
    }
  }
  const out: any[] = [];
  for (const [key, g] of groups) {
    if (ignored.has(key) || existingKeys.has(key)) continue;
    const first = g.rows[0];
    const cp = g.id.colorPhrase;
    const title = ((cp ? titleOf(first).split(cp).join(' ') : titleOf(first)).replace(/\s+/g, ' ').trim()) || titleOf(first).trim();
    const id = `prod-auto-${g.sup.id}-${autoHash(key)}`;
    if (existingIds.has(id)) continue;
    const cls = classifyProduct({ name: title, persianName: title, id });
    const category = cls.category === 'گوشی موبایل' ? 'سایر' : cls.category;
    const seen = new Set<string>(); const options: any[] = [];
    for (const v of buildVariants(g.rows)) {
      if (!v.colorName) continue;
      const k = colorKey(v.colorName) || v.colorName; if (seen.has(k)) continue; seen.add(k);
      options.push({ id: `${id}-c${options.length + 1}`, name: v.colorName, value: v.colorName, colorCode: '#64748b', priceDelta: 0, inStock: true });
    }
    const img = g.rows.map((r) => r.image || r.image_url || (Array.isArray(r.images) ? (typeof r.images[0] === 'string' ? r.images[0] : r.images[0]?.url) : '')).find((u) => typeof u === 'string' && /^https?:\/\//.test(u));
    const itemIds = g.rows.map((r) => String(r.id ?? r.product_id));
    out.push({
      id, name: title, persianName: title, brand: cls.brand, category, subcategory: cls.subcategory,
      // کالاهای کشف‌شده خودکار صرفاً پیش‌نویس‌اند؛ تا تأیید مدیر نباید قابل سفارش یا منتشرشده تلقی شوند.
      price: 0, stock: 0, inStock: false, active: false, images: [img || '/logo.png'],
      slug: `${title.toLowerCase().replace(/[^a-z0-9\u0600-\u06FF]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80)}-${autoHash(key).slice(0, 6)}`,
      description: title, source: 'puzzlekala', autoCreated: true, autoKey: key, createdAt: nowIso.slice(0, 10),
      supplierMatches: { [g.sup.id]: { supplierProductId: itemIds[0], itemIds, confirmedBy: 'auto', confirmedAt: nowIso } },
      ...(options.length ? { variants: [{ type: 'color', title: 'انتخاب رنگ', options }] } : {}),
    });
  }
  if (out.length && !options.dryRun) recordAuditLog('supplier_auto_create', `${out.length} کالای غیرگوشی از تأمین‌کنندگان ساخته شد.`, 'multi-supplier-sync', { ids: out.slice(0, 50).map((p) => p.id) });
  return out;
}

export async function executeMultiSupplierSync(
  onUpdateNotify?: (() => void) | any,
  options: { dryRun?: boolean } = {}
): Promise<{
  success: boolean;
  message: string;
  updatedMasterProducts: number;
  plannedChanges?: Array<{ productId: string; productName: string; changeType: 'created' | 'updated'; before?: any; after: any }>;
  dryRun?: boolean;
  supplierStats: Record<string, any>;
  timestamp: string;
}> {
  // Concurrency Guard: Mutex Lock
  if (isSyncRunning) {
    return {
      success: false,
      message: 'همگام‌سازی تأمین‌کنندگان در حال حاضر در حال اجراست؛ لطفاً شکیبا باشید.',
      updatedMasterProducts: 0,
      supplierStats: {},
      timestamp: new Date().toISOString(),
    };
  }

  isSyncRunning = true;
  const nowIso = new Date().toISOString();

  try {
    currentRules = loadMatchingRules();
    const suppliers = getSuppliersList();
    const enabledSuppliers = suppliers.filter((s) => s.enabled);
    const productsPath = path.join(DATA_DIR, 'products.json');

    // درصد مصوب افزایش قیمت (پیش‌فرض ۵٪)
    const settings = readJsonFile<any>(path.join(DATA_DIR, 'settings.json'), {});
    let approvedMarkupPercent = Number(settings.supplierMarkupPercent ?? 5);
    if (!Number.isFinite(approvedMarkupPercent) || approvedMarkupPercent < 0 || approvedMarkupPercent > 100) approvedMarkupPercent = 5;
    const markupRate = approvedMarkupPercent / 100;

    const supplierCatalogs: Record<string, any[]> = {};
    const supplierStats: Record<string, any> = {};

    // 1. Fetch catalogs from all enabled suppliers in PARALLEL
    await Promise.all(
      enabledSuppliers.map(async (sup) => {
        const adapter = ADAPTERS[sup.id] || { ...UniversalSupplierAdapter, id: sup.id, name: sup.name };
        sup.lastSyncAt = nowIso;

        try {
          const fetchRes = await adapter.fetchCatalog(sup);
          if (fetchRes.success && Array.isArray(fetchRes.items)) {
            // A successful HTTP response with an empty catalog is not safe evidence
            // that the supplier has zero products. Treat it as an unavailable feed so
            // a transient/auth/pagination failure cannot turn every matched product
            // into out-of-stock.
            if (fetchRes.items.length === 0) {
              sup.status = 'unavailable';
              sup.lastError = 'کاتالوگ تأمین‌کننده خالی دریافت شد؛ برای جلوگیری از صفر/ناموجود شدن کاذب، وضعیت قبلی حفظ شد.';
              supplierCatalogs[sup.id] = [];
            } else {
              sup.status = 'connected';
              sup.lastSuccessAt = nowIso;
              sup.lastError = null;
              supplierCatalogs[sup.id] = fetchRes.items;
            }
          } else {
            sup.status = 'unavailable';
            sup.lastError = fetchRes.error || 'پاسخ نامعتبر از تأمین‌کننده';
            supplierCatalogs[sup.id] = [];
          }
        } catch (err: any) {
          sup.status = 'error';
          sup.lastError = err.message || 'خطا در برقراری ارتباط';
          supplierCatalogs[sup.id] = [];
        }

        sup.matchedCount = 0;
        sup.ambiguousCount = 0;
        sup.variantsCount = 0;
        sup.inStockColorsCount = 0;

        const catItems = supplierCatalogs[sup.id] || [];
        const itemInStock = (it: any) => {
          if (!it || typeof it !== 'object') return false;
          if (it.no_longer_available === true || it.is_available === false || it.is_available === 0 || it.site_visible === 0) return false;
          if (it.inStock === true) return true;
          if (it.stock !== undefined && it.stock !== null && it.stock !== '' && Number(it.stock) > 0) return true;
          const variants = [...(Array.isArray(it.variants) ? it.variants : []), ...(Array.isArray(it.colors) ? it.colors : [])];
          if (variants.length > 0) {
            return variants.some((v: any) => v && (v.inStock === true || Number(v.stock) > 0 || v.is_available === true || v.is_available === 1));
          }
          if (Number(it.price || it.sell_price || it.sourcePrice || 0) > 0) {
            return true;
          }
          if (it.site_visible === 1 || it.site_visible === true) {
            return true;
          }
          return false;
        };
        const fetchedOk = sup.status === 'connected';
        // اگر دریافت کاتالوگ ناموفق بود، آمار قبلی حفظ می‌شود (به‌جای صفر شدن)
        const srcTotal = fetchedOk ? catItems.length : sup.sourceTotalProducts ?? 0;
        const srcInStock = fetchedOk ? catItems.filter(itemInStock).length : sup.sourceInStockProducts ?? 0;
        const srcOutOfStock = Math.max(0, srcTotal - srcInStock);

        sup.sourceTotalProducts = srcTotal;
        sup.sourceInStockProducts = srcInStock;
        sup.sourceOutOfStockProducts = srcOutOfStock;

        supplierStats[sup.id] = {
          name: sup.name,
          enabled: sup.enabled,
          status: sup.status,
          lastError: sup.lastError,
          sourceTotalProducts: srcTotal,
          sourceInStockProducts: srcInStock,
          sourceOutOfStockProducts: srcOutOfStock,
          matchedCount: 0,
          ambiguousCount: 0,
          variantsCount: 0,
          inStockColorsCount: 0,
        };
      })
    );

    // کالاهای فروشگاه «بعد از» دریافت کاتالوگ‌ها خوانده می‌شوند و تا لحظه‌ی ذخیره هیچ await ی در کار نیست؛
    // پس ویرایش هم‌زمان مدیر روی کالاها با همگام‌سازی روی هم نمی‌نویسد.
    const masterProducts: any[] = readJsonFile<any[]>(productsPath, []);
    const originalProducts = JSON.parse(JSON.stringify(masterProducts));
    const masterIdsAtStart = masterProducts.map((p: any) => p?.id);

    // نمایه‌ی شناسه‌ی ردیف‌های هر تأمین‌کننده (فقط برای «تأیید دستی مدیر»)
    const supplierIndexes: Record<string, SupplierCatalogIndex> = {};
    for (const sup of enabledSuppliers) {
      const items = supplierCatalogs[sup.id] || [];
      if (items.length === 0) continue;
      const index: SupplierCatalogIndex = { idMap: new Map(), items };
      for (const item of items) if (item.id !== undefined) index.idMap.set(String(item.id).trim(), item);
      supplierIndexes[sup.id] = index;
    }

    // تأمین‌کننده‌های «منجمد»: خطادار یا غیرفعال — آخرین قیمت/موجودی اعمال‌شده از آن‌ها دست‌نخورده می‌ماند
    const failedSupplierIds = new Set(enabledSuppliers.filter((s) => s.status !== 'connected').map((s) => s.id));
    const frozenSupplierIds = new Set<string>([...failedSupplierIds, ...suppliers.filter((s) => !s.enabled).map((s) => s.id)]);

    // جزئیات تطبیق برای نمایش با کلیک روی باکس‌های آماری
    const details: Record<string, { matched: any[]; colors: any[]; ambiguous: any[] }> = {};
    for (const sup of enabledSuppliers) details[sup.id] = { matched: [], colors: [], ambiguous: [] };
    const ctx: SyncCtx = { details, markupRate, frozenSupplierIds, nowIso, anyFailed: failedSupplierIds.size > 0, supplierName: (id) => suppliers.find((s) => s.id === id)?.name || id };

    let updatedProductsCount = 0;
    const identityIssues: any[] = [];
    for (const p of masterProducts) {
      if (!p || typeof p !== 'object') continue;
      const idn = identityOfProduct(p);
      if (idn.category === 'accessory' || p.autoCreated) continue;
      const why = !idn.model ? 'مدل کالا از نام آن قابل تشخیص نیست؛ نام را به شکل «برند + مدل + رم/حافظه» اصلاح کنید' : idn.conflicts.length ? `نام و توضیحات کالا در این مشخصات متناقض‌اند: ${idn.conflicts.map((f) => FIELD_FA[f] || f).join('، ')}` : '';
      if (why) identityIssues.push({ productId: p.id, productName: pLabel(p), kind: 'product', reason: why, candidates: [] });
    }

    // 3. تطبیق کالاهای ثبت‌شده‌ی مدیر با تأمین‌کنندگان و قیمت‌گذاری
    const consumed: Record<string, Set<string>> = {};
    for (const sup of enabledSuppliers) consumed[sup.id] = new Set();
    const handle = (product: any) => {
      if (!product || typeof product !== 'object') return;
      const productMatches: SupplierProductMatch[] = [];

      for (const sup of enabledSuppliers) {
        const items = supplierCatalogs[sup.id] || [];
        const adapter = ADAPTERS[sup.id] || { ...UniversalSupplierAdapter, id: sup.id, name: sup.name };
        if (items.length === 0) continue;

        let match: SupplierProductMatch | null = null;
        try { match = adapter.matchProduct(product, items, supplierIndexes[sup.id]); }
        catch (err: any) { details[sup.id].ambiguous.push({ productId: product.id, productName: pLabel(product), kind: 'product', reason: `خطا در تطبیق: ${err?.message || err}`, candidates: [] }); continue; }
        if (!match) continue;
        for (const k of match.itemIds || []) consumed[sup.id].add(k);
        for (const c of match.candidates || []) if (c.id !== undefined) consumed[sup.id].add(String(c.id));

        if (match.confidence === 'ambiguous') {
          const colorsOf = (() => {
            const g = (Array.isArray(product.variants) ? product.variants : []).find(isColorGroup);
            if (g && Array.isArray(g.options) && g.options.length > 0) return g.options.map((o: any) => o.name).filter(Boolean).join('، ');
            return 'عمومی / تمام رنگ‌ها';
          })();
          details[sup.id].ambiguous.push({
            productId: product.id, productName: pLabel(product), productColor: colorsOf, productPrice: product.price ?? null,
            kind: 'product', reason: match.matchReason || 'تطبیق مبهم', candidates: match.candidates || [],
          });
          if (!options.dryRun) recordAuditLog('sync_ambiguous_match', `تطبیق مبهم برای کالای ${pLabel(product)} در ${sup.name}: ${match.matchReason || ''}`, 'multi-supplier-sync', { productId: product.id, supplierId: sup.id });
        } else {
          productMatches.push(match);
          details[sup.id].matched.push({ productId: product.id, productName: pLabel(product), confidence: match.confidence, reason: match.matchReason || '', supplierProductId: match.supplierProductId ?? null });
          supplierStats[sup.id].variantsCount += match.variants.length;
        }
      }

      if (productMatches.length === 0) return;
      if (priceProduct(product, productMatches, ctx)) updatedProductsCount++;
    };
    for (const product of masterProducts) handle(product);

    // 3-ب. ساخت خودکار کالاهای «غیرگوشی» که هنوز در فروشگاه نیستند، سپس قیمت‌گذاری همان‌ها
    const created = autoCreateProducts(masterProducts, enabledSuppliers.filter((s) => s.status === 'connected'), supplierCatalogs, consumed, settings, nowIso, options);
    for (const np of created) { masterProducts.push(np); handle(np); }
    updatedProductsCount += created.length;

    // شمارنده‌های باکس‌ها دقیقاً از همان فهرست‌های جزئیات ساخته می‌شود (عدد باکس = تعداد ردیف‌های جزئیات)
    const detailsPath = path.join(DATA_DIR, 'supplier_match_details.json');
    const savedDetails = readJsonFile<Record<string, any>>(detailsPath, {});
    for (const sup of enabledSuppliers) {
      const d = details[sup.id];
      d.matched = Array.from(new Map(d.matched.map((m: any) => [`${m.productId}:${m.supplierProductId ?? ''}`, m])).values());
      d.colors = Array.from(new Map(d.colors.map((m: any) => [`${m.productId}:${m.color}:${m.supplierPrice}`, m])).values());
      const uniqueSupplierMatchedIds = new Set(d.matched.map((m: any) => String(m.supplierProductId || m.productId)).filter(Boolean)).size;
      sup.matchedCount = Math.min(sup.sourceTotalProducts || uniqueSupplierMatchedIds, uniqueSupplierMatchedIds);
      sup.inStockColorsCount = d.colors.length;
      sup.ambiguousCount = d.ambiguous.length;
      Object.assign(supplierStats[sup.id], { matchedCount: sup.matchedCount, inStockColorsCount: sup.inStockColorsCount, ambiguousCount: sup.ambiguousCount });
      savedDetails[sup.id] = { ...d, updatedAt: nowIso };
    }
    savedDetails._store = { matched: [], colors: [], ambiguous: identityIssues, updatedAt: nowIso };
    if (!options.dryRun) writeJsonFile(detailsPath, savedDetails);

    // قاعده‌ی ثابت: کالاهای موجود هرگز حذف/جابه‌جا نمی‌شوند؛ تنها اضافه‌شده‌ها کالاهای غیرگوشی ساخته‌شده‌ی خودکارند.
    const keptOk = masterIdsAtStart.every((id, i) => masterProducts[i]?.id === id);
    const extrasOk = masterProducts.slice(masterIdsAtStart.length).every((p: any) => p?.autoCreated === true && String(p?.id).startsWith('prod-auto-'));
    if (!keptOk || !extrasOk) {
      throw new Error('همگام‌سازی نباید کالایی حذف/جابه‌جا کند یا کالای غیرمجاز بسازد؛ ذخیره‌سازی متوقف شد.');
    }

    if (!options.dryRun && updatedProductsCount > 0) {
      writeJsonFile(productsPath, masterProducts);
    }
    if (!options.dryRun) saveSuppliersList(suppliers);

    if (!options.dryRun && typeof onUpdateNotify === 'function' && updatedProductsCount > 0) {
      onUpdateNotify();
    }

    const connectedCount = enabledSuppliers.filter((s) => s.status === 'connected').length;
    const totalMatched = Object.values(supplierStats).reduce((a, s: any) => a + (s.matchedCount || 0), 0);

    const message =
      enabledSuppliers.length === 0
        ? 'هیچ تأمین‌کننده فعال و قابل دسترسی برای همگام‌سازی پیدا نشد.'
        : `همگام‌سازی انجام شد — ${enabledSuppliers.length} تأمین‌کننده بررسی شدند (${connectedCount} متصل)، ${totalMatched} کالا با تطبیق کامل مشخصات (برند، مدل، نسخه، رم، حافظه و ...) هماهنگ شد، ${created.length ? created.length + ' کالای غیرگوشی جدید از تأمین‌کنندگان ساخته شد، ' : ''}${updatedProductsCount} کالا بر مبنای بیشترین قیمت تأمین‌کنندگان + نرخ مصوب (${approvedMarkupPercent}٪) به‌روزرسانی شد${identityIssues.length ? `؛ ${identityIssues.length} کالای شما مشخصات ناقص/متناقض دارد و تطبیق نشد` : ''}.`;

    if (!options.dryRun) recordAuditLog('multi_supplier_sync', message, 'admin', { enabledCount: enabledSuppliers.length, connectedCount, totalMatched, updatedProductsCount, markupPercent: approvedMarkupPercent });

    const beforeById = new Map(originalProducts.map((p: any) => [String(p?.id), p]));
    // Keep the full change set for durable history. The response is capped separately
    // so a large catalogue cannot silently lose history events after item 500.
    const allPlannedChanges = masterProducts.flatMap((after: any) => {
      const before = beforeById.get(String(after?.id));
      if (!before) return [{ productId: String(after?.id || ''), productName: pLabel(after), changeType: 'created' as const, after }];
      if (JSON.stringify(before) === JSON.stringify(after)) return [];
      return [{ productId: String(after?.id || ''), productName: pLabel(after), changeType: 'updated' as const, before, after }];
    });
    const plannedChanges = allPlannedChanges.slice(0, 500);

    // سابقهٔ افزایشی قیمت/موجودی؛ پیش‌نمایش هیچ تاریخچه‌ای را نمی‌نویسد.
    // تغییر بیش از ۳۰٪ فقط علامت‌گذاری می‌شود و به‌تنهایی تصمیم خودکار یا لغو سفارش ایجاد نمی‌کند.
    if (!options.dryRun && plannedChanges.length) {
      const historyPath = path.join(DATA_DIR, 'supplier_price_stock_history.json');
      const history = readJsonFile<any[]>(historyPath, []);
      const events: any[] = [];
      const collect = (c: any) => {
        const before = c.before || {};
        const after = c.after || {};
        const push = (variantId: string, name: string, oldPrice: any, newPrice: any, oldStock: any, newStock: any, supplierId?: string) => {
          const op = Number(oldPrice), np = Number(newPrice);
          const hasPrices = Number.isFinite(op) && op > 0 && Number.isFinite(np) && np > 0;
          const pct = hasPrices ? ((np - op) / op) * 100 : null;
          const anomaly = pct !== null && Math.abs(pct) > 30;
          if (oldPrice === newPrice && oldStock === newStock) return;
          events.push({ id: `${nowIso}:${c.productId}:${variantId}:${events.length}`, timestamp: nowIso, productId: c.productId, productName: c.productName, variantId, variantName: name, supplierId: supplierId || after.referenceSupplierId || null, oldPrice: oldPrice ?? null, newPrice: newPrice ?? null, oldStock: oldStock ?? null, newStock: newStock ?? null, priceChangePercent: pct === null ? null : Math.round(pct * 100) / 100, anomaly, anomalyReason: anomaly ? `تغییر قیمت ${Math.round(pct! * 100) / 100}٪؛ نیازمند بررسی مدیر` : null, reviewStatus: anomaly ? 'needs_review' : 'recorded' });
        };
        const beforeOpts = new Map<string, any>();
        for (const g of Array.isArray(before.variants) ? before.variants : []) for (const o of Array.isArray(g.options) ? g.options : []) beforeOpts.set(String(o.id || o.name), o);
        for (const g of Array.isArray(after.variants) ? after.variants : []) for (const o of Array.isArray(g.options) ? g.options : []) {
          const key = String(o.id || o.name), old = beforeOpts.get(key);
          push(key, String(o.name || o.value || key), old?.price, o.price, old?.stock, o.stock, o.referenceSupplierId);
        }
        if (!Array.isArray(after.variants) || !after.variants.some((g: any) => Array.isArray(g.options) && g.options.length)) push(String(c.productId), c.productName, before.price, after.price, before.stock, after.stock, after.referenceSupplierId);
      };
      allPlannedChanges.forEach(collect);
      if (events.length) {
        const validHistory = Array.isArray(history) ? history : [];
        writeJsonFile(historyPath, [...validHistory, ...events].slice(-5000));
      }
    }
    return { success: true, message: options.dryRun ? `پیش‌نمایش انجام شد؛ ${plannedChanges.length} تغییر پیشنهادی، بدون ذخیره در فایل‌های داده.` : message, updatedMasterProducts: updatedProductsCount, plannedChanges, dryRun: !!options.dryRun, supplierStats, timestamp: nowIso };
  } finally {
    isSyncRunning = false;
  }
}
