/** Validates integer quantities and aggregates repeated product IDs within one order. */
export function reserveRequestedQuantity(
  requestedByProduct: Map<string, number>,
  productId: string,
  rawQuantity: unknown,
  availableStock: unknown,
  maxLineQuantity = 100,
): number | null {
  const quantity = Number(rawQuantity);
  const stock = Number(availableStock);
  if (!Number.isSafeInteger(quantity) || quantity < 1 || quantity > maxLineQuantity || !Number.isFinite(stock) || stock < 0) return null;
  const totalRequested = (requestedByProduct.get(productId) || 0) + quantity;
  if (!Number.isSafeInteger(totalRequested) || totalRequested > stock || totalRequested > maxLineQuantity) return null;
  requestedByProduct.set(productId, totalRequested);
  return quantity;
}


/** Validate immutable order-item snapshots supplied by admin/sync APIs.
 * This does not trust browser prices for customer checkout; it is for records
 * created by privileged/manual flows and checks arithmetic consistency.
 */
export function validateOrderItemSnapshot(items: unknown, expectedSubtotal: unknown): { valid: boolean; subtotal: number; reason?: string } {
  if (!Array.isArray(items) || items.length < 1 || items.length > 100) return { valid: false, subtotal: 0, reason: 'invalid_items_count' };
  let subtotal = 0;
  for (const item of items) {
    if (!item || typeof item !== 'object' || Array.isArray(item)) return { valid: false, subtotal: 0, reason: 'invalid_item' };
    const productId = String((item as any).productId ?? (item as any).id ?? '').trim();
    const quantity = Number((item as any).quantity ?? (item as any).qty);
    const unitPrice = Number((item as any).unitPrice ?? (item as any).price);
    if (!productId || productId.length > 160) return { valid: false, subtotal: 0, reason: 'invalid_product_id' };
    if (!Number.isSafeInteger(quantity) || quantity < 1 || quantity > 100) return { valid: false, subtotal: 0, reason: 'invalid_quantity' };
    if (!Number.isFinite(unitPrice) || unitPrice <= 0 || unitPrice > 1e15 || !Number.isSafeInteger(Math.round(unitPrice))) return { valid: false, subtotal: 0, reason: 'invalid_unit_price' };
    subtotal += unitPrice * quantity;
    if (!Number.isFinite(subtotal) || subtotal > 1e15 || !Number.isSafeInteger(Math.round(subtotal))) return { valid: false, subtotal: 0, reason: 'subtotal_overflow' };
  }
  const expected = Number(expectedSubtotal);
  if (!Number.isFinite(expected) || expected < 0 || expected > 1e15 || Math.abs(Math.round(expected) - Math.round(subtotal)) > 1) {
    return { valid: false, subtotal, reason: 'subtotal_mismatch' };
  }
  return { valid: true, subtotal: Math.round(subtotal) };
}
