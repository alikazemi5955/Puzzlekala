# Puzzle Kala v1.11.0 — GitHub research follow-up

## Added
- Added admin-only `POST /api/suppliers/sync-preview`.
- Reuses the existing supplier fetching/matching/pricing computation but skips persistence to `products.json`, `supplier_match_details.json`, `suppliers.json`, audit logs, and notifications.
- Returns up to 500 `plannedChanges` entries with product id/name, create/update type, and before/after product snapshots.
- Added an automated test that snapshots the data files, runs preview, and asserts the files remain byte-identical.
- Existing live sync routes are unchanged. No automatic supplier selection or purchase-order placement was enabled.

## Inspiration reviewed
- `rezonea/python-inventory-sync-engine`: deterministic fingerprints, idempotent updates, bounded retries, and dry-run that does not write state/output files.
- `FerdinandoConte/shopify-supplier-sync-orchestrator`: whitelist, supplier scoring history, and preview-first sync.
- `voidmain69/product-attr-rag` and `hutchpd/ProductNormaliser`: product normalization and evidence provenance/conflict handling (the latter conflict handling was included in v1.10.0).
- `Nir-Bhay/store-catalog-exporter`: variant-aware catalog export and JSON-LD source parsing patterns.

## Validation status
- Prior ZIP integrity check remains applicable to v1.10.0 only; this ZIP is generated from that archive plus v1.11.0 changes.
- Full tests, lint, build, and host tests have not been run. Do not describe this release as fully tested.
