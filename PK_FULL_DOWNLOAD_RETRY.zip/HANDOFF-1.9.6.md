# Puzzle Kala — handoff 1.9.6

## This release
- Repeating a return-request status now returns the existing record without changing its note/timestamp or appending a duplicate audit event.
- Expanded return-workflow unit coverage for unknown states and illegal jumps/backward transitions.
- Package version bumped to 1.9.6.

## Verification status
- Static source review performed for the targeted route and workflow tests.
- Dependency installation, build, and test execution are not claimed: dependencies are not present in the provided environment and network package installation is unavailable here.
- Hosting/deployment tests are intentionally deferred per the user's instruction.

## Still outstanding before production use
- Real SMS OTP provider and safe account identifier linking.
- Real payment gateway verification callbacks and refund confirmation integration.
- Checkout UI integration with server-side quote API.
- Supplier sync operational hardening and preserving last-known-good supplier data on fetch failures.
- Persistent database/transaction strategy, backup and restore procedures, concurrency controls, and role-specific staff access.
- Configure real shipping rates and verify coupon/price/stock behavior end-to-end after deployment.
