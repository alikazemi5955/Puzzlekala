import dotenv from 'dotenv';
dotenv.config();
import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import {
  executeMultiSupplierSync,
  getSuppliersList,
  saveSuppliersList,
  readJsonFile,
  writeJsonFile,
  recordAuditLog,
  extractColorFromTitle,
  clearHamrahTelTokenCache,
  IGNORED_FILE,
} from './src/supplierEngine.js';
import { DATA_DIR as DATA_DIR_FROM_ENV } from './src/paths.js';
import { startAgents, registerAgentRoutes } from './src/agents/index.js';
import { smartRegister } from './src/smart/index.js';
import { runShoppingAssistant, assistantRateLimited } from './src/assistant.js';
import { hashPassword, isHashed, verifyPassword, createSession, getSession, getToken, requireRole, publicUser, digits, normalizeDigits, revokeUserSessions, revokeToken } from './src/auth.js';
import { classifyProduct } from './src/productClassifier.js';
import { canTransitionReturnStatus } from './src/returnWorkflow.js';
import { normalizePrice, normalizeStock, normalizeActive } from './src/productSafety.js';
import { reserveRequestedQuantity, validateOrderItemSnapshot } from './src/orderSafety.js';
import { ORDER_STATUS_ALIASES, canTransitionOrderStatus, isValidOrderAmount, isConsistentOrderTotal, normalizeOrderStatus } from './src/orderWorkflowSafety.js';
import { scrubSensitiveFields } from './src/securitySanitizers.js';
import { publicProductView } from './src/productPublicView.js';
import {
  getVirtualEmployees,
  addVirtualEmployee,
  updateVirtualEmployee,
  deleteVirtualEmployee,
  executeEmployeeCommand,
} from './src/virtualEmployees.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const configuredPort = Number(process.env.PORT);
const PORT = Number.isInteger(configuredPort) && configuredPort > 0 && configuredPort <= 65535 ? configuredPort : 3000;
const DATA_DIR = DATA_DIR_FROM_ENV;

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', process.env.TRUST_PROXY === '1' ? 1 : false);
app.use((req: Request, res: Response, next: NextFunction) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  if (req.path.startsWith('/api/')) res.setHeader('Cache-Control', 'no-store');
  if (process.env.NODE_ENV === 'production') res.setHeader('Strict-Transport-Security', 'max-age=15552000; includeSubDomains');
  next();
});
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));
app.use('/uploads', express.static(path.join(__dirname, 'public', 'uploads'), { maxAge: '7d' }));

// Rate limiting سبک برای endpointهای احراز هویت؛ هدف جلوگیری از brute-force ساده است.
const authHits = new Map<string, { count: number; resetAt: number }>();
const authRateLimit = (max = 8, windowMs = 60_000) => (req: Request, res: Response, next: NextFunction) => {
  const key = `${req.path}:${String(req.ip || req.socket.remoteAddress || 'unknown').slice(0, 120)}`;
  const now = Date.now();
  if (authHits.size > 5000) {
    for (const [k, v] of authHits) if (v.resetAt <= now) authHits.delete(k);
    // Bound memory even when an attacker rotates source IPs faster than the window expires.
    if (authHits.size > 10000) {
      const oldest = [...authHits.entries()].sort((a, b) => a[1].resetAt - b[1].resetAt);
      for (const [k] of oldest.slice(0, authHits.size - 10000)) authHits.delete(k);
    }
  }
  const cur = authHits.get(key);
  if (!cur || cur.resetAt <= now) { authHits.set(key, { count: 1, resetAt: now + windowMs }); return next(); }
  cur.count += 1;
  if (cur.count > max) return res.status(429).json({ success: false, message: 'تعداد تلاش‌ها زیاد است؛ لطفاً کمی بعد دوباره تلاش کنید.' });
  next();
};
registerAgentRoutes(app);

// Helper to get file path in data/
function getFilePath(filename: string): string {
  return path.join(DATA_DIR, filename);
}

// --------------------------------------------------------------------------
// API Routes
// --------------------------------------------------------------------------

// 1. Health
app.get('/api/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', time: new Date().toISOString(), port: PORT });
});

// Helper to sanitize product object
function sanitizeProduct(p: any): any {
  if (!p || typeof p !== 'object') return null;
  // If wrapped in nested products array, ignore
  if (Array.isArray(p.products)) return null;
  const name = String(p.name || p.persianName || p.title || 'کالای پازل کالا').trim();
  const persianName = String(p.persianName || name).trim();
  let brand = String(p.brand || '').trim();
  let category = String(p.category || '').trim();
  const id = String(p.id || `prod-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`);
  const baseSlug = (p.slug && typeof p.slug === 'string' && p.slug.trim())
    ? p.slug.trim()
    : (name || id || 'product').toLowerCase().replace(/[^a-z0-9\u0600-\u06FF]+/g, '-').replace(/^-+|-+$/g, '');

  // تشخیص دقیق برند و دسته‌بندی با موتور هوشمند
  const classification = classifyProduct({
    name,
    persianName,
    title: p.title,
    brand,
    category,
    slug: baseSlug,
    id,
  });

  // اگر برند پیش‌فرض یا متفرقه است، برند دقیق شناسایی‌شده جایگزین شود
  if (!brand || ['سایر برندها', 'سایر', 'متفرقه', 'دیگر', 'پیش فرض', 'پیش‌فرض', 'سامسونگ', 'Samsung', 'برند', 'نامشخص', 'Unknown', 'Other', 'other', 'default'].includes(brand)) {
    brand = classification.brand;
  } else if (!brand.includes('(') && classification.brand.includes('(') && classification.brand.includes(brand)) {
    // استانداردسازی فرمت فارسی (انگلیسی)
    brand = classification.brand;
  }

  // اگر دسته‌بندی پیش‌فرض (گوشی موبایل) بوده اما در واقع کالا لپ‌تاپ، تبلت، ساعت، پاوربانک، شارژر، هارد یا لوازم خانگی است
  if (!category || ['گوشی موبایل', 'mobile', 'cat-mobile', 'پیش فرض', 'پیش‌فرض', 'دسته اصلی', 'نامشخص', 'Unknown', 'Other', 'other', 'default', 'سایر'].includes(category)) {
    category = classification.category;
  }

  const priceNum = normalizePrice(p.price !== undefined && p.price !== null && p.price !== '' ? p.price : 0);
  const stockState = normalizeStock(p.stock !== undefined && p.stock !== null && p.stock !== '' ? p.stock : (p.inStock === true ? 1 : 0), p.inStock);
  const stockNum = stockState.stock;
  const inStockBool = stockState.inStock;
  const activeBool = normalizeActive(p.active);

  // پازل‌کالا تنوع RAM/حافظه را به‌عنوان Variant نگه نمی‌دارد؛ این دو فقط
  // در نام کالا و مشخصات فنی ثبت می‌شوند. تنوع مجاز فعلی: رنگ و گارانتی.
  const cleanVariants = Array.isArray(p.variants)
    ? p.variants.filter((v: any) => v && v.type !== 'storage' && v.type !== 'ram')
    : p.variants;

  return {
    ...p,
    id,
    name,
    persianName,
    brand,
    brandFa: classification.brandFa,
    brandEn: classification.brandEn,
    brandPersian: classification.brandFa,
    category,
    categorySlug: classification.categorySlug,
    subcategory: p.subcategory || classification.subcategory,
    price: priceNum,
    stock: stockNum,
    inStock: inStockBool,
    active: activeBool,
    slug: baseSlug || id,
    source: p.source || (String(id).startsWith('prod-') ? 'puzzlekala' : undefined),
    ...(Array.isArray(p.variants) ? { variants: cleanVariants } : {}),
  };
}


function publicProduct(p: any, adminView = false): any {
  return publicProductView(p, adminView);
}

function getAdminView(req: Request): boolean {
  return getSession(req)?.role === 'admin';
}

function isUserRegisteredProduct(p: any): boolean {
  if (!p) return false;
  const idStr = String(p.id || '');
  // Supplier products have prefixes like pk- or kasra-
  // User created products have prefix prod- or source === 'puzzlekala'
  return idStr.startsWith('prod-') || p.source === 'puzzlekala';
}

function validateUserProduct(p: any): string | null {
  if (!p || typeof p !== 'object' || Array.isArray(p)) return 'اطلاعات کالا نامعتبر است.';
  const name = String(p.name || '').trim();
  const faName = String(p.persianName || '').trim();
  if (!name) return 'نام انگلیسی/مدل کالا الزامی است.';
  if (!faName) return 'نام فارسی کالا الزامی است.';
  if (name.length > 300 || faName.length > 300) return 'نام کالا بیش از حد طولانی است.';
  const price = Number(p.price);
  if (!Number.isFinite(price) || price < 0 || price > 1e15) return 'قیمت فروش کالا معتبر نیست.';
  const stock = Number(p.stock);
  if (!Number.isFinite(stock) || !Number.isInteger(stock) || stock < 0 || stock > 1e9) return 'موجودی کالا باید یک عدد صحیح بین ۰ و ۱,۰۰۰,۰۰۰,۰۰۰ باشد.';
  if (p.active !== undefined && typeof p.active !== 'boolean') return 'active نامعتبر است.';
  if (p.inStock !== undefined && typeof p.inStock !== 'boolean') return 'inStock نامعتبر است.';
  if (p.slug !== undefined && (typeof p.slug !== 'string' || p.slug.length > 180)) return 'slug نامعتبر است.';
  if (Array.isArray(p.images)) {
    if (p.images.length > 30) return 'حداکثر ۳۰ تصویر برای هر کالا مجاز است.';
    p.images = p.images.map((x: any) => String(x || '').trim()).filter(Boolean).slice(0, 30);
  } else p.images = ['/logo.png'];
  if (p.variants !== undefined) {
    if (!Array.isArray(p.variants) || p.variants.length > 50) return 'تنوع‌های کالا نامعتبر است.';
    for (const v of p.variants) {
      if (!v || typeof v !== 'object') return 'ساختار تنوع کالا نامعتبر است.';
      if (Array.isArray(v.options) && v.options.length > 100) return 'تعداد گزینه‌های تنوع بیش از حد مجاز است.';
      if (v.type && String(v.type).length > 40) return 'نوع تنوع نامعتبر است.';
    }
  }
  return null;
}

// 2. Products
app.get('/api/products', (req: Request, res: Response) => {
  try {
    const rawProducts = readJsonFile<any[]>(getFilePath('products.json'), []);
    const sanitized = rawProducts
      .map(sanitizeProduct)
      .filter(Boolean)
      .filter(isUserRegisteredProduct);
    res.json(sanitized.map((p) => publicProduct(p, getAdminView(req))).filter(Boolean));
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to read products', message: err?.message });
  }
});

const requireAdminOrBridge = requireRole('admin');

app.post('/api/products', requireAdminOrBridge, (req: Request, res: Response) => {
  try {
    const allStoredProducts = readJsonFile<any[]>(getFilePath('products.json'), []);
    const supplierManagedProducts = allStoredProducts.filter((p) => !isUserRegisteredProduct(p));
    let products = allStoredProducts
      .map(sanitizeProduct)
      .filter(Boolean)
      .filter(isUserRegisteredProduct);

    // If client sends bulk array of products:
    if (Array.isArray(req.body)) {
      const sanitizedList = req.body.map(sanitizeProduct).filter(Boolean).filter(isUserRegisteredProduct);
      if (sanitizedList.length !== req.body.length) return res.status(422).json({ success: false, error: 'یک یا چند کالا ساختار معتبر ندارد.' });
      if (sanitizedList.some((item) => supplierManagedProducts.some((supplierProduct) => String(supplierProduct?.id) === String(item.id)))) {
        return res.status(409).json({ success: false, error: 'شناسه یکی از کالاها متعلق به کاتالوگ تأمین‌کننده است و نمی‌تواند شناسه کالای داخلی باشد.' });
      }
      for (const item of sanitizedList) {
        const validationError = validateUserProduct(item);
        if (validationError) return res.status(422).json({ success: false, error: validationError });
      }
      const ids = new Set<string>();
      const slugs = new Set<string>();
      for (const item of sanitizedList) {
        if (ids.has(item.id)) return res.status(409).json({ success: false, error: `شناسه تکراری: ${item.id}` });
        if (item.slug && slugs.has(item.slug)) return res.status(409).json({ success: false, error: `slug تکراری: ${item.slug}` });
        ids.add(item.id); if (item.slug) slugs.add(item.slug);
      }
      const existingSlugs = new Set(products.filter((p) => !ids.has(p.id) && p.slug).map((p) => String(p.slug)));
      for (const item of sanitizedList) if (item.slug && existingSlugs.has(String(item.slug))) return res.status(409).json({ success: false, error: `slug تکراری: ${item.slug}` });
      const mergedMap = new Map<string, any>();
      for (const p of products) mergedMap.set(p.id, p);
      for (const p of sanitizedList) mergedMap.set(p.id, p);
      const finalList = [...supplierManagedProducts, ...Array.from(mergedMap.values())];
      writeJsonFile(getFilePath('products.json'), finalList);
      recordAuditLog('products_bulk_upsert', `${sanitizedList.length} کالا به‌صورت گروهی ثبت/به‌روزرسانی شد.`, 'admin-ui', { count: sanitizedList.length });
      return res.json({ success: true, count: finalList.length, upserted: sanitizedList.length });
    }

    // If client sends { products: [...] }
    if (req.body && Array.isArray(req.body.products)) {
      const sanitizedList = req.body.products.map(sanitizeProduct).filter(Boolean).filter(isUserRegisteredProduct);
      if (sanitizedList.length !== req.body.products.length) return res.status(422).json({ success: false, error: 'یک یا چند کالا ساختار معتبر ندارد.' });
      if (sanitizedList.some((item) => supplierManagedProducts.some((supplierProduct) => String(supplierProduct?.id) === String(item.id)))) {
        return res.status(409).json({ success: false, error: 'شناسه یکی از کالاها متعلق به کاتالوگ تأمین‌کننده است و نمی‌تواند شناسه کالای داخلی باشد.' });
      }
      for (const item of sanitizedList) {
        const validationError = validateUserProduct(item);
        if (validationError) return res.status(422).json({ success: false, error: validationError });
      }
      const ids = new Set<string>();
      const slugs = new Set<string>();
      for (const item of sanitizedList) {
        if (ids.has(item.id)) return res.status(409).json({ success: false, error: `شناسه تکراری: ${item.id}` });
        if (item.slug && slugs.has(item.slug)) return res.status(409).json({ success: false, error: `slug تکراری: ${item.slug}` });
        ids.add(item.id); if (item.slug) slugs.add(item.slug);
      }
      const existingSlugs = new Set(products.filter((p) => !ids.has(p.id) && p.slug).map((p) => String(p.slug)));
      for (const item of sanitizedList) if (item.slug && existingSlugs.has(String(item.slug))) return res.status(409).json({ success: false, error: `slug تکراری: ${item.slug}` });
      const mergedMap = new Map<string, any>();
      for (const p of products) mergedMap.set(p.id, p);
      for (const p of sanitizedList) mergedMap.set(p.id, p);
      const finalList = [...supplierManagedProducts, ...Array.from(mergedMap.values())];
      writeJsonFile(getFilePath('products.json'), finalList);
      recordAuditLog('products_bulk_upsert', `${sanitizedList.length} کالا به‌صورت گروهی ثبت/به‌روزرسانی شد.`, 'admin-ui', { count: sanitizedList.length });
      return res.json({ success: true, count: finalList.length, upserted: sanitizedList.length });
    }

    const requestedId = String(req.body?.id || '').trim();
    const mayReuseId = requestedId.startsWith('prod-') || products.some((p) => String(p.id) === requestedId);
    const newProduct = sanitizeProduct({ ...(req.body || {}), id: mayReuseId ? requestedId : undefined, source: 'puzzlekala' });
    if (!newProduct) {
      return res.status(400).json({ success: false, error: 'Invalid product data' });
    }
    const validationError = validateUserProduct(newProduct);
    if (validationError) {
      return res.status(422).json({ success: false, error: validationError, message: validationError });
    }
    // محصولات ثبت‌شده از پنل باید با شناسه داخلی فروشگاه ذخیره شوند؛ شناسه خارجی تأمین‌کننده را نمی‌پذیریم.
    if (!isUserRegisteredProduct(newProduct)) {
      newProduct.id = `prod-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      newProduct.source = 'puzzlekala';
    }
    const duplicateSlug = products.findIndex((p) => p.id !== newProduct.id && newProduct.slug && String(p.slug) === String(newProduct.slug));
    if (duplicateSlug >= 0) return res.status(409).json({ success: false, error: 'slug کالا تکراری است.' });
    const existingIndex = products.findIndex((p) => p.id === newProduct.id);
    if (existingIndex >= 0) {
      products[existingIndex] = { ...products[existingIndex], ...newProduct };
    } else {
      products.push(newProduct);
    }
    writeJsonFile(getFilePath('products.json'), [...supplierManagedProducts, ...products]);
    recordAuditLog('product_upserted', `کالای «${newProduct.id}» ثبت/به‌روزرسانی شد.`, 'admin-ui', { productId: newProduct.id });
    res.json({ success: true, product: publicProduct(newProduct, true) });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to save product', message: err?.message });
  }
});

app.put('/api/products/:id', requireAdminOrBridge, (req: Request, res: Response) => {
  try {
    const products = readJsonFile<any[]>(getFilePath('products.json'), []);
    const { id } = req.params;
    const index = products.findIndex((p) => String(p?.id) === String(id) && isUserRegisteredProduct(p));
    if (index === -1) {
      return res.status(404).json({ error: 'Store-managed product not found' });
    }
    const updated = sanitizeProduct({ ...products[index], ...req.body, id, source: 'puzzlekala' });
    if (!isUserRegisteredProduct(updated)) return res.status(400).json({ success: false, error: 'شناسه کالا برای محصول داخلی معتبر نیست.' });
    const validationError = validateUserProduct(updated);
    if (validationError) return res.status(422).json({ success: false, error: validationError, message: validationError });
    const duplicateSlug = products.findIndex((p, i) => i !== index && updated.slug && String(p.slug) === String(updated.slug));
    if (duplicateSlug >= 0) return res.status(409).json({ success: false, error: 'slug کالا تکراری است.' });
    products[index] = updated;
    writeJsonFile(getFilePath('products.json'), products);
    recordAuditLog('product_updated', `کالای «${id}» به‌روزرسانی شد.`, 'admin-ui', { productId: id });
    res.json({ success: true, product: publicProduct(updated, true) });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update product', message: err?.message });
  }
});

app.delete('/api/products/:id', requireAdminOrBridge, (req: Request, res: Response) => {
  try {
    let products = readJsonFile<any[]>(getFilePath('products.json'), []);
    const { id } = req.params;
    const before = products.length;
    const removed = products.find((p) => p.id === id);
    // کالای ساخته‌شده‌ی خودکار از تأمین‌کننده: برای جلوگیری از ساخته شدن دوباره، کلیدش در فهرست نادیده‌ها ثبت می‌شود
    if (removed?.autoCreated && removed.autoKey) {
      const ig = readJsonFile<string[]>(getFilePath(IGNORED_FILE), []);
      if (!ig.includes(removed.autoKey)) writeJsonFile(getFilePath(IGNORED_FILE), [...ig, removed.autoKey]);
    }
    products = products.filter((p) => p.id !== id);
    if (products.length === before) return res.status(404).json({ success: false, error: 'Product not found' });
    writeJsonFile(getFilePath('products.json'), products);
    recordAuditLog('product_deleted', `کالای «${id}» حذف شد.`, 'admin-ui', { productId: id });
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to delete product', message: err?.message });
  }
});

// Virtual Employees (کارمندان مجازی و ایجنت‌های هوشمند)
app.get('/api/virtual-employees', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const employees = getVirtualEmployees();
    res.json({ success: true, employees });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message, employees: [] });
  }
});

app.post('/api/virtual-employees', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const created = addVirtualEmployee(req.body);
    res.json({ success: true, employee: created });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});

app.put('/api/virtual-employees/:id', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const updated = updateVirtualEmployee(req.params.id, req.body);
    if (!updated) return res.status(404).json({ success: false, error: 'Employee not found' });
    res.json({ success: true, employee: updated });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});

app.delete('/api/virtual-employees/:id', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const ok = deleteVirtualEmployee(req.params.id);
    if (!ok) return res.status(404).json({ success: false, error: 'Employee not found' });
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});

app.post('/api/virtual-employees/:id/command', requireRole('admin'), async (req: Request, res: Response) => {
  try {
    const { command } = req.body;
    if (!command || typeof command !== 'string' || !command.trim()) {
      return res.status(400).json({ success: false, error: 'متن دستور الزامی است.' });
    }
    const response = await executeEmployeeCommand(req.params.id, command.trim());
    res.json({ success: true, ...response });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});

// Supplier records contain credentials and integration metadata. Never expose those
// fields to the storefront or unauthenticated clients.

function normalizeSupplierId(value: any): string {
  return String(value ?? '').trim().toLowerCase().replace(/[^a-z0-9_-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '').slice(0, 64);
}

function validateSupplierUrl(value: any): string | null {
  const raw = String(value ?? '').trim();
  if (!raw) return 'نشانی تأمین‌کننده الزامی است.';
  try {
    const u = new URL(raw);
    if (!['https:', 'http:'].includes(u.protocol)) return 'فقط HTTP/HTTPS مجاز است.';
    if (u.username || u.password) return 'قرار دادن نام کاربری/رمز در URL مجاز نیست.';
    const host = u.hostname.toLowerCase().replace(/^\[|\]$/g, '').replace(/\.$/, '');
    // Supplier adapters use direct HTTP(S) requests. Reject literal IPs outside
    // the public unicast range and special-use/local names; redirects are not followed.
    const ipv4 = /^(\d{1,3}\.){3}\d{1,3}$/.test(host) ? host.split('.').map(Number) : null;
    const validIPv4 = ipv4 !== null && ipv4.every((n) => n >= 0 && n <= 255);
    let privateIPv4 = false;
    if (ipv4 && validIPv4) {
      const [a, b] = ipv4;
      privateIPv4 = a === 0 || a === 10 || a === 127 || a >= 224 ||
        (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) ||
        (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) ||
        (a === 198 && (b === 18 || b === 19 || b === 51)) || (a === 203 && b === 0);
    }
    const blocked = host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local') || host.endsWith('.internal') || host.endsWith('.test') ||
      host.includes(':') || (ipv4 !== null && (!validIPv4 || privateIPv4)) ||
      host === 'metadata.google.internal' || host === 'metadata.google.com';
    if (blocked) return 'اتصال به نشانی‌های داخلی/خصوصی مجاز نیست.';
    return null;
  } catch { return 'نشانی تأمین‌کننده نامعتبر است.'; }
}

const SUPPLIER_CONNECTION_TYPES = new Set(['api_feed', 'rest_api', 'json_feed', 'graphql']);
function validateSupplierPayload(body: any, opts: { partial?: boolean } = {}): string | null {
  if (!body || typeof body !== 'object' || Array.isArray(body)) return 'اطلاعات تأمین‌کننده نامعتبر است.';
  if (!opts.partial || body.name !== undefined) {
    const name = String(body.name ?? '').trim();
    if (name.length < 2 || name.length > 120) return 'نام تأمین‌کننده باید بین ۲ تا ۱۲۰ کاراکتر باشد.';
  }
  if (!opts.partial || body.baseUrl !== undefined) {
    const e = validateSupplierUrl(body.baseUrl);
    if (e) return e;
  }
  if (body.connectionType !== undefined && !SUPPLIER_CONNECTION_TYPES.has(String(body.connectionType))) {
    return 'نوع اتصال تأمین‌کننده نامعتبر است.';
  }
  if (body.enabled !== undefined && typeof body.enabled !== 'boolean') return 'فیلد enabled باید boolean باشد.';
  return null;
}

function sanitizeSupplierWrite(body: any, existing?: any): any {
  const source = body && typeof body === 'object' ? body : {};
  const out: any = existing ? { ...existing } : {};
  const mutable = ['name', 'baseUrl', 'connectionType', 'enabled'];
  for (const key of mutable) if (source[key] !== undefined) out[key] = key === 'name' || key === 'baseUrl' || key === 'connectionType' ? String(source[key]).trim() : Boolean(source[key]);
  // Credentials are accepted only through the dedicated credentials endpoint.
  if (!existing) {
    out.id = normalizeSupplierId(source.id) || `sup-${Date.now()}`;
    out.lastSyncAt = null; out.lastSuccessAt = null; out.lastError = null;
    out.status = 'disconnected'; out.sourceTotalProducts = 0; out.sourceInStockProducts = 0;
    out.sourceOutOfStockProducts = 0; out.matchedCount = 0; out.ambiguousCount = 0;
    out.variantsCount = 0; out.inStockColorsCount = 0;
  }
  return out;
}

function publicSupplier(s: any): any {
  if (!s || typeof s !== 'object') return null;
  // Whitelist only operational/status fields. This prevents future supplier
  // integrations from accidentally exposing a newly-added credential field.
  const allowed = [
    'id', 'name', 'enabled', 'status', 'connectionType', 'lastSyncAt',
    'lastSuccessAt', 'lastError', 'sourceTotalProducts', 'sourceInStockProducts',
    'sourceOutOfStockProducts', 'matchedCount', 'ambiguousCount', 'variantsCount',
    'inStockColorsCount', 'updatedAt'
  ];
  const out = Object.fromEntries(allowed.filter((key) => Object.prototype.hasOwnProperty.call(s, key)).map((key) => [key, s[key]]));
  // The admin UI needs the endpoint to display/edit the supplier URL. Return it
  // only when it is a valid HTTP(S) URL with no embedded credentials.
  try {
    const base = new URL(String(s.baseUrl || ''));
    if (['http:', 'https:'].includes(base.protocol) && !base.username && !base.password) {
      out.baseUrl = base.toString();
    }
  } catch { /* invalid legacy URLs are intentionally omitted */ }
  return out;
}
function publicSuppliers(list: any[]): any[] { return list.map(publicSupplier).filter(Boolean); }

// 3. Suppliers & Sync
app.get('/api/suppliers', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const suppliers = getSuppliersList();
    res.json({ success: true, suppliers: publicSuppliers(suppliers), total: suppliers.length });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to get suppliers', message: err?.message, suppliers: [] });
  }
});

app.post('/api/suppliers/:id/toggle', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const suppliers = getSuppliersList();
    const { id } = req.params;
    const idx = suppliers.findIndex((s) => s.id === id);
    if (idx === -1) {
      return res.status(404).json({ success: false, error: 'Supplier not found' });
    }
    suppliers[idx].enabled = !suppliers[idx].enabled;
    // Enabling a supplier does not prove connectivity. Mark it as unavailable/pending
    // until an actual sync succeeds; never display a false "connected" state.
    suppliers[idx].status = suppliers[idx].enabled ? 'unavailable' : 'disconnected';
    if (suppliers[idx].enabled) {
      suppliers[idx].lastError = 'فعال شد؛ اتصال در اولین همگام‌سازی بررسی می‌شود.';
    } else {
      suppliers[idx].lastError = null;
    }
    saveSuppliersList(suppliers);
    recordAuditLog('supplier_toggled', `وضعیت تأمین‌کننده «${suppliers[idx].name}» تغییر کرد.`, 'admin-ui', { supplierId: id, enabled: suppliers[idx].enabled });
    res.json({ success: true, supplier: publicSupplier(suppliers[idx]), suppliers: publicSuppliers(suppliers) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to toggle supplier', message: err?.message });
  }
});

app.delete('/api/suppliers/:id', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const id = String(req.params.id || '').trim();
    const suppliers = getSuppliersList();
    const existing = suppliers.find((s) => s.id === id);
    if (!existing) return res.status(404).json({ success: false, error: 'Supplier not found' });
    if (suppliers.length <= 1) return res.status(409).json({ success: false, error: 'حداقل یک تأمین‌کننده باید باقی بماند.' });
    const products = readJsonFile<any[]>(getFilePath('products.json'), []);
    const references = products.filter((p) => p?.supplierMatches && p.supplierMatches[id]).length;
    if (references > 0) return res.status(409).json({ success: false, error: `این تأمین‌کننده در ${references} کالا مرجع دارد؛ ابتدا تطبیق‌های آن را حذف یا منتقل کنید.` });
    const next = suppliers.filter((s) => s.id !== id);
    saveSuppliersList(next);
    recordAuditLog('supplier_deleted', `تأمین‌کننده «${existing.name}» حذف شد.`, 'admin-ui', { supplierId: id });
    res.json({ success: true, message: 'Supplier deleted', suppliers: publicSuppliers(next) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to delete supplier', message: 'خطا در حذف تأمین‌کننده' });
  }
});

app.post('/api/suppliers', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const error = validateSupplierPayload(req.body, { partial: false });
    if (error) return res.status(422).json({ success: false, error });
    const suppliers = getSuppliersList();
    const id = normalizeSupplierId(req.body?.id) || `sup-${Date.now()}`;
    if (suppliers.some((s) => s.id === id)) return res.status(409).json({ success: false, error: 'شناسه تأمین‌کننده تکراری است.' });
    const name = String(req.body.name).trim().toLowerCase();
    const baseUrl = String(req.body.baseUrl).trim().toLowerCase();
    if (suppliers.some((s) => String(s.name).trim().toLowerCase() === name)) return res.status(409).json({ success: false, error: 'نام تأمین‌کننده تکراری است.' });
    if (suppliers.some((s) => String(s.baseUrl || '').trim().toLowerCase() === baseUrl)) return res.status(409).json({ success: false, error: 'نشانی تأمین‌کننده تکراری است.' });
    const newSup = sanitizeSupplierWrite({ ...req.body, id });
    suppliers.push(newSup);
    saveSuppliersList(suppliers);
    recordAuditLog('supplier_created', `تأمین‌کننده «${newSup.name}» ایجاد شد.`, 'admin-ui', { supplierId: newSup.id });
    res.status(201).json({ success: true, supplier: publicSupplier(newSup), suppliers: publicSuppliers(suppliers) });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to save supplier', message: 'خطا در ذخیره تأمین‌کننده' });
  }
});

app.put('/api/suppliers/:id', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const suppliers = getSuppliersList();
    const id = String(req.params.id || '').trim();
    const idx = suppliers.findIndex((s) => s.id === id);
    if (idx === -1) return res.status(404).json({ error: 'Supplier not found' });
    const error = validateSupplierPayload(req.body, { partial: true });
    if (error) return res.status(422).json({ success: false, error });
    if (req.body?.id !== undefined && normalizeSupplierId(req.body.id) !== id) return res.status(400).json({ success: false, error: 'شناسه تأمین‌کننده قابل تغییر نیست.' });
    if (req.body?.name !== undefined) {
      const name = String(req.body.name).trim().toLowerCase();
      if (suppliers.some((s, i) => i !== idx && String(s.name).trim().toLowerCase() === name)) return res.status(409).json({ success: false, error: 'نام تأمین‌کننده تکراری است.' });
    }
    if (req.body?.baseUrl !== undefined) {
      const url = String(req.body.baseUrl).trim().toLowerCase();
      if (suppliers.some((s, i) => i !== idx && String(s.baseUrl || '').trim().toLowerCase() === url)) return res.status(409).json({ success: false, error: 'نشانی تأمین‌کننده تکراری است.' });
    }
    const updated = sanitizeSupplierWrite(req.body, suppliers[idx]);
    suppliers[idx] = updated;
    saveSuppliersList(suppliers);
    recordAuditLog('supplier_updated', `تأمین‌کننده «${updated.name}» به‌روزرسانی شد.`, 'admin-ui', { supplierId: id, changedFields: Object.keys(req.body || {}).filter((k) => !['password','apiKey','token','secret'].includes(k)) });
    res.json({ success: true, supplier: publicSupplier(updated), suppliers: publicSuppliers(suppliers) });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update supplier', message: 'خطا در به‌روزرسانی تأمین‌کننده' });
  }
});

// Multi-supplier sync endpoints
const handleSync = async (req: Request, res: Response) => {
  try {
    const result = await executeMultiSupplierSync();
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Sync failed' });
  }
};

// پیش‌نمایش امن: همان منطق دریافت و تطبیق را اجرا می‌کند اما هیچ فایل داده‌ای را ذخیره نمی‌کند.
app.post('/api/suppliers/sync-preview', requireRole('admin'), async (_req: Request, res: Response) => {
  try {
    const result = await executeMultiSupplierSync(undefined, { dryRun: true });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Sync preview failed' });
  }
});

// تاریخچهٔ تغییر قیمت/موجودی و موارد نیازمند بررسی؛ فقط مدیر دسترسی دارد.
app.get('/api/suppliers/price-stock-history', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const rows = readJsonFile<any[]>(path.join(DATA_DIR, 'supplier_price_stock_history.json'), []);
    const productId = String(req.query.productId || '').trim();
    const supplierId = String(req.query.supplierId || '').trim();
    const anomaliesOnly = String(req.query.anomaliesOnly || '').toLowerCase() === 'true';
    const limitRaw = Number(req.query.limit || 100);
    const limit = Math.max(1, Math.min(500, Number.isFinite(limitRaw) ? Math.floor(limitRaw) : 100));
    const filtered = rows.filter((r) => (!productId || String(r.productId) === productId) && (!supplierId || String(r.supplierId || '') === supplierId) && (!anomaliesOnly || r.anomaly === true));
    res.json({ success: true, total: filtered.length, items: filtered.slice(-limit).reverse() });
  } catch {
    res.status(500).json({ success: false, error: 'خواندن تاریخچه تغییرات ناموفق بود.' });
  }
});

// جزئیات باکس‌های آماری هر تأمین‌کننده: کالاهای هماهنگ، رنگ‌های هماهنگ، کالاهای مبهم
app.get('/api/suppliers/:id/details', requireRole('admin'), (req: Request, res: Response) => {
  const all = readJsonFile<Record<string, any>>(path.join(DATA_DIR, 'supplier_match_details.json'), {});
  const d = all[req.params.id] || { matched: [], colors: [], ambiguous: [], updatedAt: null };

  const products = readJsonFile<any[]>(getFilePath('products.json'), []);
  const prodMap = new Map<string, any>(products.map((p) => [p.id, p]));

  const getProductColorStr = (p: any): string => {
    if (!p) return 'عمومی / تمام رنگ‌ها';
    if (Array.isArray(p.variants)) {
      const colorVar = p.variants.find((v: any) => v.type === 'color' || v.name === 'رنگ' || v.title?.includes('رنگ'));
      if (colorVar && Array.isArray(colorVar.options) && colorVar.options.length > 0) {
        return colorVar.options.map((o: any) => o.name || o.value || o.title).filter(Boolean).join('، ');
      }
    }
    if (Array.isArray(p.colors) && p.colors.length > 0) {
      return p.colors.map((c: any) => (typeof c === 'string' ? c : c.name || c.title)).filter(Boolean).join('، ');
    }
    if (p.color) return String(p.color);
    return 'عمومی / تمام رنگ‌ها';
  };

  const getColorItems = (product: any, defaultPrice: any) => {
    if (!product) return [];
    const items: { name: string; price: number }[] = [];
    if (Array.isArray(product.variants)) {
      const colorVar = product.variants.find((v: any) => v.type === 'color' || v.name === 'رنگ' || v.title?.includes('رنگ'));
      if (colorVar && Array.isArray(colorVar.options) && colorVar.options.length > 0) {
        for (const o of colorVar.options) {
          const name = String(o.name || o.value || o.title || '').trim();
          if (name) {
            const pr = Number(o.price || (o.priceDelta ? (product.price || 0) + o.priceDelta : defaultPrice) || 0);
            items.push({ name, price: pr || defaultPrice });
          }
        }
      }
    }
    if (items.length === 0 && Array.isArray(product.colors) && product.colors.length > 0) {
      for (const c of product.colors) {
        const name = typeof c === 'string' ? c.trim() : String(c.name || c.title || '').trim();
        if (name) {
          const pr = typeof c === 'object' && c.price ? Number(c.price) : defaultPrice;
          items.push({ name, price: pr || defaultPrice });
        }
      }
    }
    return items;
  };

  const enrichedAmbiguous = (d.ambiguous || []).map((row: any) => {
    const p = prodMap.get(row.productId);
    const pName = row.productName || (p ? (p.persianName || p.name) : row.productId);
    const pColor = row.productColor || row.color || (p ? getProductColorStr(p) : 'عمومی / تمام رنگ‌ها');
    const pPrice = row.productPrice !== undefined ? row.productPrice : (p ? p.price : null);
    const pColorItems = getColorItems(p, pPrice);

    const candidates = (row.candidates || []).map((c: any) => {
      let cColor = c.color;
      if (!cColor || cColor === c.title) {
        cColor = extractColorFromTitle(c.title) || 'پیش‌فرض / نامشخص';
      }
      let cPrice = c.price !== undefined && c.price !== null ? c.price : (c.sourcePrice !== undefined ? c.sourcePrice : null);

      let cColorItems: { name: string; price: number }[] = [];
      if (Array.isArray(c.variants) && c.variants.length > 0) {
        cColorItems = c.variants.map((v: any) => ({
          name: v.name || v.color || v.title,
          price: Number(v.price || v.sourcePrice || cPrice || 0),
        }));
      }

      if (cColorItems.length === 0) {
        const candProduct = products.find(
          (x) =>
            x.id === `prod-ks-${c.id}` ||
            x.id === `prod-ht-${c.id}` ||
            x.id === `prod-eh-${c.id}` ||
            x.id === c.id ||
            x.supplierMatches?.kasra?.supplierProductId === String(c.id) ||
            x.supplierMatches?.hamrahtel?.supplierProductId === String(c.id) ||
            x.name === c.title ||
            x.title === c.title
        );
        if (candProduct) {
          if (!cPrice) cPrice = candProduct.price;
          cColorItems = getColorItems(candProduct, cPrice);
        }
      }

      if (cColorItems.length === 0) {
        const cCols = String(cColor).split(/[،,]/).map((s: string) => s.trim()).filter(Boolean);
        cColorItems = cCols.map((col: string) => ({
          name: col,
          price: cPrice || 0,
        }));
      }

      return {
        ...c,
        color: cColor || 'پیش‌فرض / نامشخص',
        price: cPrice,
        colorItems: cColorItems,
      };
    });

    return {
      ...row,
      productName: pName,
      productColor: pColor,
      productPrice: pPrice,
      productColorItems: pColorItems,
      candidates,
    };
  });

  res.json({ success: true, supplierId: req.params.id, ...d, ambiguous: enrichedAmbiguous });
});

// تأیید دستی یک کالای مبهم: شناسه کالای تأمین‌کننده به کالای پازل کالا «پین» می‌شود و بلافاصله قیمت اعمال می‌گردد
app.post('/api/suppliers/:id/confirm-match', requireRole('admin'), async (req: Request, res: Response) => {
  try {
    const { productId, supplierProductId } = req.body || {};
    if (!productId || supplierProductId === undefined || supplierProductId === null || supplierProductId === '')
      return res.status(400).json({ success: false, message: 'productId و supplierProductId لازم است.' });
    const suppliers = getSuppliersList();
    const supplier = suppliers.find((x) => x.id === req.params.id);
    if (!supplier) return res.status(404).json({ success: false, message: 'تأمین‌کننده یافت نشد.' });
    const products = readJsonFile<any[]>(getFilePath('products.json'), []);
    const p = products.find((x) => x.id === productId);
    if (!p) return res.status(404).json({ success: false, message: 'کالا یافت نشد.' });
    if (!isUserRegisteredProduct(p)) return res.status(422).json({ success: false, message: 'فقط کالای اصلی فروشگاه قابل تطبیق است.' });
    const supplierProductKey = String(supplierProductId).trim();
    if (!supplierProductKey || supplierProductKey.length > 160) return res.status(422).json({ success: false, message: 'شناسه کالای تأمین‌کننده نامعتبر است.' });
    p.supplierMatches = { ...(p.supplierMatches || {}), [req.params.id]: { supplierProductId: supplierProductKey, confirmedAt: new Date().toISOString(), confirmedBy: 'admin' } };
    writeJsonFile(getFilePath('products.json'), products);
    recordAuditLog('supplier_match_confirmed', `تطبیق کالای «${productId}» با «${supplierProductKey}» در «${supplier.name}» تأیید شد.`, 'admin-ui', { productId, supplierId: supplier.id, supplierProductId: supplierProductKey });

    // اعمال فوری قیمت و موجودی بدون معطلی و بدون انتظار ۵ دقیقه‌ای
    try {
      await executeMultiSupplierSync();
    } catch (syncErr: any) {
      console.error('[PuzzleKala] Immediate sync on confirm-match error:', syncErr?.message);
    }

    res.json({ success: true, message: 'تطبیق تأیید شد و قیمت و موجودی بلافاصله اعمال گردید.' });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err?.message });
  }
});

// ثبت یا به‌روزرسانی نام کاربری و کلمه عبور سایت تأمین‌کننده
app.post('/api/suppliers/:id/credentials', requireRole('admin'), async (req: Request, res: Response) => {
  try {
    const { username, password, baseUrl } = req.body || {};
    if (username !== undefined && String(username).length > 160) return res.status(422).json({ success: false, message: 'نام کاربری بیش از حد طولانی است.' });
    if (password !== undefined && String(password).length > 512) return res.status(422).json({ success: false, message: 'رمز عبور بیش از حد طولانی است.' });
    if (baseUrl !== undefined) { const urlError = validateSupplierUrl(baseUrl); if (urlError) return res.status(422).json({ success: false, message: urlError }); }
    const suppliers = getSuppliersList();
    const sup = suppliers.find((s) => s.id === req.params.id);
    if (!sup) {
      return res.status(404).json({ success: false, message: 'تأمین‌کننده یافت نشد.' });
    }
    if (username !== undefined) sup.username = String(username).trim();
    if (password !== undefined) sup.password = String(password);
    if (baseUrl !== undefined && String(baseUrl).trim()) sup.baseUrl = String(baseUrl).trim();

    saveSuppliersList(suppliers);

    if (sup.id === 'hamrahtel') {
      clearHamrahTelTokenCache();
    }

    recordAuditLog(
      'supplier_credentials_update',
      `اطلاعات ورود برای تأمین‌کننده «${sup.name}» به‌روزرسانی شد.`,
      'admin-ui',
      { supplierId: sup.id }
    );

    // اجرای استعلام زنده بلافاصله با اطلاعات ورود جدید
    let syncError: string | null = null;
    try {
      await executeMultiSupplierSync();
    } catch (e: any) {
      syncError = e?.message || null;
    }

    const updatedList = getSuppliersList();
    const updatedSup = updatedList.find((s) => s.id === req.params.id) || sup;

    res.json({
      success: true,
      message: 'نام کاربری و کلمه عبور با موفقیت ذخیره شد و استعلام زنده انجام گرفت.',
      supplier: publicSupplier(updatedSup),
      syncError,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err?.message || 'خطا در ثبت اطلاعات' });
  }
});

app.post('/api/suppliers/sync', requireRole('admin'), handleSync);
app.post('/api/suppliers/sync-all', requireRole('admin'), handleSync);
app.post('/api/kasra/sync-now', requireRole('admin'), handleSync);

app.get('/api/suppliers/status', requireRole('admin'), (req: Request, res: Response) => {
  const sups = getSuppliersList();
  res.json({ suppliers: publicSuppliers(sups), connectedCount: sups.filter((s) => s.status === 'connected').length });
});

app.get('/api/sync/status', requireRole('admin'), (req: Request, res: Response) => {
  const sups = getSuppliersList();
  res.json({
    success: true,
    version: {
      overall: 1,
      products: 1,
      orders: 1,
      settings: 1,
      coupons: 1,
      users: 1,
    },
    suppliers: publicSuppliers(sups),
    lastSyncAt: sups[0]?.lastSyncAt || null,
  });
});

app.get('/api/sync/bundle', requireRole('admin', 'customer'), (req: Request, res: Response) => {
  try {
    const rawProducts = readJsonFile<any[]>(getFilePath('products.json'), []);
    const products = rawProducts
      .map(sanitizeProduct)
      .filter(Boolean)
      .filter(isUserRegisteredProduct)
      .map((p) => publicProduct(p, getAdminView(req)))
      .filter(Boolean);
    const allOrders = readJsonFile<any[]>(getFilePath('orders.json'), []);
    const sess = getSession(req);
    const orders = sess?.role === 'admin'
      ? allOrders
      : allOrders.filter((o) => String(o.userId || o.customerId || o.user?.id || '') === String(sess?.userId || ''));
    const rawSettings = readJsonFile<any>(getFilePath('settings.json'), {});
    const { adminPassword, adminToken, apiKey, secret, password, token, accessToken, refreshToken, credentials, supplierCredentials, ...settings } = rawSettings;
    const coupons = flattenCoupons(readJsonFile<any[]>(getFilePath('coupons.json'), []));
    const users = visibleUsers(req);
    res.json({
      success: true,
      data: {
        products,
        orders,
        settings,
        coupons,
        users,
      },
      version: {
        overall: 1,
        products: 1,
        orders: 1,
        settings: 1,
        coupons: 1,
        users: 1,
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to build sync bundle', message: err?.message });
  }
});

app.get('/api/kasra/status', requireRole('admin'), (req: Request, res: Response) => {
  const sups = getSuppliersList();
  const kasra = sups.find((s) => s.id === 'kasra') || sups[0];
  res.json({
    success: true,
    connected: kasra ? Boolean(kasra.enabled && kasra.status === 'connected') : false,
    kasra: publicSupplier(kasra),
  });
});

app.get('/api/kasra/stats', requireRole('admin'), (req: Request, res: Response) => {
  const sups = getSuppliersList();
  const kasra = sups.find((s) => s.id === 'kasra') || sups[0];
  const settings = readJsonFile<any>(getFilePath('settings.json'), {});
  const markupPercentage = Number(settings.supplierMarkupPercent ?? 5);

  const totalCatalogCount = kasra?.sourceTotalProducts ?? 0;
  const inStockCount = kasra?.sourceInStockProducts ?? 0;
  const outOfStockCount = kasra?.sourceOutOfStockProducts ?? Math.max(0, totalCatalogCount - inStockCount);

  res.json({
    success: true,
    totalCatalogCount,
    inStockCount,
    outOfStockCount,
    markupPercentage,
    totalProducts: totalCatalogCount,
    inStockProducts: inStockCount,
    outOfStockProducts: outOfStockCount,
    matchedProducts: kasra?.matchedCount || 0,
    matchedCount: kasra?.matchedCount || 0,
    inStockColorsCount: kasra?.inStockColorsCount || 0,
    status: kasra?.status || 'unknown',
    connected: kasra ? kasra.enabled !== false && kasra.status === 'connected' : false,
    lastSyncAt: kasra?.lastSyncAt || null,
    suppliers: publicSuppliers(sups),
    kasra: publicSupplier(kasra),
  });
});

// 4. Settings
const PUBLIC_SETTING_KEYS = new Set([
  'serverApiUrl', 'storeName', 'storeSlogan', 'storePhone', 'supportPhone', 'supportEmail', 'storeAddress',
  'shippingFee', 'freeShippingThreshold', 'shippingTiers', 'quickShortcuts', 'vatPercent',
  'enableSpecialDeals', 'enableOrderSms', 'enableCOD', 'enableCoupons', 'isStoreActive',
  'bannerNotice', 'storeDescription', 'seoTitle', 'seoDescription', 'socialLinks', 'theme',
]);
const publicSettingsView = (settings: any) => {
  const source = scrubSensitiveFields(settings && typeof settings === 'object' ? settings : {});
  const result: Record<string, any> = {};
  for (const key of PUBLIC_SETTING_KEYS) {
    if (source[key] === undefined) continue;
    if (key === 'shippingTiers' && Array.isArray(source.shippingTiers)) {
      result.shippingTiers = source.shippingTiers.filter((tier: any) => tier && tier.isActive !== false).map((tier: any) => ({
        id: tier.id, title: tier.title, minPrice: tier.minPrice, maxPrice: tier.maxPrice,
        fee: tier.fee, estimatedDelivery: tier.estimatedDelivery, description: tier.description,
        method: tier.method, methodId: tier.methodId, code: tier.code, isActive: tier.isActive,
      }));
    } else if (key === 'quickShortcuts' && Array.isArray(source.quickShortcuts)) {
      result.quickShortcuts = source.quickShortcuts.filter((item: any) => item && item.isActive !== false).map((item: any) => ({
        id: item.id, title: item.title, subtitle: item.subtitle, iconName: item.iconName,
        linkType: item.linkType, linkTarget: item.linkTarget, badge: item.badge,
        badgeColor: item.badgeColor, bgGradient: item.bgGradient, iconColor: item.iconColor, order: item.order,
      }));
    } else result[key] = source[key];
  }
  return result;
};
app.get('/api/settings', (req: Request, res: Response) => {
  try {
    const settings = readJsonFile<any>(getFilePath('settings.json'), {});
    if (getSession(req)?.role === 'admin') return res.json(scrubSensitiveFields(settings));
    res.json(publicSettingsView(settings));
  } catch {
    res.status(500).json({ error: 'Failed to read settings', message: 'تنظیمات قابل خواندن نیست.' });
  }
});

const handleSettingsUpdate = (req: Request, res: Response) => {
  try {
    const current = readJsonFile<any>(getFilePath('settings.json'), {});
    const body = req.body && typeof req.body === 'object' ? { ...req.body } : {};
    delete body.adminPassword; delete body.adminToken; delete body.apiKey; delete body.secret; delete body.password; delete body.token; delete body.accessToken; delete body.refreshToken; delete body.credentials; delete body.supplierCredentials;
    const updated = { ...current, ...body };
    writeJsonFile(getFilePath('settings.json'), updated);
    res.json({ success: true, settings: scrubSensitiveFields(updated) });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to save settings', message: err?.message });
  }
};

app.post('/api/settings', requireRole('admin'), handleSettingsUpdate);
app.put('/api/settings', requireRole('admin'), handleSettingsUpdate);

// قیمت‌گذاری سفارش فقط سمت سرور انجام می‌شود؛ مبلغ ارسالی مرورگر مرجع مالی نیست.
function calculateShippingFee(subtotal: number, settings: any, requestedMethod?: unknown): { fee: number; method: string; tier?: any } | null {
  const tiers = Array.isArray(settings?.shippingTiers) ? settings.shippingTiers.filter((t: any) => t && t.isActive !== false) : [];
  const method = String(requestedMethod || 'standard').trim().slice(0, 60) || 'standard';
  if (tiers.length) {
    const matching = tiers.filter((t: any) => {
      const min = Number(t.minPrice ?? 0), max = Number(t.maxPrice ?? 0);
      const inRange = Number.isFinite(min) && subtotal >= min && (max <= 0 || subtotal < max || (max === min && subtotal === max));
      const methodMatches = !t.methodId && !t.method && !t.code || String(t.methodId || t.method || t.code) === method;
      return inRange && methodMatches && Number.isFinite(Number(t.fee)) && Number(t.fee) >= 0;
    });
    const tier = matching[0];
    if (tier) return { fee: Math.round(Number(tier.fee)), method, tier: { id: tier.id, title: String(tier.title || method).slice(0, 120), estimatedDelivery: tier.estimatedDelivery || null } };
    // Once explicit shipping tiers are configured, an unmatched/disabled method
    // must not fall through to the legacy flat fee (which could undercharge shipping).
    return null;
  }
  const freeThreshold = Number(settings?.freeShippingThreshold);
  if (Number.isFinite(freeThreshold) && freeThreshold > 0 && subtotal >= freeThreshold) return { fee: 0, method };
  const fee = Number(settings?.shippingFee ?? 0);
  if (!Number.isFinite(fee) || fee < 0) return null;
  return { fee: Math.round(fee), method };
}

function calculateCouponDiscount(codeInput: unknown, subtotal: number, items: any[], coupons: any[], settings: any): { code: string | null; discount: number; coupon?: any; error?: string } {
  const code = String(codeInput || '').trim().toUpperCase().slice(0, 80);
  if (!code) return { code: null, discount: 0 };
  if (settings?.enableCoupons === false) return { code: null, discount: 0, error: 'استفاده از کد تخفیف در حال حاضر غیرفعال است.' };
  const now = Date.now();
  const coupon = flattenCoupons(coupons).find((c: any) => String(c.code || '').trim().toUpperCase() === code && c.isActive !== false && c.active !== false);
  if (!coupon) return { code: null, discount: 0, error: 'کد تخفیف معتبر نیست.' };
  const start = coupon.startAt || coupon.startDate, end = coupon.endAt || coupon.endDate;
  // Fail closed for malformed configured dates; invalid dates must never disable the validity window.
  if (start) { const startMs = Date.parse(String(start)); if (!Number.isFinite(startMs)) return { code: null, discount: 0, error: 'تاریخ شروع کد تخفیف معتبر نیست.' }; if (now < startMs) return { code: null, discount: 0, error: 'زمان استفاده از این کد تخفیف هنوز شروع نشده است.' }; }
  if (end) { const endMs = Date.parse(String(end)); if (!Number.isFinite(endMs)) return { code: null, discount: 0, error: 'تاریخ پایان کد تخفیف معتبر نیست.' }; if (now > endMs) return { code: null, discount: 0, error: 'مهلت استفاده از این کد تخفیف تمام شده است.' }; }
  const minimum = Number(coupon.minimumOrder ?? coupon.minOrder ?? 0);
  if (Number.isFinite(minimum) && subtotal < minimum) return { code: null, discount: 0, error: 'مبلغ سفارش برای استفاده از این کد تخفیف کافی نیست.' };
  const limit = Number(coupon.usageLimit ?? coupon.maxUses ?? 0), used = Number(coupon.usageCount ?? coupon.usedCount ?? 0);
  if (limit > 0 && used >= limit) return { code: null, discount: 0, error: 'ظرفیت استفاده از این کد تخفیف تمام شده است.' };
  const appliesTo = Array.isArray(coupon.productIds) ? new Set(coupon.productIds.map(String)) : null;
  const eligibleSubtotal = items.reduce((sum, item) => !appliesTo || appliesTo.has(String(item.productId)) ? sum + Number(item.unitPrice) * Number(item.quantity) : sum, 0);
  if (appliesTo && eligibleSubtotal <= 0) return { code: null, discount: 0, error: 'این کد برای کالاهای سفارش‌شده قابل استفاده نیست.' };
  const type = String(coupon.type || coupon.discountType || (coupon.percent != null ? 'percent' : 'fixed')).toLowerCase();
  const rawValue = Number(coupon.value ?? coupon.discountValue ?? coupon.percent ?? 0);
  if (!Number.isFinite(rawValue) || rawValue <= 0) return { code: null, discount: 0, error: 'مقدار کد تخفیف معتبر نیست.' };
  let discount = ['percent', 'percentage', 'درصد', 'percentage_discount'].includes(type) ? Math.floor(eligibleSubtotal * Math.min(rawValue, 100) / 100) : Math.floor(rawValue);
  const maxDiscount = Number(coupon.maxDiscount ?? coupon.maximumDiscount ?? 0);
  if (maxDiscount > 0 && Number.isFinite(maxDiscount)) discount = Math.min(discount, maxDiscount);
  // Discounts cannot exceed eligible merchandise subtotal; shipping is never discounted here.
  discount = Math.max(0, Math.min(Math.round(discount), Math.round(eligibleSubtotal), Math.round(subtotal)));
  return { code, discount, coupon: { id: coupon.id || code, code, type, value: rawValue } };
}

// 5. Orders
app.get('/api/orders', requireRole('admin', 'customer'), (req: Request, res: Response) => {
  try {
    const orders = readJsonFile<any[]>(getFilePath('orders.json'), []);
    const sess = getSession(req);
    if (sess?.role === 'admin') return res.json(orders);
    const mine = orders.filter((o) => String(o.userId || o.customerId || o.user?.id || '') === String(sess?.userId || ''));
    res.json(mine);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to read orders', message: err?.message });
  }
});

app.post('/api/orders/quote', requireRole('admin', 'customer'), (req: Request, res: Response) => {
  try {
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    const items = Array.isArray(body.items) ? body.items : [];
    if (!items.length || items.length > 100) return res.status(422).json({ success: false, message: 'اقلام سفارش نامعتبر است.' });
    const products = readJsonFile<any[]>(getFilePath('products.json'), []);
    const map = new Map(products.map((p) => [String(p.id), p]));
    let subtotal = 0;
    const cleanItems: any[] = [];
    const requestedByProduct = new Map<string, number>();
    for (const item of items) {
      const p = map.get(String(item?.productId || item?.id || ''));
      const price = Number(p?.price), stock = Number(p?.stock);
      const productId = p ? String(p.id) : '';
      const qty = p ? reserveRequestedQuantity(requestedByProduct, productId, item?.quantity ?? item?.qty ?? 1, stock) : null;
      if (!p || qty === null || p.active === false || p.inStock === false || !Number.isFinite(price) || price <= 0) {
        return res.status(422).json({ success: false, message: 'یکی از کالاها نامعتبر یا فاقد موجودی کافی است.' });
      }
      subtotal += price * qty;
      if (!Number.isFinite(subtotal) || !Number.isSafeInteger(Math.round(subtotal)) || subtotal > 1e15) return res.status(422).json({ success: false, message: 'مبلغ سفارش بیش از حد مجاز است.' });
      cleanItems.push({ productId, quantity: qty, unitPrice: price });
    }
    const settings = readJsonFile<any>(getFilePath('settings.json'), {});
    const shipping = calculateShippingFee(subtotal, settings, body.shippingMethod);
    if (!shipping) return res.status(422).json({ success: false, message: 'روش ارسال انتخاب‌شده فعال نیست یا تعرفه معتبر ندارد.' });
    const coupon = calculateCouponDiscount(body.couponCode || body.coupon, subtotal, cleanItems, readJsonFile<any[]>(getFilePath('coupons.json'), []), settings);
    if (coupon.error) return res.status(422).json({ success: false, message: coupon.error });
    return res.json({ success: true, subtotal, discountAmount: coupon.discount, couponCode: coupon.code, shippingFee: shipping.fee, shippingMethod: shipping.method, shippingTier: shipping.tier || null, total: Math.max(0, subtotal - coupon.discount) + shipping.fee });
  } catch { return res.status(500).json({ success: false, message: 'محاسبه مبلغ سفارش انجام نشد.' }); }
});

app.post('/api/orders', requireRole('admin', 'customer'), (req: Request, res: Response) => {
  try {
    const orders = readJsonFile<any[]>(getFilePath('orders.json'), []);
    const sess = getSession(req);
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    if (sess?.role === 'customer') {
      const items = Array.isArray(body.items) ? body.items : [];
      if (!items.length || items.length > 100) return res.status(422).json({ success: false, message: 'اقلام سفارش نامعتبر است.' });
      const products = readJsonFile<any[]>(getFilePath('products.json'), []);
      const map = new Map(products.map((p) => [String(p.id), p]));
      let subtotal = 0;
      const requestedByProduct = new Map<string, number>();
      const cleanItems = items.map((item: any) => {
        const p = map.get(String(item?.productId || item?.id || ''));
        const unitPrice = Number(p?.price);
        const availableStock = Number(p?.stock);
        const productId = p ? String(p.id) : '';
        const qty = p ? reserveRequestedQuantity(requestedByProduct, productId, item?.quantity ?? item?.qty ?? 1, availableStock) : null;
        if (!p || qty === null || p.active === false || p.inStock === false ||
            !Number.isFinite(unitPrice) || unitPrice <= 0) return null;
        subtotal += unitPrice * qty;
        if (!Number.isFinite(subtotal) || !Number.isSafeInteger(Math.round(subtotal)) || subtotal > 1e15) return null;
        return { productId, quantity: qty, unitPrice, name: String(p.persianName || p.name || '') };
      });
      if (cleanItems.some((x: any) => !x)) return res.status(422).json({ success: false, message: 'یکی از کالاها نامعتبر یا فاقد موجودی کافی است.' });
      const settings = readJsonFile<any>(getFilePath('settings.json'), {});
      const shipping = calculateShippingFee(subtotal, settings, body.shippingMethod);
      if (!shipping) return res.status(422).json({ success: false, message: 'روش ارسال انتخاب‌شده فعال نیست یا تعرفه معتبر ندارد.' });
      // Use an address-book entry when supplied; otherwise accept a one-off address.
      // The order stores an immutable snapshot so later address edits do not alter old orders.
      const customerUsers = readJsonFile<any[]>(getFilePath('users.json'), []);
      const customerIndex = customerUsers.findIndex((u) => String(u.id) === String(sess?.userId));
      const customer = customerIndex >= 0 ? customerUsers[customerIndex] : null;
      const addressId = String(body.addressId || '').trim();
      let shippingAddress = typeof body.shippingAddress === 'string' ? body.shippingAddress.trim().slice(0, 1000) : '';
      let shippingAddressSnapshot: any = null;
      if (addressId) {
        const savedAddresses = Array.isArray(customer?.addresses) ? customer.addresses : [];
        const selected = savedAddresses.find((a: any) => String(a.id) === addressId);
        if (!selected) return res.status(422).json({ success: false, message: 'نشانی انتخاب‌شده در حساب شما وجود ندارد.' });
        shippingAddressSnapshot = { ...selected };
        shippingAddress = [selected.province, selected.city, selected.address, selected.unit ? `واحد ${selected.unit}` : ''].filter(Boolean).join('، ').slice(0, 1000);
      } else if (!shippingAddress && customer) {
        const savedAddresses = Array.isArray(customer.addresses) ? customer.addresses : [];
        const selected = savedAddresses.find((a: any) => String(a.id) === String(customer.defaultAddressId || '')) || savedAddresses[0];
        if (selected) {
          shippingAddressSnapshot = { ...selected };
          shippingAddress = [selected.province, selected.city, selected.address, selected.unit ? `واحد ${selected.unit}` : ''].filter(Boolean).join('، ').slice(0, 1000);
        }
      }
      if (!shippingAddress) return res.status(422).json({ success: false, message: 'نشانی ارسال الزامی است.' });
      const couponResult = calculateCouponDiscount(body.couponCode || body.coupon, subtotal, cleanItems as any[], readJsonFile<any[]>(getFilePath('coupons.json'), []), settings);
      if (couponResult.error) return res.status(422).json({ success: false, message: couponResult.error });
      const discountAmount = couponResult.discount;
      const shippingFee = shipping.fee;
      const total = Math.max(0, subtotal - discountAmount) + shippingFee;
      if (!Number.isSafeInteger(Math.round(total)) || total > 1e15) return res.status(422).json({ success: false, message: 'مبلغ نهایی سفارش معتبر نیست.' });
      const newOrder = {
        id: `ord-${Date.now()}-${crypto.randomUUID().slice(0, 8)}`,
        userId: sess.userId,
        items: cleanItems,
        subtotal,
        discountAmount,
        couponCode: couponResult.code,
        couponSnapshot: couponResult.coupon || null,
        shippingFee,
        shippingMethod: shipping.method,
        shippingTierSnapshot: shipping.tier || null,
        total,
        status: 'در حال بررسی',
        paymentStatus: 'pending',
        shippingAddress,
        shippingAddressSnapshot,
        createdAt: new Date().toISOString(),
      };
      const previousOrders = orders.slice();
      orders.unshift(newOrder);
      if (!writeJsonFile(getFilePath('orders.json'), orders)) return res.status(500).json({ success: false, message: 'ذخیره سفارش انجام نشد؛ لطفاً دوباره تلاش کنید.' });
      if (couponResult.code) {
        const couponList = flattenCoupons(readJsonFile<any[]>(getFilePath('coupons.json'), []));
        const selected = couponList.find((c: any) => String(c.code || '').trim().toUpperCase() === couponResult.code);
        if (!selected) {
          const rolledBack = writeJsonFile(getFilePath('orders.json'), previousOrders);
          recordAuditLog('coupon_checkout_rollback', 'سفارش به‌دلیل ناپدیدشدن کوپن پس از محاسبه بازگردانده شد.', String(sess?.userId || 'customer'), { orderId: newOrder.id, rollbackSucceeded: rolledBack });
          return res.status(rolledBack ? 409 : 500).json({ success: false, message: rolledBack ? 'کد تخفیف هنگام ثبت سفارش تغییر کرد؛ سفارش ذخیره نشد. لطفاً مبلغ را دوباره بررسی کنید.' : 'کد تخفیف تغییر کرد و بازگردانی سفارش کامل نشد؛ سفارش نیازمند بررسی مدیر است.' });
        }
        const oldCount = Number(selected.usageCount ?? selected.usedCount ?? 0);
        const limit = Number(selected.usageLimit ?? selected.maxUses ?? 0);
        if (!Number.isFinite(oldCount) || oldCount < 0 || (limit > 0 && oldCount >= limit)) {
          const rolledBack = writeJsonFile(getFilePath('orders.json'), previousOrders);
          recordAuditLog('coupon_checkout_rollback', 'سفارش به‌دلیل تغییر ظرفیت کوپن بازگردانده شد.', String(sess?.userId || 'customer'), { orderId: newOrder.id, rollbackSucceeded: rolledBack });
          return res.status(rolledBack ? 409 : 500).json({ success: false, message: rolledBack ? 'ظرفیت کد تخفیف تغییر کرده است؛ سفارش ذخیره نشد.' : 'ظرفیت کوپن تغییر کرده و بازگردانی سفارش کامل نشد؛ نیازمند بررسی مدیر است.' });
        }
        selected.usageCount = oldCount + 1;
        const couponFile = couponList.map((c: any) => String(c.id ?? c.code) === String(selected.id ?? selected.code) ? selected : c);
        if (!writeJsonFile(getFilePath('coupons.json'), couponFile)) {
          const rolledBack = writeJsonFile(getFilePath('orders.json'), previousOrders);
          recordAuditLog('coupon_checkout_rollback', 'ثبت مصرف کوپن شکست خورد و سفارش بازگردانده شد.', String(sess?.userId || 'customer'), { orderId: newOrder.id, rollbackSucceeded: rolledBack });
          return res.status(500).json({ success: false, message: rolledBack ? 'ثبت مصرف کد تخفیف انجام نشد؛ سفارش بازگردانده شد.' : 'ثبت مصرف کد تخفیف و بازگردانی سفارش هر دو با مشکل مواجه شدند؛ سفارش نیازمند بررسی مدیر است.' });
        }
      }
      recordAuditLog('order_created', `سفارش ${newOrder.id} ثبت شد.`, String(sess?.userId || 'customer'), { orderId: newOrder.id, total, subtotal, discountAmount, shippingFee, couponCode: couponResult.code, itemCount: cleanItems.length });
      return res.json({ success: true, order: newOrder });
    }
    if (!Array.isArray(body.items) || body.items.length < 1 || body.items.length > 100) return res.status(422).json({ success: false, message: 'اقلام سفارش مدیریتی نامعتبر است.' });
    const total = Number(body.total), subtotal = Number(body.subtotal ?? body.total);
    if (!isValidOrderAmount(total) || !isValidOrderAmount(subtotal)) return res.status(422).json({ success: false, message: 'مبالغ سفارش مدیریتی معتبر نیستند.' });
    const itemSnapshot = validateOrderItemSnapshot(body.items, subtotal);
    if (!itemSnapshot.valid) return res.status(422).json({ success: false, message: 'اقلام سفارش مدیریتی با مبلغ کالاها هم‌خوانی ندارند یا مشخصات قیمت/تعداد نامعتبر است.' });
    for (const field of ['discountAmount', 'shippingFee']) {
      if (body[field] !== undefined && (!Number.isFinite(Number(body[field])) || Number(body[field]) < 0 || Number(body[field]) > 1e15)) return res.status(422).json({ success: false, message: `مقدار ${field} معتبر نیست.` });
    }
    if (body.discountAmount !== undefined && Number(body.discountAmount) > subtotal) return res.status(422).json({ success: false, message: 'تخفیف نمی‌تواند از مبلغ کالاها بیشتر باشد.' });
    const discountAmount = Number(body.discountAmount ?? 0);
    const shippingFee = Number(body.shippingFee ?? 0);
    const expectedTotal = Math.max(0, subtotal - discountAmount) + shippingFee;
    if (!isConsistentOrderTotal(subtotal, discountAmount, shippingFee, total) || Math.abs(Math.round(total) - Math.round(expectedTotal)) > 1) return res.status(422).json({ success: false, message: 'جمع سفارش با مبلغ کالاها، تخفیف و ارسال هم‌خوانی ندارد.' });
    const orderId = String(body.id || `ord-${Date.now()}-${crypto.randomUUID().slice(0, 8)}`).trim().slice(0, 160);
    if (!orderId || orders.some((o: any) => String(o.id) === orderId)) return res.status(409).json({ success: false, message: 'شناسه سفارش تکراری یا نامعتبر است.' });
    const allowedInitialStatuses = ['در حال بررسی'];
    const requestedStatus = String(body.status || 'در حال بررسی');
    if (!allowedInitialStatuses.includes(requestedStatus)) return res.status(422).json({ success: false, message: 'وضعیت اولیه سفارش معتبر نیست.' });
    const allowedFields = ['userId','customerId','customerName','customerPhone','customerEmail','items','discountAmount','couponCode','couponSnapshot','shippingFee','shippingMethod','shippingTierSnapshot','shippingAddress','shippingAddressSnapshot','note','adminNotes','trackingNumber','trackingCode','shippingTrackingNumber','shippingProvider'];
    const newOrder: Record<string, any> = {};
    for (const key of allowedFields) if (body[key] !== undefined) newOrder[key] = body[key];
    Object.assign(newOrder, { id: orderId, total: Math.round(total), subtotal: Math.round(subtotal), discountAmount, shippingFee, status: requestedStatus, paymentStatus: 'pending', refundStatus: 'none', createdAt: new Date().toISOString() });
    orders.unshift(newOrder);
    if (!writeJsonFile(getFilePath('orders.json'), orders)) return res.status(500).json({ success: false, message: 'ذخیره سفارش مدیریتی انجام نشد.' });
    recordAuditLog('order_created_by_admin', `سفارش ${newOrder.id} توسط مدیر ثبت شد.`, String(sess?.userId || 'admin'), { orderId: newOrder.id, total: newOrder.total });
    res.json({ success: true, order: newOrder });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to save order', message: err?.message });
  }
});

// Legacy SyncBridge sends the complete order list with PUT /api/orders. Only an admin session may use this.
app.put('/api/orders', requireRole('admin'), (req: Request, res: Response) => {
  try {
    if (!Array.isArray(req.body?.orders) || req.body.orders.length > 10000) return res.status(422).json({ success: false, message: 'لیست سفارش‌ها نامعتبر است.' });
    const existing = readJsonFile<any[]>(getFilePath('orders.json'), []);
    const byId = new Map(existing.map((o) => [String(o.id), o]));
    const actor = String(getSession(req)?.userId || 'admin');
    const seenInput = new Set<string>();
    const statuses: readonly string[] = ORDER_STATUS_ALIASES;
    const normalized: any[] = [];
    for (const raw of req.body.orders) {
      if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return res.status(422).json({ success: false, message: 'یکی از سفارش‌های همگام‌سازی نامعتبر است.' });
      const id = String(raw.id || '').trim();
      if (!id || id.length > 160 || seenInput.has(id)) return res.status(422).json({ success: false, message: 'شناسهٔ سفارش خالی، طولانی یا تکراری است.' });
      seenInput.add(id);
      const previous = byId.get(id);
      const requestedStatus = String(raw.status || (previous ? (previous.status || 'در حال بررسی') : 'در حال بررسی'));
      if (!statuses.includes(requestedStatus)) return res.status(422).json({ success: false, message: `وضعیت سفارش ${id} معتبر نیست.` });
      if (!previous) {
        if (!Array.isArray(raw.items) || raw.items.length < 1 || raw.items.length > 100) return res.status(422).json({ success: false, message: `اقلام سفارش جدید ${id} معتبر نیست.` });
        const total = Number(raw.total), subtotal = Number(raw.subtotal ?? raw.total);
        if (!isValidOrderAmount(total) || !isValidOrderAmount(subtotal)) return res.status(422).json({ success: false, message: `مبالغ سفارش جدید ${id} معتبر نیست.` });
        const itemSnapshot = validateOrderItemSnapshot(raw.items, subtotal);
        if (!itemSnapshot.valid) return res.status(422).json({ success: false, message: `اقلام سفارش ${id} با مبلغ کالاها هم‌خوانی ندارند یا مشخصات قیمت/تعداد نامعتبر است.` });
        for (const field of ['discountAmount', 'shippingFee']) if (raw[field] !== undefined && (!Number.isFinite(Number(raw[field])) || Number(raw[field]) < 0 || Number(raw[field]) > 1e15)) return res.status(422).json({ success: false, message: `مقدار ${field} در سفارش ${id} معتبر نیست.` });
        const discountAmount = Number(raw.discountAmount ?? 0), shippingFee = Number(raw.shippingFee ?? 0);
        if (discountAmount > subtotal) return res.status(422).json({ success: false, message: `تخفیف سفارش ${id} از مبلغ کالاها بیشتر است.` });
        const expectedTotal = Math.max(0, subtotal - discountAmount) + shippingFee;
        if (!isConsistentOrderTotal(subtotal, discountAmount, shippingFee, total) || Math.abs(Math.round(total) - Math.round(expectedTotal)) > 1) return res.status(422).json({ success: false, message: `جمع سفارش ${id} با اجزای مبلغ هم‌خوانی ندارد.` });
        if (!['در حال بررسی', 'pending', 'under_review'].includes(requestedStatus)) return res.status(422).json({ success: false, message: 'سفارش جدید باید با وضعیت در حال بررسی ثبت شود.' });
        const fields = ['userId','customerId','customerName','customerPhone','customerEmail','items','discountAmount','couponCode','couponSnapshot','shippingFee','shippingMethod','shippingTierSnapshot','shippingAddress','shippingAddressSnapshot','note','adminNotes','trackingNumber','trackingCode','shippingTrackingNumber','shippingProvider'];
        const created: Record<string, any> = {};
        for (const key of fields) if (raw[key] !== undefined) created[key] = raw[key];
        Object.assign(created, { id, total: Math.round(total), subtotal: Math.round(subtotal), discountAmount, shippingFee, status: 'در حال بررسی', paymentStatus: 'pending', refundStatus: 'none', createdAt: new Date().toISOString() });
        recordAuditLog('order_created_via_sync', `سفارش ${id} از مسیر همگام‌سازی مدیر ثبت شد.`, actor, { orderId: id, total: created.total });
        normalized.push(created);
        continue;
      }
      if (!canTransitionOrderStatus(previous.status, requestedStatus)) return res.status(409).json({ success: false, message: `تغییر وضعیت سفارش ${id} در این مسیر مجاز نیست.` });
      const next = normalizeOrderStatus(requestedStatus), current = normalizeOrderStatus(previous.status);
      const safe: any = { ...previous, status: requestedStatus, updatedAt: new Date().toISOString() };
      if (typeof raw.archived === 'boolean') safe.archived = raw.archived;
      if (raw.archived === true && !previous.archived) { safe.archivedAt = new Date().toISOString(); safe.archivedBy = actor; }
      for (const key of ['trackingNumber','trackingCode','shippingTrackingNumber','shippingProvider','adminNotes','note','cancelReason']) {
        if (raw[key] !== undefined && typeof raw[key] === 'string') safe[key] = raw[key].slice(0, key === 'adminNotes' || key === 'note' ? 2000 : 500);
      }
      if (next === 'cancelled' && current !== 'cancelled') {
        const reason = String(raw.cancelReason || '').trim().slice(0, 500);
        if (reason.length < 5) return res.status(422).json({ success: false, message: `برای لغو سفارش ${id} ثبت دلیل الزامی است.` });
        safe.cancelReason = reason; safe.cancelledAt = new Date().toISOString(); safe.cancelledBy = actor;
      }
      if (raw.status !== previous.status || raw.archived !== previous.archived) recordAuditLog('order_updated_via_sync', `وضعیت سفارش ${id} از مسیر همگام‌سازی تغییر کرد.`, actor, { orderId: id, previousStatus: previous.status, newStatus: safe.status, previousArchived: previous.archived, newArchived: safe.archived });
      normalized.push(safe);
    }
    const seen = new Set(normalized.map((o: any) => String(o.id)));
    const finalOrders = [...normalized, ...existing.filter((o) => !seen.has(String(o.id)))];
    if (!writeJsonFile(getFilePath('orders.json'), finalOrders)) return res.status(500).json({ success: false, message: 'ذخیره سفارش‌های همگام‌سازی انجام نشد.' });
    res.json({ success: true, count: finalOrders.length, retainedMissingOrders: finalOrders.length - normalized.length });
  } catch { return res.status(500).json({ success: false, error: 'Failed to sync orders' }); }
});

// مشتری فقط تا زمانی که سفارش هنوز در مرحله بررسی است می‌تواند درخواست لغو مستقیم ثبت کند.
// این مسیر هیچ‌گاه وضعیت بازپرداخت را به‌صورت خودکار «انجام‌شده» نمی‌کند.
app.post('/api/orders/:id/cancel', requireRole('admin', 'customer'), (req: Request, res: Response) => {
  try {
    const orders = readJsonFile<any[]>(getFilePath('orders.json'), []);
    const { id } = req.params;
    const idx = orders.findIndex((o) => String(o.id) === String(id));
    if (idx < 0) return res.status(404).json({ success: false, message: 'سفارش یافت نشد.' });
    const sess = getSession(req);
    const order = orders[idx];
    if (sess?.role !== 'admin' && String(order.userId || order.customerId || '') !== String(sess?.userId || '')) {
      return res.status(403).json({ success: false, message: 'این سفارش متعلق به حساب شما نیست.' });
    }
    const status = String(order.status || '').toLowerCase();
    if (sess?.role !== 'admin' && !['pending', 'در حال بررسی', 'under_review'].includes(status)) {
      return res.status(409).json({ success: false, message: 'لغو مستقیم فقط تا پیش از تأیید سفارش امکان‌پذیر است.' });
    }
    if (['cancelled', 'canceled', 'لغو شده', 'لغو‌شده'].includes(status)) return res.json({ success: true, order, alreadyCancelled: true });
    if (sess?.role === 'admin' && ['shipped', 'ارسال‌شده', 'delivered', 'تحویل‌شده', 'تحویل شده'].includes(status)) {
      return res.status(409).json({ success: false, message: 'سفارش ارسال‌شده یا تحویل‌شده از مسیر لغو عادی قابل لغو نیست؛ درخواست مرجوعی/بازپرداخت را بررسی کنید.' });
    }
    const reason = String(req.body?.reason || '').trim().slice(0, 500);
    if (sess?.role === 'admin' && reason.length < 5) return res.status(422).json({ success: false, message: 'برای لغو مدیریتی ثبت دلیل الزامی است.' });
    orders[idx] = { ...order, status: 'cancelled', cancelReason: reason || undefined, cancelledAt: new Date().toISOString(), cancelledBy: sess?.role === 'admin' ? String(sess.userId || 'admin') : 'customer', updatedAt: new Date().toISOString() };
    if (!writeJsonFile(getFilePath('orders.json'), orders)) return res.status(500).json({ success: false, message: 'ذخیره لغو سفارش انجام نشد.' });
    recordAuditLog('order_cancelled', `سفارش ${id} لغو شد.`, String(sess?.userId || sess?.role || 'unknown'), { orderId: id, previousStatus: order.status, reason, paymentStatus: order.paymentStatus || 'unknown' });
    return res.json({ success: true, order: orders[idx], refundStatus: order.paymentStatus === 'paid' ? 'requires_review' : 'not_required_or_unconfirmed' });
  } catch (err: any) {
    return res.status(500).json({ success: false, message: 'لغو سفارش انجام نشد.' });
  }
});

app.put('/api/orders/:id', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const orders = readJsonFile<any[]>(getFilePath('orders.json'), []);
    const { id } = req.params;
    const idx = orders.findIndex((o) => o.id === id);
    if (idx === -1) {
      return res.status(404).json({ error: 'Order not found' });
    }
    const previous = orders[idx];
    const incoming = req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : {};
    const body: Record<string, any> = {};
    for (const key of ['status', 'trackingNumber', 'trackingCode', 'shippingTrackingNumber', 'shippingProvider', 'adminNotes', 'note', 'cancelReason']) {
      if (incoming[key] !== undefined) {
        if (typeof incoming[key] !== 'string') return res.status(422).json({ success: false, message: `فیلد ${key} باید متن باشد.` });
        body[key] = incoming[key].trim().slice(0, key === 'adminNotes' || key === 'note' ? 2000 : 500);
      }
    }
    if (!Object.keys(body).length) return res.status(422).json({ success: false, message: 'هیچ فیلد مجازی برای به‌روزرسانی ارسال نشده است.' });
    const allowedStatuses = ['در حال بررسی', 'تأییدشده', 'تاییدشده', 'در حال آماده‌سازی', 'ارسال‌شده', 'تحویل‌شده', 'cancelled', 'canceled', 'لغو شده', 'لغو‌شده'];
    if (body.status !== undefined && !allowedStatuses.includes(String(body.status))) return res.status(422).json({ success: false, message: 'وضعیت سفارش معتبر نیست.' });
    const cancelledStatuses = ['cancelled', 'لغو شده', 'لغو‌شده'];
    const current = normalizeOrderStatus(previous.status);
    const next = body.status === undefined ? current : normalizeOrderStatus(body.status);
    if (body.status !== undefined && !canTransitionOrderStatus(previous.status, body.status)) return res.status(409).json({ success: false, message: 'تغییر وضعیت سفارش با این مسیر مجاز نیست.' });
    if (body.status !== undefined && cancelledStatuses.includes(String(body.status)) && !cancelledStatuses.includes(String(previous.status || ''))) {
      const reason = String(body.cancelReason || body.reason || '').trim().slice(0, 500);
      if (reason.length < 5) return res.status(422).json({ success: false, message: 'برای لغو مدیریتی ثبت دلیل الزامی است.' });
      body.cancelReason = reason; body.cancelledAt = new Date().toISOString(); body.cancelledBy = String(getSession(req)?.userId || 'admin'); delete body.reason;
    }
    orders[idx] = { ...previous, ...body, id: previous.id, updatedAt: new Date().toISOString() };
    if (!writeJsonFile(getFilePath('orders.json'), orders)) return res.status(500).json({ success: false, message: 'ذخیره تغییرات سفارش انجام نشد.' });
    recordAuditLog('order_updated', `سفارش ${id} توسط مدیر به‌روزرسانی شد.`, String(getSession(req)?.userId || 'admin'), { orderId: id, previousStatus: previous.status, newStatus: orders[idx].status, previousRefundStatus: previous.refundStatus, newRefundStatus: orders[idx].refundStatus });
    res.json({ success: true, order: orders[idx] });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update order', message: err?.message });
  }
});

// Controlled manual financial reconciliation. This records a real manual action; it is not a gateway integration.
app.post('/api/admin/orders/:id/financial-action', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const action = String(req.body?.action || '');
    const note = String(req.body?.note || '').trim().slice(0, 1000);
    const reference = String(req.body?.reference || '').trim().slice(0, 160);
    if (!['confirm_manual_payment', 'confirm_manual_refund'].includes(action)) return res.status(422).json({ success: false, message: 'عملیات مالی نامعتبر است.' });
    if (req.body?.confirmed !== true || note.length < 8) return res.status(422).json({ success: false, message: 'برای ثبت اقدام دستی، تأیید صریح و توضیح معتبر الزامی است.' });
    const orders = readJsonFile<any[]>(getFilePath('orders.json'), []);
    const idx = orders.findIndex((o) => String(o.id) === String(req.params.id));
    if (idx < 0) return res.status(404).json({ success: false, message: 'سفارش یافت نشد.' });
    const previous = orders[idx];
    const now = new Date().toISOString();
    const normalizedOrderStatus = String(previous.status || '').trim().toLowerCase();
    const orderIsCancelled = ['cancelled', 'canceled', 'لغو شده', 'لغو‌شده'].includes(normalizedOrderStatus);
    if (action === 'confirm_manual_payment') {
      if (orderIsCancelled) return res.status(409).json({ success: false, message: 'ثبت پرداخت برای سفارش لغوشده از این مسیر مجاز نیست.' });
      if (previous.paymentStatus === 'paid') return res.status(409).json({ success: false, message: 'پرداخت قبلاً ثبت شده است.' });
      orders[idx] = { ...previous, paymentStatus: 'paid', paymentConfirmation: { type: 'manual_admin', note, reference: reference || null, confirmedBy: String(getSession(req)?.userId || 'admin'), confirmedAt: now }, updatedAt: now };
    } else {
      if (previous.paymentStatus !== 'paid') return res.status(409).json({ success: false, message: 'تکمیل بازپرداخت کامل فقط برای سفارش با پرداخت کامل تأییدشده مجاز است؛ بازپرداخت جزئی به گردش‌کار جداگانه نیاز دارد.' });
      if (!orderIsCancelled && previous.refundStatus !== 'pending' && previous.refundStatus !== 'refund_pending') return res.status(409).json({ success: false, message: 'ثبت بازپرداخت فقط برای سفارش لغوشده یا بازپرداختی که رسماً در انتظار اجراست مجاز است.' });
      if (previous.refundStatus === 'completed') return res.status(409).json({ success: false, message: 'بازپرداخت قبلاً تکمیل شده است.' });
      orders[idx] = { ...previous, refundStatus: 'completed', refundConfirmation: { type: 'manual_admin', note, reference: reference || null, confirmedBy: String(getSession(req)?.userId || 'admin'), confirmedAt: now }, updatedAt: now };
    }
    if (!writeJsonFile(getFilePath('orders.json'), orders)) return res.status(500).json({ success: false, message: 'ذخیره اقدام مالی انجام نشد.' });
    recordAuditLog(action, `اقدام مالی دستی برای سفارش ${previous.id} ثبت شد.`, String(getSession(req)?.userId || 'admin'), { orderId: previous.id, note, reference: reference || null, previousPaymentStatus: previous.paymentStatus || 'unknown', newPaymentStatus: orders[idx].paymentStatus || 'unknown', previousRefundStatus: previous.refundStatus || 'none', newRefundStatus: orders[idx].refundStatus || 'none' });
    return res.json({ success: true, order: orders[idx], message: 'اقدام دستی ثبت شد؛ تأیید درگاه پرداخت خودکار انجام نشده است.' });
  } catch { return res.status(500).json({ success: false, message: 'ثبت اقدام مالی انجام نشد.' }); }
});

app.delete('/api/orders/:id', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const orders = readJsonFile<any[]>(getFilePath('orders.json'), []);
    const { id } = req.params;
    const idx = orders.findIndex((o) => String(o.id) === String(id));
    if (idx < 0) return res.status(404).json({ success: false, message: 'سفارش یافت نشد.' });
    const previous = orders[idx];
    // Keep the financial/order history: "delete" is an archival action, not a hard delete.
    orders[idx] = { ...previous, archived: true, archivedAt: new Date().toISOString(), archivedBy: String(getSession(req)?.userId || 'admin') };
    writeJsonFile(getFilePath('orders.json'), orders);
    recordAuditLog('order_archived', `سفارش ${id} از فهرست فعال بایگانی شد.`, String(getSession(req)?.userId || 'admin'), { orderId: id, previousStatus: previous.status, paymentStatus: previous.paymentStatus || 'unknown' });
    res.json({ success: true, message: 'سفارش بایگانی شد و سوابق آن حفظ شد.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to archive order' });
  }
});

// 6. Users & Auth
// نشانی‌های ذخیره‌شده متعلق به حساب‌اند؛ هر سفارش همچنان snapshot نشانی زمان ثبت خود را نگه می‌دارد.
app.get('/api/account/addresses', requireRole('customer'), (req: Request, res: Response) => {
  const sess = getSession(req);
  const users = readJsonFile<any[]>(getFilePath('users.json'), []);
  const user = users.find((u) => String(u.id) === String(sess?.userId));
  if (!user) return res.status(404).json({ success: false, message: 'حساب کاربری یافت نشد.' });
  return res.json({ success: true, addresses: Array.isArray(user.addresses) ? user.addresses : [], defaultAddressId: user.defaultAddressId || null });
});

app.post('/api/account/addresses', requireRole('customer'), (req: Request, res: Response) => {
  try {
    const sess = getSession(req);
    const users = readJsonFile<any[]>(getFilePath('users.json'), []);
    const idx = users.findIndex((u) => String(u.id) === String(sess?.userId));
    if (idx < 0) return res.status(404).json({ success: false, message: 'حساب کاربری یافت نشد.' });
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    const action = String(body.action || 'add');
    const addresses = Array.isArray(users[idx].addresses) ? [...users[idx].addresses] : [];
    const clean = (v: any) => ({
      title: String(v?.title || 'نشانی من').trim().slice(0, 80),
      recipientName: String(v?.recipientName || v?.name || '').trim().slice(0, 120),
      phone: digits(v?.phone || ''),
      province: String(v?.province || '').trim().slice(0, 80),
      city: String(v?.city || '').trim().slice(0, 80),
      postalCode: digits(v?.postalCode || '').slice(0, 20),
      address: String(v?.address || '').trim().slice(0, 1000),
      unit: String(v?.unit || '').trim().slice(0, 80),
    });
    if (action === 'add') {
      if (addresses.length >= 20) return res.status(422).json({ success: false, message: 'حداکثر ۲۰ نشانی قابل ذخیره است.' });
      const a = clean(body.address);
      if (!a.recipientName || a.phone.length < 10 || !a.city || !a.address) return res.status(422).json({ success: false, message: 'نام گیرنده، تلفن، شهر و نشانی کامل الزامی است.' });
      const created = { id: `addr-${crypto.randomUUID()}`, ...a, createdAt: new Date().toISOString() };
      addresses.push(created);
      if (body.makeDefault || !users[idx].defaultAddressId) users[idx].defaultAddressId = created.id;
      users[idx].addresses = addresses;
      writeJsonFile(getFilePath('users.json'), users);
      recordAuditLog('customer_address_added', 'نشانی جدید به حساب مشتری اضافه شد.', String(sess?.userId), { addressId: created.id });
      return res.status(201).json({ success: true, address: created, addresses, defaultAddressId: users[idx].defaultAddressId });
    }
    const id = String(body.id || '');
    const at = addresses.findIndex((a: any) => String(a.id) === id);
    if (at < 0) return res.status(404).json({ success: false, message: 'نشانی یافت نشد.' });
    if (action === 'default') {
      users[idx].defaultAddressId = id;
    } else if (action === 'update') {
      const a = clean(body.address);
      if (!a.recipientName || a.phone.length < 10 || !a.city || !a.address) return res.status(422).json({ success: false, message: 'نام گیرنده، تلفن، شهر و نشانی کامل الزامی است.' });
      addresses[at] = { ...addresses[at], ...a, updatedAt: new Date().toISOString() };
      users[idx].addresses = addresses;
    } else if (action === 'delete') {
      addresses.splice(at, 1);
      users[idx].addresses = addresses;
      if (String(users[idx].defaultAddressId || '') === id) users[idx].defaultAddressId = addresses[0]?.id || null;
    } else return res.status(422).json({ success: false, message: 'عملیات نشانی نامعتبر است.' });
    writeJsonFile(getFilePath('users.json'), users);
    recordAuditLog('customer_address_changed', 'نشانی‌های حساب مشتری تغییر کرد.', String(sess?.userId), { addressId: id, action });
    return res.json({ success: true, addresses: users[idx].addresses || [], defaultAddressId: users[idx].defaultAddressId || null });
  } catch {
    return res.status(500).json({ success: false, message: 'ذخیره نشانی انجام نشد.' });
  }
});

// درخواست مرجوعی جدا از وضعیت سفارش و بازپرداخت نگهداری می‌شود.
app.get('/api/returns', requireRole('admin', 'customer'), (req: Request, res: Response) => {
  const sess = getSession(req);
  const all = readJsonFile<any[]>(getFilePath('return_requests.json'), []);
  return res.json(sess?.role === 'admin' ? all : all.filter((r) => String(r.userId) === String(sess?.userId)));
});

app.post('/api/returns', requireRole('customer'), (req: Request, res: Response) => {
  try {
    const sess = getSession(req);
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    const orders = readJsonFile<any[]>(getFilePath('orders.json'), []);
    const order = orders.find((o) => String(o.id) === String(body.orderId) && String(o.userId || o.customerId || '') === String(sess?.userId));
    if (!order) return res.status(404).json({ success: false, message: 'سفارش متعلق به این حساب یافت نشد.' });
    if (!['delivered', 'تحویل‌شده', 'تحویل شده'].includes(String(order.status || '').toLowerCase())) return res.status(409).json({ success: false, message: 'درخواست مرجوعی پس از ثبت تحویل سفارش امکان‌پذیر است.' });
    const reason = String(body.reason || '').trim().slice(0, 120);
    const description = String(body.description || '').trim().slice(0, 1000);
    if (!reason) return res.status(422).json({ success: false, message: 'دلیل مرجوعی الزامی است.' });
    const all = readJsonFile<any[]>(getFilePath('return_requests.json'), []);
    if (all.some((r) => String(r.orderId) === String(order.id) && !['rejected', 'closed'].includes(String(r.status)))) return res.status(409).json({ success: false, message: 'برای این سفارش یک درخواست مرجوعی باز وجود دارد.' });
    const images = Array.isArray(body.images)
      ? body.images.filter((x: any) => typeof x === 'string' && x.length <= 1000 && (/^\/uploads\/[a-zA-Z0-9._/-]+$/.test(x) || /^https:\/\//i.test(x))).slice(0, 5)
      : [];
    const item = { id: `ret-${crypto.randomUUID()}`, orderId: order.id, userId: sess?.userId, reason, description, images, status: 'pending', createdAt: new Date().toISOString() };
    all.unshift(item);
    if (!writeJsonFile(getFilePath('return_requests.json'), all)) return res.status(500).json({ success: false, message: 'ذخیره درخواست مرجوعی انجام نشد.' });
    recordAuditLog('return_requested', `درخواست مرجوعی برای سفارش ${order.id} ثبت شد.`, String(sess?.userId || 'customer'), { returnId: item.id, orderId: order.id });
    return res.status(201).json({ success: true, request: item });
  } catch { return res.status(500).json({ success: false, message: 'ثبت درخواست مرجوعی انجام نشد.' }); }
});

app.put('/api/returns/:id', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const all = readJsonFile<any[]>(getFilePath('return_requests.json'), []);
    const idx = all.findIndex((r) => String(r.id) === String(req.params.id));
    if (idx < 0) return res.status(404).json({ success: false, message: 'درخواست مرجوعی یافت نشد.' });
    const status = String(req.body?.status || '');
    if (!['approved', 'rejected', 'received', 'refund_pending', 'closed'].includes(status)) return res.status(422).json({ success: false, message: 'وضعیت مرجوعی نامعتبر است.' });
    const previous = all[idx];
    const currentStatus = String(previous.status || 'pending');
    if (!canTransitionReturnStatus(currentStatus, status)) {
      return res.status(409).json({ success: false, message: `تغییر وضعیت مرجوعی از «${currentStatus}» به «${status}» مجاز نیست.` });
    }
    // Repeating the current status is a true no-op: do not rewrite notes/timestamps or create duplicate audit events.
    if (currentStatus === status) return res.json({ success: true, request: previous, unchanged: true });
    const adminNote = String(req.body?.adminNote || '').trim().slice(0, 1000);
    if (status === 'rejected' && adminNote.length < 5) return res.status(422).json({ success: false, message: 'برای رد درخواست مرجوعی، ثبت دلیل الزامی است.' });
    if (status === 'refund_pending') {
      const orders = readJsonFile<any[]>(getFilePath('orders.json'), []);
      const order = orders.find((o) => String(o.id) === String(previous.orderId));
      if (!order || !['paid', 'partially_refunded'].includes(String(order.paymentStatus || ''))) {
        return res.status(409).json({ success: false, message: 'ارجاع به مرحله بازپرداخت فقط پس از تأیید پرداخت سفارش مجاز است.' });
      }
    }
    all[idx] = { ...previous, status, adminNote, updatedAt: new Date().toISOString(), updatedBy: String(getSession(req)?.userId || 'admin') };
    if (!writeJsonFile(getFilePath('return_requests.json'), all)) return res.status(500).json({ success: false, message: 'ذخیره وضعیت مرجوعی انجام نشد.' });
    recordAuditLog('return_status_changed', `وضعیت مرجوعی ${previous.id} تغییر کرد.`, String(getSession(req)?.userId || 'admin'), { returnId: previous.id, orderId: previous.orderId, previousStatus: previous.status, newStatus: status });
    return res.json({ success: true, request: all[idx] });
  } catch { return res.status(500).json({ success: false, message: 'به‌روزرسانی درخواست مرجوعی انجام نشد.' }); }
});

// کاربران: مدیر لیست کامل (بدون رمز) می‌بیند؛ مشتری فقط رکورد خودش؛ بقیه هیچ.
function visibleUsers(req: Request): any[] {
  const sess = getSession(req);
  const users = readJsonFile<any[]>(getFilePath('users.json'), []);
  if (!sess) return [];
  if (sess.role === 'admin') return users.map(publicUser);
  if (sess.role === 'customer') return users.filter((u) => u.id === sess.userId).map(publicUser);
  return [];
}

app.get('/api/users', requireRole('admin', 'customer'), (req: Request, res: Response) => {
  try {
    res.json(visibleUsers(req));
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to read users', message: err?.message });
  }
});

app.delete(['/api/users/:id', '/api/users.php'], requireRole('admin'), (req: Request, res: Response) => {
  try {
    const id = req.params.id || (req.query.id as string);
    if (!id) return res.status(400).json({ success: false, message: 'شناسه کاربر لازم است.' });
    let users = readJsonFile<any[]>(getFilePath('users.json'), []);
    const target = users.find((u) => u.id === id);
    if (!target) return res.status(404).json({ success: false, message: 'کاربر یافت نشد.' });
    if (target.role === 'admin') return res.status(403).json({ success: false, message: 'حساب مدیر قابل حذف نیست.' });
    users = users.filter((u) => u.id !== id);
    writeJsonFile(getFilePath('users.json'), users);
    res.json({ success: true, message: 'User deleted' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to delete user', message: err?.message });
  }
});

function isValidIranianNationalCode(value: unknown): boolean {
  const code = digits(value);
  if (!/^\d{10}$/.test(code) || /^([0-9])\1{9}$/.test(code)) return false;
  const check = Number(code[9]);
  let sum = 0;
  for (let i = 0; i < 9; i++) sum += Number(code[i]) * (10 - i);
  const remainder = sum % 11;
  return remainder < 2 ? check === remainder : check === 11 - remainder;
}

const findCustomer = (users: any[], identifier: string) => {
  const raw = String(identifier || '').trim();
  const d = digits(raw);
  return users.find((u) => {
    if (u.role === 'admin') return false;
    if (d && u.nationalCode && digits(u.nationalCode) === d) return true;
    if (u.username && String(u.username).toLowerCase() === raw.toLowerCase()) return true;
    if (u.email && String(u.email).toLowerCase() === raw.toLowerCase()) return true;
    if (d.length >= 10 && u.phone) { const p = digits(u.phone); return p.length >= 10 && p.slice(-10) === d.slice(-10); }
    return false;
  });
};

app.post('/api/auth/login', authRateLimit(8), (req: Request, res: Response) => {
  try {
    const { identifier, phone, nationalCode, password } = req.body || {};
    if (typeof password !== 'string' || password.length > 256) return res.status(400).json({ success: false, message: 'رمز عبور نامعتبر است.' });
    const users = readJsonFile<any[]>(getFilePath('users.json'), []);
    const user = findCustomer(users, identifier || phone || nationalCode);
    if (!user) return res.status(401).json({ success: false, message: 'کاربری با این مشخصات یافت نشد.' });
    if (!user.password) return res.status(401).json({ success: false, message: 'برای این حساب رمز عبور تنظیم نشده است. با پشتیبانی تماس بگیرید.' });
    if (!verifyPassword(user.password, password)) return res.status(401).json({ success: false, message: 'کلمه عبور وارد شده نادرست است.' });
    if (!isHashed(user.password)) { // ارتقای رمز قدیمی به هش
      user.password = hashPassword(String(password));
      writeJsonFile(getFilePath('users.json'), users);
    }
    if (user.isActive === false) return res.status(403).json({ success: false, message: 'حساب کاربری غیرفعال است.' });
    res.json({ success: true, user: publicUser(user), token: createSession('customer', { userId: user.id, username: user.username }) });
  } catch (err: any) {
    res.status(500).json({ error: 'Login error', message: err?.message });
  }
});

app.post('/api/auth/register', authRateLimit(5), (req: Request, res: Response) => {
  try {
    const users = readJsonFile<any[]>(getFilePath('users.json'), []);
    const body = req.body || {};
    const phone = digits(body.phone), nc = digits(body.nationalCode);
    if (typeof body.password !== 'string' || body.password.length < 8 || body.password.length > 256) return res.status(400).json({ success: false, message: 'رمز عبور باید بین ۸ تا ۲۵۶ نویسه باشد.' });
    if (!isValidIranianNationalCode(nc)) return res.status(400).json({ success: false, message: 'کد ملی معتبر الزامی است.' });
    if (phone.length < 10 || phone.length > 15) return res.status(400).json({ success: false, message: 'شماره موبایل معتبر الزامی است.' });
    if (phone && users.some((u) => u.phone && digits(u.phone).slice(-10) === phone.slice(-10)))
      return res.status(409).json({ success: false, message: 'این شماره تماس قبلاً ثبت شده است.' });
    if (nc && users.some((u) => u.nationalCode && digits(u.nationalCode) === nc))
      return res.status(409).json({ success: false, message: 'این کد ملی قبلاً ثبت شده است.' });
    const email = String(body.email || '').trim().toLowerCase().slice(0, 160);
    if (email && users.some((u) => String(u.email || '').trim().toLowerCase() === email))
      return res.status(409).json({ success: false, message: 'این ایمیل قبلاً به حساب دیگری متصل شده است.' });
    const requestedUsername = String(body.username || '').trim().slice(0, 80);
    if (requestedUsername && users.some((u) => String(u.username || '').toLowerCase() === requestedUsername.toLowerCase()))
      return res.status(409).json({ success: false, message: 'این نام کاربری قبلاً ثبت شده است.' });
    const newUser = {
      id: `usr-${Date.now()}-${crypto.randomUUID().slice(0, 8)}`,
      username: String(body.username || body.email || body.phone || `customer_${Date.now()}`).trim().slice(0, 80),
      name: String(body.name || `${body.firstName || ''} ${body.lastName || ''}`).trim().slice(0, 120),
      firstName: String(body.firstName || '').trim().slice(0, 60),
      lastName: String(body.lastName || '').trim().slice(0, 60),
      email,
      phone: String(body.phone || '').trim().slice(0, 30),
      nationalCode: nc,
      // شماره موبایل هنوز تا زمان اتصال درگاه پیامک تأیید نشده است.
      phoneVerified: false,
      role: 'customer', isActive: true, walletBalance: 0,
      password: hashPassword(String(body.password)), createdAt: new Date().toISOString(),
    };
    users.push(newUser);
    writeJsonFile(getFilePath('users.json'), users);
    res.json({ success: true, user: publicUser(newUser), token: createSession('customer', { userId: newUser.id, username: newUser.username }) });
  } catch (err: any) {
    res.status(500).json({ error: 'Register error', message: err?.message });
  }
});

app.post('/api/auth/logout', (req: Request, res: Response) => {
  const token = getToken(req);
  if (token) revokeToken(token);
  res.json({ success: true });
});

// بازیابی رمز مدیر: ADMIN_RESET_PASSWORD (و اختیاری ADMIN_RESET_USERNAME) را در .env بگذارید و سرور را یک بار بالا بیاورید.
(function applyAdminReset() {
  const pw = process.env.ADMIN_RESET_PASSWORD;
  if (!pw) return;
  try {
    const users = readJsonFile<any[]>(getFilePath('users.json'), []);
    const name = process.env.ADMIN_RESET_USERNAME || 'admin';
    let admin = users.find((u) => u.role === 'admin' && (u.username === name || u.phone === name)) || users.find((u) => u.role === 'admin');
    if (!admin) { admin = { id: 'admin', name: 'مدیر فروشگاه', username: name, role: 'admin', isActive: true }; users.push(admin); }
    admin.password = hashPassword(pw);
    writeJsonFile(getFilePath('users.json'), users);
    console.log('[Auth] رمز مدیر بازنشانی شد. ADMIN_RESET_PASSWORD را از .env حذف کنید.');
  } catch (e: any) { console.error('[Auth] admin reset failed:', e?.message); }
})();

app.post('/api/admin/login', authRateLimit(8), (req: Request, res: Response) => {
  const { username, password } = req.body || {};
  const rawUser = String(username || '').trim();
  const rawPass = String(password || '').trim();
  if (rawPass.length > 256) return res.status(400).json({ success: false, message: 'رمز عبور نامعتبر است.' });
  const cleanUsername = rawUser.toLowerCase();
  const normPass = normalizeDigits(rawPass);
  const normUser = normalizeDigits(rawUser);

  const users = readJsonFile<any[]>(getFilePath('users.json'), []);
  let admin = users.find((u) => u.role === 'admin' && (
    String(u.username || '').toLowerCase() === cleanUsername ||
    u.username === rawUser ||
    (u.phone && (u.phone === rawUser || digits(u.phone) === digits(rawUser)))
  ));

  // Never alias a requested username to an unrelated administrator account.
  // The documented test account remains available because it is matched above
  // by its actual stored username; no fallback account selection is performed.

  if (admin && admin.isActive !== false) {
    const matchedPassword = verifyPassword(admin.password, rawPass)
      ? rawPass
      : (verifyPassword(admin.password, normPass) ? normPass : null);

    if (matchedPassword !== null) {
      if (!isHashed(admin.password)) {
        admin.password = hashPassword(matchedPassword);
        writeJsonFile(getFilePath('users.json'), users);
      }
      return res.json({
        success: true,
        message: 'خوش آمدید! ورود به پنل مدیریت با موفقیت انجام شد.',
        token: createSession('admin', { userId: admin.id, username: admin.username }),
        user: publicUser(admin),
      });
    }
  }
  return res.status(401).json({ success: false, message: 'نام کاربری یا رمز عبور اشتباه است' });
});

app.post('/api/admin/clear-data', requireRole('admin'), (req: Request, res: Response) => {
  try {
    // This operation is destructive; a plain POST must never erase business records.
    if (req.body?.confirm !== 'CLEAR_ORDERS_AND_BALANCES') {
      return res.status(422).json({ success: false, message: 'برای پاک‌سازی، فیلد confirm با مقدار CLEAR_ORDERS_AND_BALANCES را صریحاً ارسال کنید.' });
    }
    const reason = String(req.body?.reason || '').trim().slice(0, 500);
    if (reason.length < 10) return res.status(422).json({ success: false, message: 'ثبت دلیل پاک‌سازی (حداقل ۱۰ نویسه) الزامی است.' });
    const sess = getSession(req);
    const counts = {
      orders: readJsonFile<any[]>(getFilePath('orders.json'), []).length,
      tickets: readJsonFile<any[]>(getFilePath('tickets.json'), []).length,
      smsLogs: readJsonFile<any[]>(getFilePath('sms_logs.json'), []).length,
      walletTransactions: readJsonFile<any[]>(getFilePath('wallet_transactions.json'), []).length,
    };
    const affectedFiles = ['orders.json', 'tickets.json', 'sms_logs.json', 'wallet_transactions.json', 'users.json'];
    const snapshots = new Map<string, any>();
    for (const name of affectedFiles) snapshots.set(name, readJsonFile<any>(getFilePath(name), []));
    const backupDir = getFilePath(path.join('backups', `clear-data-${Date.now()}`));
    fs.mkdirSync(backupDir, { recursive: true });
    for (const name of affectedFiles) {
      fs.writeFileSync(path.join(backupDir, name), JSON.stringify(snapshots.get(name), null, 2), { encoding: 'utf-8', flag: 'wx' });
    }
    const users = Array.isArray(snapshots.get('users.json')) ? snapshots.get('users.json').map((u: any) => ({ ...u })) : [];
    for (const u of users) if (typeof u.walletBalance !== 'undefined') u.walletBalance = 0;
    const replacements: Record<string, any> = {
      'orders.json': [], 'tickets.json': [], 'sms_logs.json': [], 'wallet_transactions.json': [], 'users.json': users,
    };
    const written: string[] = [];
    try {
      for (const name of affectedFiles) {
        if (!writeJsonFile(getFilePath(name), replacements[name])) throw new Error(`write failed: ${name}`);
        written.push(name);
      }
    } catch (writeError) {
      // Best-effort rollback from in-memory snapshots; the timestamped backup remains for manual recovery.
      for (const name of written.reverse()) writeJsonFile(getFilePath(name), snapshots.get(name));
      throw writeError;
    }
    recordAuditLog('admin_clear_data', 'پاک‌سازی اطلاعات عملیاتی توسط مدیر انجام شد.', String(sess?.userId || 'admin'), { reason, counts, backupPath: path.relative(DATA_DIR, backupDir) });
    return res.json({ success: true, message: 'اطلاعات عملیاتی انتخاب‌شده پاک‌سازی شد.', clearedCounts: counts });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message });
  }
});

app.post('/api/admin/change-credentials', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const { newUsername, newPassword } = req.body || {};
    const sess = getSession(req);
    const users = readJsonFile<any[]>(getFilePath('users.json'), []);
    const idx = users.findIndex((u) => u.role === 'admin' && (!sess?.userId || u.id === sess.userId));
    if (idx < 0) return res.status(404).json({ success: false, message: 'مدیر یافت نشد' });
    if (newUsername) {
      const candidate = String(newUsername).trim().slice(0, 80);
      if (candidate.length < 3) return res.status(400).json({ success: false, message: 'نام کاربری جدید معتبر نیست.' });
      if (users.some((u, i) => i !== idx && u.username === candidate)) return res.status(409).json({ success: false, message: 'این نام کاربری قبلاً استفاده شده است.' });
      users[idx].username = candidate;
    }
    if (newPassword) {
      if (String(newPassword).length < 8) return res.status(400).json({ success: false, message: 'رمز جدید باید حداقل ۸ کاراکتر باشد.' });
      users[idx].password = hashPassword(String(newPassword));
    }
    writeJsonFile(getFilePath('users.json'), users);
    // پس از تغییر اعتبارنامه، نشست‌های قبلی این مدیر دیگر معتبر نیستند.
    const revoked = revokeUserSessions(users[idx].id, 'admin');
    // یک نشست تازه صادر می‌کنیم تا مدیر از پنل خارج نشود.
    const token = createSession('admin', { userId: users[idx].id, username: users[idx].username });
    res.json({ success: true, token, user: publicUser(users[idx]), revokedSessions: revoked, message: 'اطلاعات با موفقیت تغییر کرد' });
  } catch (err: any) {
    res.status(500).json({ error: 'Error changing credentials', message: err?.message });
  }
});

// 7. Coupons
app.get('/api/coupons', (req: Request, res: Response) => {
  try {
    const allCoupons = flattenCoupons(readJsonFile<any[]>(getFilePath('coupons.json'), []));
    if (getSession(req)?.role === 'admin') return res.json(allCoupons);
    // Public storefront receives only fields needed to display/enter a coupon; internal usage counters and admin metadata stay server-side.
    const publicFields = ['id', 'code', 'type', 'discountType', 'value', 'discountValue', 'percent', 'isActive', 'active', 'startAt', 'startDate', 'endAt', 'endDate', 'minimumOrder', 'minOrder', 'productIds', 'maxDiscount', 'maximumDiscount'];
    const publicCoupons = allCoupons
      .filter((c: any) => c && c.isActive !== false && c.active !== false)
      .map((c: any) => Object.fromEntries(publicFields.filter((key) => c[key] !== undefined).map((key) => [key, c[key]])));
    res.json(publicCoupons);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to read coupons', message: err?.message });
  }
});

// اصلاح باگ تو در تو شدن کوپن‌ها: فرانت‌اند کل لیست را به شکل { coupons: [...] } ارسال می‌کند
const flattenCoupons = (input: any): any[] => {
  const out: any[] = [];
  const walk = (x: any) => {
    if (Array.isArray(x)) x.forEach(walk);
    else if (x && typeof x === 'object') {
      if (Array.isArray(x.coupons)) walk(x.coupons);
      else if (x.code || x.id) out.push(x);
    }
  };
  walk(input);
  const seen = new Set<string>();
  return out.filter((c) => { const k = String(c.id ?? c.code); if (seen.has(k)) return false; seen.add(k); return true; });
};

app.post('/api/coupons', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const body = req.body;
    let coupons: any[];
    if (body && Array.isArray(body.coupons)) {
      coupons = flattenCoupons(body.coupons); // ذخیره کل لیست (جایگزینی)
    } else {
      const current = flattenCoupons(readJsonFile<any[]>(getFilePath('coupons.json'), []));
      const incoming = flattenCoupons(body);
      const incomingCode = String(incoming[0]?.code || '').trim().toUpperCase();
      const incomingId = String(incoming[0]?.id || incoming[0]?.code || '');
      coupons = [...current.filter((c) => String(c.id ?? c.code) !== incomingId && (!incomingCode || String(c.code || '').trim().toUpperCase() !== incomingCode)), ...incoming];
    }
    const seenCodes = new Set<string>();
    for (const coupon of coupons) {
      const code = String(coupon?.code || '').trim().toUpperCase();
      if (!code || code.length > 80) return res.status(422).json({ success: false, message: 'هر کد تخفیف باید کد غیرخالی و حداکثر ۸۰ نویسه داشته باشد.' });
      if (seenCodes.has(code)) return res.status(409).json({ success: false, message: `کد تخفیف تکراری است: ${code}` });
      seenCodes.add(code);
      const value = Number(coupon.value ?? coupon.discountValue ?? coupon.percent ?? 0);
      if (!Number.isFinite(value) || value <= 0 || value > 1e15) return res.status(422).json({ success: false, message: `مقدار کد تخفیف ${code} معتبر نیست.` });
      const type = String(coupon.type || coupon.discountType || (coupon.percent != null ? 'percent' : 'fixed')).toLowerCase();
      if (!['percent', 'percentage', 'درصد', 'percentage_discount', 'fixed', 'amount', 'مبلغ', 'fixed_amount'].includes(type)) return res.status(422).json({ success: false, message: `نوع کد تخفیف ${code} معتبر نیست.` });
      if (['percent', 'percentage', 'درصد', 'percentage_discount'].includes(type) && value > 100) return res.status(422).json({ success: false, message: `درصد تخفیف ${code} نمی‌تواند بیش از ۱۰۰ باشد.` });
      const minimum = Number(coupon.minimumOrder ?? coupon.minOrder ?? 0);
      if (!Number.isFinite(minimum) || minimum < 0 || minimum > 1e15) return res.status(422).json({ success: false, message: `حداقل مبلغ سفارش برای ${code} معتبر نیست.` });
      const start = coupon.startAt || coupon.startDate, end = coupon.endAt || coupon.endDate;
      if (start && !Number.isFinite(Date.parse(String(start)))) return res.status(422).json({ success: false, message: `تاریخ شروع کد ${code} معتبر نیست.` });
      if (end && !Number.isFinite(Date.parse(String(end)))) return res.status(422).json({ success: false, message: `تاریخ پایان کد ${code} معتبر نیست.` });
      if (start && end && Date.parse(String(start)) > Date.parse(String(end))) return res.status(422).json({ success: false, message: `تاریخ شروع کد ${code} پس از تاریخ پایان آن است.` });
      const limit = Number(coupon.usageLimit ?? coupon.maxUses ?? 0);
      const used = Number(coupon.usageCount ?? coupon.usedCount ?? 0);
      if (!Number.isFinite(limit) || limit < 0 || !Number.isFinite(used) || used < 0) return res.status(422).json({ success: false, message: `محدودیت مصرف کد تخفیف ${code} معتبر نیست.` });
    }
    if (!writeJsonFile(getFilePath('coupons.json'), coupons)) return res.status(500).json({ success: false, message: 'ذخیره کدهای تخفیف انجام نشد.' });
    res.json({ success: true, coupons });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to save coupon', message: err?.message });
  }
});

// 8. Banners
app.get('/api/banners', (req: Request, res: Response) => {
  try {
    const banners = readJsonFile<any[]>(getFilePath('banners.json'), []);
    res.json(banners);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to read banners', message: err?.message });
  }
});

app.post('/api/banners', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const banners = Array.isArray(req.body) ? req.body : (Array.isArray(req.body?.banners) ? req.body.banners : []);
    writeJsonFile(getFilePath('banners.json'), banners);
    res.json({ success: true, banners });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to save banners', message: err?.message });
  }
});

// Reviews
app.get('/api/reviews', (req: Request, res: Response) => {
  try {
    const reviews = readJsonFile<any[]>(getFilePath('reviews.json'), []);
    // Public storefronts show only approved reviews. Legacy records without an
    // explicit moderation status remain visible for backwards compatibility.
    const visible = getSession(req)?.role === 'admin'
      ? reviews
      : reviews.filter((r) => !r?.status || ['approved', 'published'].includes(String(r.status).toLowerCase()));
    res.json(visible);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to read reviews', message: err?.message });
  }
});

app.post('/api/reviews', authRateLimit(5), (req: Request, res: Response) => {
  try {
    const reviews = readJsonFile<any[]>(getFilePath('reviews.json'), []);
    // Bulk replacement is an administrative operation; anonymous clients must
    // never be able to erase or rewrite the complete review collection.
    if (Array.isArray(req.body)) {
      if (getSession(req)?.role !== 'admin') {
        return res.status(401).json({ success: false, message: 'برای جایگزینی کامل نظرات، ورود مدیر لازم است.' });
      }
      if (req.body.length > 5000) return res.status(413).json({ success: false, message: 'تعداد نظرات بیش از حد مجاز است.' });
      writeJsonFile(getFilePath('reviews.json'), req.body);
      return res.json({ success: true, reviews: req.body });
    }
    const body = req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : {};
    const rating = Number(body.rating ?? body.stars);
    const comment = String(body.comment ?? body.text ?? body.message ?? '').trim();
    if (!comment || comment.length > 3000 || !Number.isFinite(rating) || rating < 1 || rating > 5) {
      return res.status(422).json({ success: false, message: 'متن نظر و امتیاز معتبر بین ۱ تا ۵ الزامی است.' });
    }
    const review = {
      id: `rev-${Date.now()}-${crypto.randomUUID().slice(0, 8)}`,
      productId: String(body.productId ?? '').slice(0, 120),
      productName: String(body.productName ?? '').slice(0, 200),
      name: String(body.name ?? body.displayName ?? 'مشتری').trim().slice(0, 80),
      rating,
      comment,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    reviews.unshift(review);
    writeJsonFile(getFilePath('reviews.json'), reviews.slice(0, 20000));
    res.status(201).json({ success: true, review });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to save review', message: 'خطا در ذخیره نظر.' });
  }
});

// Special Offers
app.get(['/api/special-offers', '/api/special_offers'], (req: Request, res: Response) => {
  try {
    const offers = readJsonFile<any[]>(getFilePath('special_offers.json'), []);
    res.json(offers);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to read special offers', message: err?.message });
  }
});

app.post(['/api/special-offers', '/api/special_offers'], requireRole('admin'), (req: Request, res: Response) => {
  try {
    const offers = Array.isArray(req.body) ? req.body : (Array.isArray(req.body?.offers) ? req.body.offers : []);
    writeJsonFile(getFilePath('special_offers.json'), offers);
    res.json({ success: true, offers });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to save special offers', message: err?.message });
  }
});

// Home Boxes
app.get(['/api/home-boxes', '/api/home_boxes'], (req: Request, res: Response) => {
  try {
    const boxes = readJsonFile<any[]>(getFilePath('home_boxes.json'), []);
    res.json(boxes);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to read home boxes', message: err?.message });
  }
});

app.post(['/api/home-boxes', '/api/home_boxes'], requireRole('admin'), (req: Request, res: Response) => {
  try {
    const boxes = Array.isArray(req.body) ? req.body : (Array.isArray(req.body?.boxes) ? req.body.boxes : []);
    writeJsonFile(getFilePath('home_boxes.json'), boxes);
    res.json({ success: true, boxes });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to save home boxes', message: err?.message });
  }
});

// 9. Tickets
app.get('/api/tickets', requireRole('admin', 'customer'), (req: Request, res: Response) => {
  try {
    const tickets = readJsonFile<any[]>(getFilePath('tickets.json'), []);
    const sess = getSession(req);
    if (sess?.role === 'admin') return res.json(tickets);
    res.json(tickets.filter((t) => String(t.userId || t.customerId || t.user?.id || '') === String(sess?.userId || '')));
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to read tickets', message: err?.message });
  }
});

app.post('/api/tickets', requireRole('admin', 'customer'), (req: Request, res: Response) => {
  try {
    const tickets = readJsonFile<any[]>(getFilePath('tickets.json'), []);
    const sess = getSession(req); const body = req.body && typeof req.body === 'object' ? req.body : {};
    const newTicket: any = {
      id: `tck-${Date.now()}-${crypto.randomUUID().slice(0, 8)}`,
      subject: String(body.subject || 'پشتیبانی').slice(0, 200),
      message: String(body.message || '').slice(0, 5000),
      priority: ['low','normal','high','urgent'].includes(body.priority) ? body.priority : 'normal',
      status: 'open', userId: sess?.role === 'customer' ? sess.userId : String(body.userId || ''),
      messages: [], createdAt: new Date().toISOString(),
    };
    if (!newTicket.message.trim()) return res.status(422).json({ success: false, message: 'متن تیکت الزامی است.' });
    tickets.unshift(newTicket); writeJsonFile(getFilePath('tickets.json'), tickets);
    res.json({ success: true, ticket: newTicket });
  } catch (err: any) { res.status(500).json({ error: 'Failed to save ticket', message: err?.message }); }
});

app.put('/api/tickets/:id', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const tickets = readJsonFile<any[]>(getFilePath('tickets.json'), []);
    const { id } = req.params;
    const idx = tickets.findIndex((t) => t.id === id);
    if (idx !== -1) {
      const body = req.body && typeof req.body === 'object' ? req.body : {};
      const allowedStatuses = ['open', 'in_progress', 'waiting_customer', 'closed'];
      const updates: any = {};
      if (body.status !== undefined) { if (!allowedStatuses.includes(String(body.status))) return res.status(422).json({ success: false, message: 'وضعیت تیکت معتبر نیست.' }); updates.status = String(body.status); }
      if (body.priority !== undefined) { if (!['low', 'normal', 'high', 'urgent'].includes(String(body.priority))) return res.status(422).json({ success: false, message: 'اولویت تیکت معتبر نیست.' }); updates.priority = String(body.priority); }
      if (body.subject !== undefined) updates.subject = String(body.subject).trim().slice(0, 200);
      if (body.adminNote !== undefined) updates.adminNote = String(body.adminNote).trim().slice(0, 1000);
      tickets[idx] = { ...tickets[idx], ...updates, updatedAt: new Date().toISOString() };
      if (!writeJsonFile(getFilePath('tickets.json'), tickets)) return res.status(500).json({ success: false, message: 'ذخیره تغییرات تیکت انجام نشد.' });
      return res.json({ success: true, ticket: tickets[idx] });
    }
    res.status(404).json({ success: false, error: 'Ticket not found' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});

app.post('/api/tickets/:id/reply', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const tickets = readJsonFile<any[]>(getFilePath('tickets.json'), []);
    const { id } = req.params;
    const idx = tickets.findIndex((t) => t.id === id);
    const message = String(req.body?.message || '').trim().slice(0, 5000);
    const status = req.body?.status;
    if (!message) return res.status(422).json({ success: false, message: 'متن پاسخ الزامی است.' });
    if (status !== undefined && !['open', 'in_progress', 'waiting_customer', 'closed'].includes(String(status))) return res.status(422).json({ success: false, message: 'وضعیت تیکت معتبر نیست.' });
    if (idx !== -1) {
      if (!Array.isArray(tickets[idx].messages)) {
        tickets[idx].messages = [];
      }
      tickets[idx].messages.push({
        id: `msg-${Date.now()}`,
        sender: 'support',
        message,
        createdAt: new Date().toISOString(),
      });
      if (status) tickets[idx].status = status;
      tickets[idx].updatedAt = new Date().toISOString();
      if (!writeJsonFile(getFilePath('tickets.json'), tickets)) return res.status(500).json({ success: false, message: 'ذخیره پاسخ تیکت انجام نشد.' });
      return res.json({ success: true, ticket: tickets[idx] });
    }
    res.status(404).json({ success: false, error: 'Ticket not found' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});

// 10. Wallet
app.get('/api/wallet/transactions', requireRole('admin', 'customer'), (req: Request, res: Response) => {
  try {
    const txs = readJsonFile<any[]>(getFilePath('wallet_transactions.json'), []);
    const sess = getSession(req);
    if (sess?.role === 'admin') return res.json(txs);
    res.json(txs.filter((t) => String(t.userId || '') === String(sess?.userId || '')));
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to read transactions', message: err?.message });
  }
});

app.post('/api/wallet/adjust', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const txs = readJsonFile<any[]>(getFilePath('wallet_transactions.json'), []);
    const { userId, amount, description } = req.body || {};
    const numericAmount = Number(amount);
    if (!userId || !Number.isFinite(numericAmount) || numericAmount === 0 || Math.abs(numericAmount) > 1_000_000_000) {
      return res.status(400).json({ success: false, message: 'شناسه کاربر و مبلغ معتبر لازم است.' });
    }
    const users = readJsonFile<any[]>(getFilePath('users.json'), []);
    const previousUsers = users.map((u) => ({ ...u }));
    const uIdx = users.findIndex((u) => String(u.id) === String(userId) && u.role !== 'admin');
    if (uIdx < 0) return res.status(404).json({ success: false, message: 'مشتری برای تغییر موجودی کیف پول یافت نشد.' });
    const currentBalance = Number(users[uIdx].walletBalance ?? 0);
    const nextBalance = currentBalance + numericAmount;
    if (!Number.isFinite(currentBalance) || !Number.isFinite(nextBalance) || Math.abs(nextBalance) > 1_000_000_000) {
      return res.status(422).json({ success: false, message: 'موجودی جدید کیف پول از محدودهٔ مجاز خارج است.' });
    }
    const newTx = {
      id: `tx-${crypto.randomUUID()}`,
      userId: String(userId),
      amount: numericAmount,
      description: String(description || '').trim().slice(0, 500),
      createdAt: new Date().toISOString(),
    };
    users[uIdx].walletBalance = nextBalance;
    // Both writes remain separate JSON operations; a database transaction is still
    // required to guarantee atomicity if the process stops between these writes.
    if (!writeJsonFile(getFilePath('users.json'), users)) return res.status(500).json({ success: false, message: 'ذخیره موجودی کیف پول انجام نشد؛ تراکنش ثبت نشد.' });
    txs.unshift(newTx);
    if (!writeJsonFile(getFilePath('wallet_transactions.json'), txs)) {
      const rolledBack = writeJsonFile(getFilePath('users.json'), previousUsers);
      return res.status(500).json({ success: false, message: rolledBack ? 'ثبت دفتر تراکنش ناموفق بود؛ تغییر موجودی برگشت داده شد.' : 'ثبت دفتر تراکنش و بازگردانی موجودی ناموفق بود؛ تطبیق حسابداری فوری لازم است.', reconciliationRequired: !rolledBack });
    }
    recordAuditLog('wallet_adjusted', 'موجودی کیف پول مشتری توسط مدیر تغییر کرد.', String(getSession(req)?.userId || 'admin'), { userId: String(userId), amount: numericAmount, transactionId: newTx.id, reason: newTx.description });
    res.json({ success: true, transaction: newTx, walletBalance: nextBalance });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to adjust wallet', message: err?.message });
  }
});

// 11. SMS
app.get('/api/sms/history', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const logs = readJsonFile<any[]>(getFilePath('sms_logs.json'), []);
    res.json(logs);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to read sms logs', message: err?.message });
  }
});

app.post('/api/sms/send', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const logs = readJsonFile<any[]>(getFilePath('sms_logs.json'), []);
    const newLog = {
      id: `sms-${Date.now()}`,
      ...req.body,
      status: 'recorded_not_sent',
      sentAt: new Date().toISOString(),
    };
    logs.unshift(newLog);
    writeJsonFile(getFilePath('sms_logs.json'), logs);
    res.json({ success: true, log: newLog });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to send sms', message: err?.message });
  }
});

// 12. Accounting Module
const ACC_USERS = () => path.join(DATA_DIR, 'accounting', 'users.json');

app.get('/api/accounting/users', requireRole('accounting'), (req: Request, res: Response) => {
  try {
    const accUsers = readJsonFile<any[]>(ACC_USERS(), []).map(publicUser);
    res.json({ success: true, users: accUsers });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to read accounting users', message: err?.message, users: [] });
  }
});

app.post('/api/accounting/users', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const accUsers = readJsonFile<any[]>(ACC_USERS(), []);
    const { id, username, fullName, role, password } = req.body || {};
    let user: any;
    if (id) {
      const idx = accUsers.findIndex((u) => u.id === id);
      if (idx >= 0) {
        const { password: _p, ...rest } = req.body;
        accUsers[idx] = { ...accUsers[idx], ...rest };
        if (password) accUsers[idx].password = isHashed(password) ? password : hashPassword(String(password));
        user = accUsers[idx];
      }
    }
    if (!user) {
      if (!password) return res.status(400).json({ success: false, message: 'رمز عبور لازم است.' });
      user = {
        id: id || `usr_acc_${Date.now()}`,
        username: username || `user_${Date.now()}`,
        fullName: fullName || 'کاربر حسابداری',
        role: role || 'اپراتور',
        createdAt: new Date().toLocaleDateString('fa-IR'),
        password: hashPassword(String(password)),
      };
      accUsers.push(user);
    }
    writeJsonFile(ACC_USERS(), accUsers);
    res.json({ success: true, message: `کاربر ${user.username} با موفقیت در سرور ذخیره شد.`, user: publicUser(user) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});

app.delete('/api/accounting/users', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const id = req.query.id as string;
    if (!id) return res.status(400).json({ success: false, message: 'شناسه کاربر لازم است.' });
    let accUsers = readJsonFile<any[]>(ACC_USERS(), []);
    if (!accUsers.some((u) => u.id === id)) return res.status(404).json({ success: false, message: 'کاربر یافت نشد.' });
    accUsers = accUsers.filter((u) => u.id !== id);
    writeJsonFile(ACC_USERS(), accUsers);
    res.json({ success: true, message: 'کاربر مورد نظر با موفقیت از سرور حذف شد.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});

app.post('/api/accounting/auth/login', authRateLimit(8), (req: Request, res: Response) => {
  try {
    const { username, password } = req.body || {};
    const rawUser = String(username || '').trim();
    const rawPass = String(password || '').trim();
    if (rawPass.length > 256) return res.status(400).json({ success: false, message: 'رمز عبور نامعتبر است.' });
    const cleanUsername = rawUser.toLowerCase();
    const normPass = normalizeDigits(rawPass);

    const accUsers = readJsonFile<any[]>(ACC_USERS(), []);
    // Match only the account explicitly named by the caller. Do not fall back
    // to the first accounting user for aliases such as "admin".
    const user = accUsers.find((u) => String(u.username || '').toLowerCase() === cleanUsername || u.username === rawUser);
    if (user && user.isActive !== false) {
      const matchedPassword = verifyPassword(user.password, rawPass)
        ? rawPass
        : (verifyPassword(user.password, normPass) ? normPass : null);
      if (matchedPassword !== null) {
        if (!isHashed(user.password)) {
          user.password = hashPassword(matchedPassword);
          writeJsonFile(ACC_USERS(), accUsers);
        }
        return res.json({ success: true, user: publicUser(user), token: createSession('accounting', { userId: user.id, username: user.username }) });
      }
    }
    return res.status(401).json({ success: false, message: 'نام کاربری یا رمز عبور حسابداری اشتباه است' });
  } catch (err: any) {
    res.status(500).json({ error: 'Accounting login error', message: err?.message });
  }
});

app.get('/api/accounting/user-data', requireRole('accounting'), (req: Request, res: Response) => {
  try {
    const sess = getSession(req);
    const requestedUsername = (req.query.username as string) || sess?.username || 'admin';
    if (sess?.role !== 'admin' && requestedUsername !== sess?.username) return res.status(403).json({ success: false, message: 'دسترسی به اطلاعات کاربر دیگر مجاز نیست.' });
    const safeUser = String(requestedUsername).replace(/[^a-zA-Z0-9_\-]/g, '');
    const userFile = path.join(DATA_DIR, 'accounting', 'users', `${safeUser}.json`);
    const fallbackFile = path.join(DATA_DIR, 'accounting', 'users', 'admin.json');
    let data: any = {};
    if (fs.existsSync(userFile)) {
      data = readJsonFile<any>(userFile, {});
    } else if (safeUser === 'admin' && fs.existsSync(fallbackFile)) {
      // The legacy fallback is valid only for the explicitly requested admin
      // account; never return admin bookkeeping data for an unrelated username.
      data = readJsonFile<any>(fallbackFile, {});
    }
    res.json({ success: true, data });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Accounting data error', message: err?.message });
  }
});

app.post('/api/accounting/user-data', requireRole('accounting'), (req: Request, res: Response) => {
  try {
    const { username, data } = req.body || {};
    const sess = getSession(req);
    const requestedUsername = String(username || sess?.username || 'admin');
    if (sess?.role !== 'admin' && requestedUsername !== sess?.username) return res.status(403).json({ success: false, message: 'دسترسی به اطلاعات کاربر دیگر مجاز نیست.' });
    const safeUser = requestedUsername.replace(/[^a-zA-Z0-9_\-]/g, '');
    const userDir = path.join(DATA_DIR, 'accounting', 'users');
    if (!fs.existsSync(userDir)) {
      fs.mkdirSync(userDir, { recursive: true });
    }
    const filePath = path.join(userDir, `${safeUser}.json`);
    const updatedAt = new Date().toISOString();
    writeJsonFile(filePath, { ...data, updatedAt });
    res.json({ success: true, updatedAt });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});

// 13. Audit Logs
app.get('/api/audit-logs', requireRole('admin'), (req: Request, res: Response) => {
  try {
    const logs = readJsonFile<any[]>(getFilePath('audit_logs.json'), []);
    res.json(logs);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to read audit logs', message: err?.message });
  }
});

// 14. AI Assistant Endpoints
const aiChatHits = new Map<string, { count: number; resetAt: number }>();
const aiChatRateLimit = (req: Request): boolean => {
  const key = String(req.ip || req.socket.remoteAddress || 'unknown').slice(0, 120);
  const now = Date.now();
  if (aiChatHits.size >= 10000) {
    for (const [k, v] of aiChatHits) if (v.resetAt <= now) aiChatHits.delete(k);
    if (aiChatHits.size >= 10000) {
      const oldest = [...aiChatHits.entries()].sort((a, b) => a[1].resetAt - b[1].resetAt);
      for (const [k] of oldest.slice(0, aiChatHits.size - 9999)) aiChatHits.delete(k);
    }
  }
  const cur = aiChatHits.get(key);
  if (!cur || cur.resetAt <= now) { aiChatHits.set(key, { count: 1, resetAt: now + 60_000 }); return true; }
  cur.count += 1;
  return cur.count <= 30;
};
app.post('/api/ai/chat', async (req: Request, res: Response) => {
  const fallback = 'درود! در فروشگاه پازل کالا در خدمت شما هستیم. اگر درباره مشخصات فنی کالاها، مقایسه یا رنج قیمت سؤالی دارید، بفرمایید.';
  try {
    const msg = String(req.body?.message ?? req.body?.query ?? '').trim().slice(0, 1500);
    if (!msg || !aiChatRateLimit(req) || assistantRateLimited(`chat:${req.ip}`)) return res.status(msg ? 429 : 200).json({ success: true, reply: fallback, summary: fallback });
    const r = await runShoppingAssistant(readJsonFile<any[]>(getFilePath('products.json'), []), msg);
    const rep = r.ok && r.summary ? r.summary : fallback;
    res.json({ success: true, reply: rep, summary: rep, products: (r.products || []).map((p: any) => publicProduct(p, false)).filter(Boolean) });
  } catch {
    res.json({ success: true, reply: fallback, summary: fallback, products: [] });
  }
});

// ثبت هوشمند کالا: فقط مدیر، با محدودیت تعداد درخواست (جلوگیری از مصرف بی‌رویه سهمیه هوش مصنوعی)
const smartHits = new Map<string, number[]>();
app.post('/api/ai/parse-product', requireAdminOrBridge, async (req: Request, res: Response) => {
  // Do not retain bearer credentials as Map keys; rate-limit by network origin.
  const key = String(req.ip || req.socket.remoteAddress || 'unknown').slice(0, 120);
  const now = Date.now();
  if (smartHits.size >= 10000) {
    for (const [k, times] of smartHits) if (!times.some((t) => now - t < 60000)) smartHits.delete(k);
    if (smartHits.size >= 10000) {
      const oldest = [...smartHits.entries()].sort((a, b) => (a[1][a[1].length - 1] || 0) - (b[1][b[1].length - 1] || 0));
      for (const [k] of oldest.slice(0, smartHits.size - 9999)) smartHits.delete(k);
    }
  }
  const hits = (smartHits.get(key) || []).filter((t) => now - t < 60000);
  if (hits.length >= 8) return res.status(429).json({ success: false, message: 'تعداد درخواست ثبت هوشمند زیاد است؛ یک دقیقه صبر کنید.' });
  smartHits.set(key, [...hits, now]);
  const query = String(req.body?.query || '').trim().slice(0, 200);
  if (!query) return res.status(400).json({ success: false, message: 'نام یا مدل کالا را وارد کنید.' });
  try {
    const out = await smartRegister(query);
    res.status(out.success ? 200 : 422).json(out);
  } catch (err: any) {
    console.error('[smartRegister]', err?.message || err);
    res.status(500).json({ success: false, message: 'خطای غیرمنتظره در ثبت هوشمند؛ دوباره تلاش کنید.' });
  }
});

// دستیار هوشمند خرید مشتری: فقط از کالاهای واقعی و موجود فروشگاه پیشنهاد می‌دهد.
app.post(['/api/ai/shopping-assistant', '/api/ai/shop-consult'], async (req: Request, res: Response) => {
  try {
    if (assistantRateLimited(`shop:${req.ip}`)) {
      return res.status(429).json({ success: false, message: 'تعداد درخواست‌ها زیاد است؛ کمی بعد دوباره تلاش کنید.' });
    }
    const { query, message, budget, priority, brand } = req.body || {};
    const q = String(query || message || '').trim().slice(0, 1500);
    const r = await runShoppingAssistant(readJsonFile<any[]>(getFilePath('products.json'), []), q, { budget, priority, brand });
    if (!r.ok) return res.status(503).json({ success: false, message: r.error || 'دستیار در دسترس نیست.' });
    res.json({ success: true, summary: r.summary, reply: r.summary, products: (r.products || []).map((p: any) => publicProduct(p, false)).filter(Boolean) });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'خطای غیرمنتظره در دستیار خرید.' });
  }
});

// 15. API Catch-All: Guarantee valid JSON for all /api/* requests
app.all('/api/*', (req: Request, res: Response) => {
  res.status(404).json({
    success: false,
    error: `API route not found: ${req.method} ${req.path}`,
    version: {
      overall: 1,
      products: 1,
      orders: 1,
      settings: 1,
      coupons: 1,
      users: 1,
    },
    data: {},
    suppliers: [],
    products: [],
    orders: [],
    users: [],
    settings: {},
    coupons: [],
    tickets: [],
  });
});

// --------------------------------------------------------------------------
// Start Server with Vite Middleware
// --------------------------------------------------------------------------

async function startServer() {
  // Serve public static assets
  app.use(express.static(path.join(__dirname, 'public'), { index: false, maxAge: '1h' }));

  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    // Mount Vite dev server in middleware mode
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // In production, serve dist folder or fallback to index.html
    const distPath = path.join(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (req: Request, res: Response) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    } else {
      // The repository root index.html points at /src/main.tsx, which browsers
      // cannot execute directly in production. Fail clearly instead of serving
      // a broken storefront when the Vite build output is missing.
      app.get('*', (req: Request, res: Response) => {
        res.status(503).type('text/plain').send('Puzzle Kala frontend is not built. Run `npm run build` and deploy the generated dist/ directory.');
      });
    }
  }

  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`[PuzzleKala] Dev server running at http://localhost:${PORT}`);
    // Start 30-second multi-supplier synchronization loop
    try {
      // چرخه ۵ دقیقه‌ای: همگام‌سازی تأمین‌کنندگان ← بروزرسانی قیمت سایت ← پایش و هشدار
      startAgents();
      console.log(`[PuzzleKala] Supplier sync + agents cycle initialized.`);
    } catch (err) {
      console.error('[PuzzleKala] Failed to initialize supplier loop:', err);
    }
  });

  const shutdown = () => {
    console.log('[PuzzleKala] Shutting down server gracefully...');
    server.close(() => {
      console.log('[PuzzleKala] Closed.');
      process.exit(0);
    });
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

startServer().catch((err) => {
  console.error('[PuzzleKala] Failed to start server:', err);
  process.exit(1);
});
