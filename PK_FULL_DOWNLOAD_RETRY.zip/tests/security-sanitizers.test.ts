import test from 'node:test';
import assert from 'node:assert/strict';
import { scrubSensitiveFields, isSensitiveKey } from '../src/securitySanitizers.js';

test('scrubs secrets recursively regardless of common key naming styles', () => {
  const input = {
    title: 'ok',
    api_key: 'a',
    webhookSecret: 'b',
    nested: { supplierCredentials: { password: 'c' }, safe: true },
    array: [{ access_token: 'd', name: 'ok' }],
  };
  assert.deepEqual(scrubSensitiveFields(input), {
    title: 'ok', nested: { safe: true }, array: [{ name: 'ok' }],
  });
});

test('recognizes secret keys with case and separator variants', () => {
  for (const key of ['API_KEY', 'apiKey', 'supplier-credentials', 'private_key', 'refreshToken', 'passwordHash']) {
    assert.equal(isSensitiveKey(key), true, key);
  }
});


test('fails closed on deeply nested objects instead of returning unsanitized data', () => {
  let input: any = { password: 'top-secret' };
  for (let i = 0; i < 15; i++) input = { nested: input };
  const output: any = scrubSensitiveFields(input);
  let cursor = output;
  for (let i = 0; i < 13; i++) cursor = cursor?.nested;
  assert.equal(cursor, null);
  assert.equal(JSON.stringify(output).includes('top-secret'), false);
});

test('scrubs camelCase and prefixed secret names from settings and nested objects', () => {
  const input = {
    adminPassword: 'a',
    supplierPassword: 'b',
    googleApiKey: 'c',
    sessionTokenHash: 'd',
    publicLabel: 'safe',
    nested: { ADMIN_PASSWORD: 'e', accessToken: 'f', supplier_api_key: 'g', secretaryName: 'safe-name' },
  };
  assert.deepEqual(scrubSensitiveFields(input), {
    publicLabel: 'safe', nested: { secretaryName: 'safe-name' },
  });
});
