import test from 'node:test';
import assert from 'node:assert/strict';
import { canTransitionReturnStatus } from '../src/returnWorkflow.js';

test('درخواست مرجوعی فقط از مسیرهای مجاز عبور می‌کند', () => {
  assert.equal(canTransitionReturnStatus('pending', 'approved'), true);
  assert.equal(canTransitionReturnStatus('pending', 'rejected'), true);
  assert.equal(canTransitionReturnStatus('approved', 'received'), true);
  assert.equal(canTransitionReturnStatus('received', 'refund_pending'), true);
  assert.equal(canTransitionReturnStatus('refund_pending', 'closed'), true);
  assert.equal(canTransitionReturnStatus('pending', 'closed'), false);
  assert.equal(canTransitionReturnStatus('rejected', 'approved'), false);
  assert.equal(canTransitionReturnStatus('closed', 'received'), false);
});

test('تکرار وضعیت فعلی بدون تغییر مجاز است', () => {
  assert.equal(canTransitionReturnStatus('pending', 'pending'), true);
  assert.equal(canTransitionReturnStatus('closed', 'closed'), true);
});


test('حالت‌های ناشناخته و برگشت از وضعیت نهایی رد می‌شوند', () => {
  assert.equal(canTransitionReturnStatus('unknown', 'approved'), false);
  assert.equal(canTransitionReturnStatus('pending', 'received'), false);
  assert.equal(canTransitionReturnStatus('received', 'approved'), false);
  assert.equal(canTransitionReturnStatus('refund_pending', 'approved'), false);
  assert.equal(canTransitionReturnStatus('rejected', 'closed'), false);
});
