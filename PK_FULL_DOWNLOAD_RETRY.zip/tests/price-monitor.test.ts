// تست پایش رنگ‌ها با هر دو قالب داده؛ بدون اینترنت و بدون دسترسی به دادهٔ واقعی فروشگاه.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

process.env.PUZZLEKALA_DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'pk-price-monitor-'));
const { extractColorSnapshots } = await import('../src/agents/priceMonitor.js');

test('رنگ‌های قالب variants[].options با شناسهٔ ثابت، قیمت و موجودی خوانده می‌شوند', () => {
  const colors = extractColorSnapshots({
    price: 12_000_000, inStock: true, stock: 5,
    variants: [{ type: 'color', options: [
      { id: 'color-blue-17', name: 'آبی یخی', price: 12_400_000, inStock: true },
      { id: 'color-black-18', name: 'مشکی', priceDelta: 0, inStock: false },
    ] }],
  });
  assert.deepEqual(colors['color-blue-17'], { name: 'آبی یخی', inStock: true, price: 12_400_000 });
  assert.deepEqual(colors['color-black-18'], { name: 'مشکی', inStock: false, price: 12_000_000 });
});

test('قالب قدیمی colors همچنان پشتیبانی می‌شود و شناسهٔ رنگ حفظ می‌شود', () => {
  const colors = extractColorSnapshots({ price: 9_000_000, inStock: true, colors: [
    { id: 'old-red-id', name: 'قرمز', price: 9_100_000, inStock: true },
  ] });
  assert.deepEqual(colors['old-red-id'], { name: 'قرمز', inStock: true, price: 9_100_000 });
});

test('اگر موجودی والد کالا صفر/ناموجود باشد، گزینهٔ رنگ موجود تلقی نمی‌شود', () => {
  const colors = extractColorSnapshots({ price: 5_000_000, stock: 0, inStock: false, variants: [
    { options: [{ id: 'green', name: 'سبز', inStock: true }] },
  ] });
  assert.equal(colors.green.inStock, false);
});

test('اگر شناسهٔ رنگ وجود نداشته باشد، نام رنگ به‌عنوان کلید پایدار جایگزین می‌شود', () => {
  const colors = extractColorSnapshots({ price: 1_000_000, variants: [
    { options: [{ name: 'طلایی', inStock: true }] },
  ] });
  assert.deepEqual(colors['طلایی'], { name: 'طلایی', inStock: true, price: 1_000_000 });
});
