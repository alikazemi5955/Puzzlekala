import test from 'node:test';
import assert from 'node:assert/strict';
import { isSafeUrl } from '../src/smart/images.js';

test('image/source URL validation accepts public HTTPS hosts only', () => {
  assert.equal(isSafeUrl('https://example.com/product.png'), true);
  assert.equal(isSafeUrl('http://example.com/product.png'), false);
  assert.equal(isSafeUrl('javascript:alert(1)'), false);
  assert.equal(isSafeUrl('https://user:pass@example.com/a.png'), false);
});

test('image/source URL validation rejects local, private, and special-use IP destinations', () => {
  for (const url of [
    'https://localhost/a.png',
    'https://a.localhost/a.png',
    'https://host.local/a.png',
    'https://host.internal/a.png',
    'https://127.0.0.1/a.png',
    'https://10.0.0.1/a.png',
    'https://172.16.0.1/a.png',
    'https://192.168.1.1/a.png',
    'https://169.254.169.254/latest/meta-data',
    'https://[::1]/a.png',
  ]) assert.equal(isSafeUrl(url), false, url);
});
