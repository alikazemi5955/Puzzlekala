// تست ثبت هوشمند چندمنبعی با منابع و عکس‌های جعلی (بدون اینترنت)
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'fs';
import os from 'os';
import path from 'path';

process.env.PUZZLEKALA_DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'pk-smart-'));
const { smartRegister, detectEvidenceConflicts } = await import('../src/smart/index.js');
const { evidenceFromHtml } = await import('../src/smart/sources.js');
const { parseQuery } = await import('../src/smart/queryParser.js');

const ev = (source: string, title: string, extra: any = {}) => ({ source, sourceLabel: source, title, images: [], colors: [], specs: [], ...extra });
const src = (id: string, list: any[]) => ({ id, label: id, async find() { return list; } });
const images = { sharp: null, fetchBuffer: async () => null } as any;
const specs = Array.from({ length: 8 }, (_, i) => ({ label: `مشخصه ${i}`, value: `مقدار ${i}` }));
const dk = (title: string) => ev('digikala', title, { colors: [{ name: 'آبی یخی', colorCode: '#a5c8e4' }, { name: 'سرمه‌ای' }], specs, description: 'توضیح فارسی کامل و واقعی درباره‌ی این گوشی موبایل که طول کافی دارد تا پذیرفته شود.' });

test('ورودی A57 12/256: فقط نسخه‌ی درست پذیرفته می‌شود و رم/حافظه پیش‌فرض نمی‌شود', async () => {
  const r: any = await smartRegister('سامسونگ A57 12/256', { images, sources: [src('digikala', [
    dk('گوشی موبایل سامسونگ مدل Galaxy A57 5G دو سیم کارت ظرفیت 256 گیگابایت و رم 12 گیگابایت'),
    dk('گوشی موبایل سامسونگ مدل Galaxy A57 5G دو سیم کارت ظرفیت 256 گیگابایت و رم 8 گیگابایت'),
    dk('گوشی موبایل سامسونگ مدل Galaxy A56 5G ظرفیت 256 گیگابایت و رم 12 گیگابایت'),
    dk('گوشی موبایل سامسونگ مدل Galaxy A57 FE ظرفیت 256 گیگابایت و رم 12 گیگابایت'),
    dk('قاب گوشی سامسونگ Galaxy A57'),
  ])] });
  assert.equal(r.success, true);
  assert.equal(r.meta.sources.length, 1);
  assert.match(r.product.persianName, /A57/);
  assert.match(r.product.persianName, /256 گیگابایت/);
  assert.match(r.product.persianName, /رم 12 گیگابایت/);
  assert.equal(r.meta.rejected.length, 4);
});


test('اگر مدیر رم/حافظه دقیق داده، شاهدی که این مشخصات را ندارد رد می‌شود', async () => {
  const r: any = await smartRegister('سامسونگ A57 12/256', { images, sources: [src('url', [
    ev('url', 'گوشی سامسونگ Galaxy A57 5G', { colors: [{ name: 'آبی' }], specs }),
  ])] });
  assert.equal(r.success, false);
  assert.ok(r.diagnostics.rejected[0].reasons.some((x: string) => /رم.*مشخص نیست|حافظه.*مشخص نیست/.test(x)));
});

test('رم/حافظه صریح جدول مشخصات صفحه محصول برای تطبیق قابل استفاده است', async () => {
  const r: any = await smartRegister('سامسونگ A57 12/256', { images, sources: [src('url', [
    ev('url', 'گوشی سامسونگ Galaxy A57 5G', { specs: [
      { label: 'حافظه رم', value: '12 گیگابایت' },
      { label: 'حافظه داخلی', value: '256 گیگابایت' },
      ...specs,
    ] }),
  ])] });
  assert.equal(r.success, true);
  assert.equal(r.product.ram, '12 گیگابایت');
  assert.equal(r.product.storage, '256 گیگابایت');
});

test('فقط «A57» (بدون برند و رم): فرم پر می‌شود، رم/حافظه خالی می‌ماند و نسخه‌ها هشدار داده می‌شوند', async () => {
  const r: any = await smartRegister('A57', { images, sources: [src('digikala', [
    dk('گوشی موبایل سامسونگ مدل Galaxy A57 5G ظرفیت 256 گیگابایت و رم 12 گیگابایت'),
    dk('گوشی موبایل سامسونگ مدل Galaxy A57 5G ظرفیت 128 گیگابایت و رم 8 گیگابایت'),
  ])] });
  assert.equal(r.success, true);
  assert.equal(r.product.ram, undefined);
  assert.equal(r.product.storage, undefined);
  assert.doesNotMatch(r.product.persianName, /گیگابایت/);
  assert.ok(r.meta.warnings.some((w: string) => /چند نسخه/.test(w)));
  assert.equal(r.product.brand, 'سامسونگ');
});

test('بدون رم/حافظه ولی فقط یک نسخه در منابع: همان با هشدار ثبت می‌شود', async () => {
  const r: any = await smartRegister('سامسونگ A57', { images, sources: [src('digikala', [dk('گوشی موبایل سامسونگ مدل Galaxy A57 5G ظرفیت 256 گیگابایت و رم 12 گیگابایت')])] });
  assert.equal(r.success, true);
  assert.ok(r.meta.warnings.some((w: string) => /رم\/حافظه در درخواست نبود/.test(w)));
});

test('بدون دیجی‌کالا هم کار می‌کند (فقط منبع دیگر)', async () => {
  const r: any = await smartRegister('iPhone 16 Pro 256', { images, sources: [
    src('digikala', []),
    src('url', [ev('url', 'Apple iPhone 16 Pro 256GB', { colors: [{ name: 'Natural Titanium' }], specs, description: 'x'.repeat(80) })]),
  ] });
  assert.equal(r.success, true);
  assert.match(r.product.persianName, /iPhone 16 Pro/);
});

test('iPhone 16 با Pro/Plus/Pro Max اشتباه گرفته نمی‌شود', async () => {
  const r: any = await smartRegister('iPhone 16 128', { images, sources: [src('x', [ev('x', 'Apple iPhone 16 Pro 128GB'), ev('x', 'Apple iPhone 16 Plus 128GB'), ev('x', 'Apple iPhone 16 Pro Max 128GB')])] });
  assert.equal(r.success, false);
  assert.equal(r.diagnostics.rejected.length, 3);
});

test('منبع خراب بقیه را نمی‌شکند و اگر هیچ شاهدی نباشد چیزی ساخته نمی‌شود', async () => {
  const bad = { id: 'bad', label: 'bad', async find() { throw new Error('boom'); } };
  const r: any = await smartRegister('سامسونگ A57 12/256', { images, sources: [bad as any] });
  assert.equal(r.success, false);
  assert.match(r.diagnostics.sources.bad, /خطا/);
});

test('ورودی نامفهوم رد می‌شود', async () => {
  const r: any = await smartRegister('یه چیزی', { images, sources: [] });
  assert.equal(r.success, false);
});

test('استخراج عمومی از صفحه‌ی HTML هر فروشگاه (JSON-LD و جدول مشخصات)', () => {
  const html = `<html><head><title>x</title><script type="application/ld+json">{"@type":"Product","name":"Samsung Galaxy A57 5G 12GB 256GB","image":["/a.jpg"],"description":"d","color":"Blue, Black","mpn":"SM-A576B"}</script></head><body><table><tr><th>صفحه نمایش</th><td>6.7 اینچ</td></tr></table></body></html>`;
  const e: any = evidenceFromHtml(html, 'https://shop.example.com/p/1');
  assert.equal(e.title, 'Samsung Galaxy A57 5G 12GB 256GB');
  assert.equal(e.images[0], 'https://shop.example.com/a.jpg');
  assert.equal(e.colors.length, 2);
  assert.equal(e.specs[0].value, '6.7 اینچ');
  assert.equal(e.modelCode, 'SM-A576B');
});

test('تحلیل ورودی فارسی', () => {
  const q = parseQuery('گوشی ایفون ۱۶ پرو مکس ۲۵۶');
  assert.deepEqual([q.identity.brand, q.identity.model, q.storage], ['apple', 'iphone 16', 256]);
});


test('اختلاف مشخصات میان منابع پنهان نمی‌شود و برای بررسی مدیر ثبت می‌شود', async () => {
  const a = ev('url', 'Samsung Galaxy A57 12GB 256GB', { specs: [{ label: 'ظرفیت باتری', value: '5000 mAh' }] });
  const b = ev('digikala', 'Samsung Galaxy A57 12GB 256GB', { specs: [{ label: 'ظرفیت باتری', value: '4500 mAh' }] });
  const conflicts = detectEvidenceConflicts([
    { ev: a, identity: parseQuery('Samsung A57 12/256').identity },
    { ev: b, identity: parseQuery('Samsung A57 12/256').identity },
  ] as any);
  assert.equal(conflicts.length, 1);
  assert.equal(conflicts[0].values.length, 2);
  assert.match(conflicts[0].field, /battery|باتری/i);
});

test('اختلاف منبع در متادیتای ثبت هوشمند همراه با نام منابع خروجی داده می‌شود', async () => {
  const r: any = await smartRegister('سامسونگ A57 12/256', { images, sources: [src('url', [
    ev('url', 'Samsung Galaxy A57 12GB RAM 256GB', { specs: [{ label: 'ظرفیت باتری', value: '5000 mAh' }, ...specs] }),
    ev('url', 'Samsung Galaxy A57 12GB RAM 256GB', { specs: [{ label: 'ظرفیت باتری', value: '4500 mAh' }, ...specs] }),
  ])] });
  assert.equal(r.success, true);
  assert.ok(r.meta.needsReview);
  assert.ok(r.meta.evidenceConflicts.length >= 1);
});


test('وقتی منبع فقط هویت و چند مشخصه دارد، توضیحات و بررسی اولیه ساخته می‌شود بدون ادعای نظر مشتری', async () => {
  const r: any = await smartRegister('سامسونگ A57 12/256', { images, sources: [src('url', [
    ev('url', 'Samsung Galaxy A57 5G 12GB 256GB', { specs: [
      { label: 'حافظه رم', value: '12 گیگابایت' },
      { label: 'حافظه داخلی', value: '256 گیگابایت' },
      { label: 'ظرفیت باتری', value: '5000 میلی‌آمپر ساعت' },
    ] }),
  ])] });
  assert.equal(r.success, true);
  assert.ok(r.product.description.length > 40);
  assert.ok(r.product.fullDescription.includes('مشخصات تأییدشده'));
  assert.ok(r.product.review.includes('نظر خریدار'));
  assert.ok(r.product.technicalSpecs.length >= 3);
  assert.equal(r.product.price, undefined);
  assert.equal(r.product.stock, undefined);
});
