import test from 'node:test';
import assert from 'node:assert/strict';
import { runShoppingAssistant } from '../src/assistant.js';

test('shopping assistant does not recommend a product when every color variant is unavailable', async () => {
  const product = {
    id: 'prod-test', name: 'Samsung Galaxy A57 256GB', persianName: 'گوشی سامسونگ گلکسی A57',
    price: 20_000_000, active: true, inStock: true,
    variants: [{ type: 'color', title: 'رنگ', options: [{ name: 'Navy', inStock: false, stock: 0 }] }],
  };
  const result = await runShoppingAssistant([product], 'سامسونگ گلکسی A57');
  assert.equal(result.ok, true);
  assert.deepEqual(result.products, []);
});

test('shopping assistant includes available color variants in the recommendation data', async () => {
  const product = {
    id: 'prod-test', name: 'Samsung Galaxy A57 256GB', persianName: 'گوشی سامسونگ گلکسی A57',
    price: 20_000_000, active: true, inStock: true,
    variants: [{ type: 'color', title: 'رنگ', options: [{ name: 'Navy', inStock: true, stock: 2, price: 20_000_000 }] }],
  };
  const result = await runShoppingAssistant([product], 'سامسونگ گلکسی A57');
  assert.equal(result.ok, true);
  assert.equal(result.products?.length, 1);
});

test('public product projection excludes internal supplier pricing metadata', async () => {
  const { publicProductView } = await import('../src/productPublicView.js');
  const internalProduct = {
    id: 'prod-test', name: 'Phone', persianName: 'گوشی', price: 100, active: true, inStock: true,
    sourcePrice: 70, syncedPrice: 75, approvedSourcePrice: 80,
    referenceSupplierId: 'supplier-secret-id', referenceSupplierName: 'Internal Supplier',
    supplierName: 'Internal Supplier', supplierMatches: [{ supplierId: 'x' }], priceJumpHeldSource: { price: 1 },
  };
  const publicProjection = publicProductView(internalProduct, false);
  for (const key of ['sourcePrice', 'syncedPrice', 'approvedSourcePrice', 'referenceSupplierId', 'referenceSupplierName', 'supplierName', 'supplierMatches', 'priceJumpHeldSource']) {
    assert.equal(key in publicProjection, false, key);
  }
  assert.equal(publicProjection.price, 100);
});
