// تست‌های خودکار قوانین تأمین‌کننده: اجرا با  npm test
// هر قانون مهم پازل کالا یک تست دارد؛ اگر کدی قانونی را بشکند، این تست‌ها قرمز می‌شوند.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'fs';
import os from 'os';
import path from 'path';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pk-test-'));
process.env.PUZZLEKALA_DATA_DIR = dir;
const E = await import('../src/supplierEngine.js');
const I = await import('../src/identity.js');

const sup = (id: string, enabled = true) => ({ id, name: id, enabled, baseUrl: 'https://example.com/', connectionType: 'api_feed', status: 'connected', lastSyncAt: null, lastSuccessAt: null, lastError: null, matchedCount: 0, ambiguousCount: 0, variantsCount: 0, inStockColorsCount: 0 }) as any;
const product = (id: string, name: string, persianName: string, colors: string[], price = 1000) => ({
  id, name, persianName, price, inStock: true,
  variants: [{ type: 'color', title: 'رنگ', options: colors.map((c, i) => ({ id: `${id}-c${i}`, name: c, value: c, inStock: true })) }],
});
const read = (f: string) => JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
async function run(products: any[], catalogs: Record<string, any[] | 'fail'>) {
  fs.writeFileSync(path.join(dir, 'products.json'), JSON.stringify(products));
  fs.writeFileSync(path.join(dir, 'settings.json'), JSON.stringify({ supplierMarkupPercent: 5 }));
  const ids = Object.keys(catalogs);
  E.saveSuppliersList([...ids.map((i) => sup(i)), sup('kasra', false), sup('hamrahtel', false), sup('ehadish', false)]);
  for (const id of ids) {
    const cat = catalogs[id];
    E.registerSupplierAdapter({ ...(E.UniversalSupplierAdapter as any), id, name: id, async fetchCatalog() { return cat === 'fail' ? { success: false, items: [], error: 'down' } : { success: true, items: cat }; } });
  }
  const r = await E.executeMultiSupplierSync();
  return { r, products: read('products.json') as any[], details: read('supplier_match_details.json') };
}
const opt = (p: any, name: string) => p.variants[0].options.find((o: any) => o.name === name);

const A57 = () => product('a57', 'Samsung Galaxy A57 5G 12GB 256GB', 'گوشی موبایل سامسونگ مدل Galaxy A57 5G ظرفیت 256 گیگابایت و رم 12 گیگابایت', ['آبی یخی', 'سرمه‌ای', 'یاسی']);

test('قیمت هر رنگ = بالاترین قیمت تأمین‌کنندگان × ۱٫۰۵', async () => {
  const { products } = await run([A57()], {
    s1: [{ id: '1', title: 'Samsung Galaxy A57 5G 12GB RAM 256GB', price: 20000000, variants: [{ name: 'Icy Blue', price: 20000000, stock: 3 }, { name: 'Navy', price: 20000000, stock: 0 }, { name: 'Lilac', price: 20400000, stock: 2 }] }],
    s2: [{ id: 'a', title: 'گوشی موبایل سامسونگ مدل Galaxy A57 5G ظرفیت 256 گیگابایت و رم 12 گیگابایت', price: 20500000, variants: [{ name: 'آبی یخی', price: 20500000, stock: 5 }, { name: 'سرمه ای', price: 20100000, stock: 1 }] }],
  });
  const p = products[0];
  assert.equal(opt(p, 'آبی یخی').price, Math.round(20500000 * 1.05));
  assert.equal(opt(p, 'سرمه‌ای').price, Math.round(20100000 * 1.05)); // s1 ناموجود، s2 موجود
  assert.equal(opt(p, 'یاسی').price, Math.round(20400000 * 1.05));
  assert.ok(p.variants[0].options.every((o: any) => o.inStock));
});

test('رم/حافظه/نسخه‌ی اشتباه هرگز تطبیق نمی‌خورد', async () => {
  const { products, details } = await run([A57()], { s1: [
    { id: '1', title: 'Samsung Galaxy A57 5G 8GB RAM 256GB', price: 17000000, stock: 5 },
    { id: '2', title: 'Samsung Galaxy A57 5G 12GB RAM 128GB', price: 16000000, stock: 5 },
    { id: '3', title: 'Samsung Galaxy A56 5G 12GB RAM 256GB', price: 15000000, stock: 5 },
    { id: '4', title: 'Samsung Galaxy A57 FE 5G 12GB RAM 256GB', price: 22000000, stock: 5 },
    { id: '5', title: 'Samsung Galaxy A57 Ultra 5G 12GB RAM 256GB', price: 25000000, stock: 5 },
  ] });
  assert.equal(products[0].price, 1000);
  assert.equal(details.s1.matched.length, 0);
});

test('S24 با S24 Ultra و S24 FE اشتباه گرفته نمی‌شود', async () => {
  const s24 = product('s24', 'Samsung Galaxy S24 8GB 256GB', 'گوشی موبایل سامسونگ مدل Galaxy S24 ظرفیت 256 گیگابایت و رم 8 گیگابایت', ['مشکی']);
  const { products } = await run([s24], { s1: [
    { id: '1', title: 'Samsung Galaxy S24 Ultra 12GB 256GB', price: 50000000, stock: 5 },
    { id: '2', title: 'Samsung Galaxy S24 FE 8GB 256GB', price: 30000000, stock: 5 },
  ] });
  assert.equal(products[0].price, 1000);
});

test('اگر تأمین‌کننده رم را ننوشته باشد، قیمت اعمال نمی‌شود و به «نیازمند بررسی» می‌رود', async () => {
  const { products, details } = await run([A57()], { s1: [{ id: '1', title: 'Samsung Galaxy A57 256GB', price: 17000000, stock: 5 }] });
  assert.equal(products[0].price, 1000);
  assert.equal(details.s1.ambiguous.length, 1);
  assert.match(details.s1.ambiguous[0].reason, /رم/);
});

test('تأمین‌کننده‌ای که شبکه را ننوشته ولی ردیف 4G هم دارد، مبهم است؛ اگر ردیف دیگری نداشته باشد قبول می‌شود', async () => {
  const note = product('n14', 'Xiaomi Redmi Note 14 5G 8GB 256GB', 'گوشی موبایل شیائومی مدل Redmi Note 14 5G ظرفیت 256 گیگابایت و رم 8 گیگابایت', ['مشکی']);
  const a = await run([note], { s1: [
    { id: '1', title: 'Xiaomi Redmi Note 14 8GB 256GB', price: 10000000, stock: 5 },
    { id: '2', title: 'Xiaomi Redmi Note 14 4G 8GB 256GB', price: 8000000, stock: 5 },
  ] });
  assert.equal(a.products[0].price, 1000);
  const b = await run([note], { s1: [{ id: '1', title: 'Xiaomi Redmi Note 14 8GB 256GB', price: 10000000, stock: 5 }] });
  assert.equal(b.products[0].price, Math.round(10000000 * 1.05));
});

test('گوشی‌های جدید تأمین‌کننده هرگز ساخته نمی‌شوند؛ فقط کالاهای غیرگوشی', async () => {
  const items = [
    { id: '1', title: 'Samsung Galaxy A57 5G 12GB RAM 256GB', price: 20000000, stock: 5 },
    { id: '9', title: 'Samsung Galaxy S99 Ultra 12GB RAM 256GB', price: 90000000, stock: 5 },
    { id: '10', title: 'Sony PlayStation 5 Slim Disc 1TB', price: 30000000, stock: 4 },
    { id: '11', title: 'کابل شارژ تایپ سی انکر 1 متر', price: 300000, stock: 40 },
    { id: '12', title: 'کابل ناموجود', price: 300000, stock: 0 },
  ];
  const r1 = await run([A57()], { s1: items });
  assert.equal(r1.products.length, 3); // A57 + PS5 + کابل؛ نه S99 و نه کالای ناموجود
  assert.ok(!r1.products.some((p: any) => /S99/.test(p.name)));
  const ps = r1.products.find((p: any) => /PlayStation/.test(p.name));
  assert.equal(ps.price, Math.round(30000000 * 1.05));
  assert.equal(ps.autoCreated, true);
  assert.ok(String(ps.id).startsWith('prod-auto-'));
  // دور دوم: کالاها تکراری ساخته نمی‌شوند و قیمت پایدار می‌ماند
  fs.writeFileSync(path.join(dir, 'products.json'), JSON.stringify(r1.products));
  const r2 = await (async () => { const E2 = E; const res = await E2.executeMultiSupplierSync(); return { r: res, products: read('products.json') as any[] }; })();
  assert.equal(r2.products.length, 3);
  assert.equal(r2.products.find((p: any) => /PlayStation/.test(p.name)).price, Math.round(30000000 * 1.05));
});

test('کالای غیرگوشی که مدیر حذف کرده (در فهرست نادیده‌ها) دوباره ساخته نمی‌شود', async () => {
  const items = [{ id: '10', title: 'Sony PlayStation 5 Slim Disc 1TB', price: 30000000, stock: 4 }];
  const r1 = await run([], { s1: items });
  assert.equal(r1.products.length, 1);
  fs.writeFileSync(path.join(dir, E.IGNORED_FILE), JSON.stringify([r1.products[0].autoKey]));
  const r2 = await run([], { s1: items });
  assert.equal(r2.products.length, 0);
  fs.rmSync(path.join(dir, E.IGNORED_FILE));
});

test('اگر کالای خودکار از تأمین‌کننده ناموجود شود، در سایت ناموجود می‌شود', async () => {
  const r1 = await run([], { s1: [{ id: '10', title: 'Sony PlayStation 5 Slim Disc 1TB', price: 30000000, stock: 4 }] });
  fs.writeFileSync(path.join(dir, 'products.json'), JSON.stringify(r1.products));
  const r2 = await (async () => { E.registerSupplierAdapter({ ...(E.UniversalSupplierAdapter as any), id: 's1', name: 's1', async fetchCatalog() { return { success: true, items: [{ id: '10', title: 'Sony PlayStation 5 Slim Disc 1TB', price: 30000000, stock: 0 }, { id: '77', title: 'x', price: 1, stock: 1 }] }; } }); await E.executeMultiSupplierSync(); return read('products.json') as any[]; })();
  assert.equal(r2[0].inStock, false);
});

test('اختلاف ۱۰ برابری (اشتباه ریال/تومان) اعمال نمی‌شود', async () => {
  const p = A57();
  p.price = 21000000;
  for (const o of p.variants[0].options as any[]) { o.price = 21000000; }
  const { products, details } = await run([p], { s1: [{ id: '1', title: 'Samsung Galaxy A57 5G 12GB RAM 256GB', price: 200000000, stock: 5 }] });
  assert.equal(products[0].variants[0].options[0].price, 21000000);
  assert.ok(details.s1.ambiguous.some((a: any) => a.kind === 'unit_mismatch'));
});

test('جهش قیمت عادی (حتی بیش از ۳۰٪) مانع اعمال قیمت نمی‌شود', async () => {
  const p = A57();
  for (const o of p.variants[0].options as any[]) { o.price = 10000000; }
  const { products } = await run([p], { s1: [{ id: '1', title: 'Samsung Galaxy A57 5G 12GB RAM 256GB', price: 20000000, variants: [{ name: 'Icy Blue', price: 20000000, stock: 3 }] }] });
  assert.equal(opt(products[0], 'آبی یخی').price, 21000000);
});

test('رنگ نامشخص تأمین‌کننده باعث ناموجود شدن رنگ‌های ما نمی‌شود', async () => {
  const { products } = await run([A57()], { s1: [{ id: '1', title: 'Samsung Galaxy A57 5G 12GB RAM 256GB', price: 20000000, variants: [{ name: 'Icy Blue', price: 20000000, stock: 3 }, { name: 'Xyzcolor', price: 20000000, stock: 3 }] }] });
  const p = products[0];
  assert.equal(opt(p, 'آبی یخی').inStock, true);
  assert.equal(opt(p, 'سرمه‌ای').inStock, true); // هنوز مطمئن نیستیم ناموجود است
  assert.equal(opt(p, 'یاسی').inStock, true);
});

test('وقتی همه‌ی رنگ‌های تأمین‌کننده تطبیق خورد، رنگی که او ندارد ناموجود می‌شود', async () => {
  const { products } = await run([A57()], { s1: [{ id: '1', title: 'Samsung Galaxy A57 5G 12GB RAM 256GB', price: 20000000, variants: [{ name: 'Icy Blue', price: 20000000, stock: 3 }, { name: 'Navy', price: 20000000, stock: 3 }] }] });
  const p = products[0];
  assert.equal(opt(p, 'یاسی').inStock, false);
  assert.equal(opt(p, 'آبی یخی').inStock, true);
});

test('اگر یکی از تأمین‌کننده‌ها خطا بدهد، هیچ رنگی ناموجود نمی‌شود', async () => {
  const { products } = await run([A57()], { s1: [{ id: '1', title: 'Samsung Galaxy A57 5G 12GB RAM 256GB', price: 20000000, variants: [{ name: 'Icy Blue', price: 20000000, stock: 3 }] }], s2: 'fail' });
  assert.ok(products[0].variants[0].options.every((o: any) => o.inStock));
});

test('ردیف‌های جدای هر رنگ در تأمین‌کننده ادغام می‌شوند', async () => {
  const { products } = await run([A57()], { s1: [
    { id: '1', title: 'Samsung Galaxy A57 5G 12GB RAM 256GB Icy Blue', price: 20000000, stock: 3 },
    { id: '2', title: 'Samsung Galaxy A57 5G 12GB RAM 256GB Navy', price: 20100000, stock: 3 },
    { id: '3', title: 'Samsung Galaxy A57 5G 12GB RAM 256GB Lilac', price: 20200000, stock: 3 },
  ] });
  assert.equal(opt(products[0], 'آبی یخی').price, Math.round(20000000 * 1.05));
  assert.equal(opt(products[0], 'سرمه‌ای').price, Math.round(20100000 * 1.05));
  assert.equal(opt(products[0], 'یاسی').price, Math.round(20200000 * 1.05));
});

test('تأیید دستی مدیر قبول می‌شود مگر مشخصات صریحاً متناقض باشد', async () => {
  const p: any = A57();
  p.supplierMatches = { s1: { supplierProductId: '7', confirmedBy: 'admin' } };
  const ok = await run([p], { s1: [{ id: '7', title: 'A57 256GB', price: 20000000, stock: 5 }] });
  assert.equal(ok.products[0].variants[0].options.length, 3);
  const bad: any = A57();
  bad.supplierMatches = { s1: { supplierProductId: '7', confirmedBy: 'admin' } };
  const r = await run([bad], { s1: [{ id: '7', title: 'Samsung Galaxy A57 5G 8GB RAM 256GB', price: 17000000, stock: 5 }] });
  assert.equal(r.products[0].price, 1000);
});

// ------------------------------------------------------------------ هویت کالا
test('استخراج هویت: عنوان‌های فارسی و انگلیسی', () => {
  const x = I.identityFromText('گوشی موبایل سامسونگ مدل Galaxy A57 5G دو سیم کارت ظرفیت 256 گیگابایت و رم 8 گیگابایت');
  assert.deepEqual([x.brand, x.model, x.ram, x.storage, x.network, x.sim], ['samsung', 'a57', 8, 256, '5G', 'dual']);
  const y = I.identityFromText('Apple iPhone 16 Pro Max 256GB CH/A');
  assert.deepEqual([y.brand, y.model, y.modifiers.join('+'), y.storage, y.part], ['apple', 'iphone 16', 'max+pro', 256, 'CH/A']);
  const z = I.identityFromText('poco x7 pro 12 512', { loose: true });
  assert.deepEqual([z.model, z.modifiers.join('+'), z.ram, z.storage], ['poco x7', 'pro', 12, 512]);
});

test('کلمات توصیفی مثل Aluminum/Frame/processor/series مدل یا کشور را عوض نمی‌کنند', () => {
  const x = I.identityFromText('Samsung Galaxy A57 5G 256GB Dual SIM Exynos 1580 Aluminum Frame IP68 series processor feature');
  assert.equal(x.model, 'a57');
  assert.deepEqual(x.modifiers, []);
  assert.equal(x.region, null);
});

test('رنگ‌ها: برابر، زیرمجموعه و ابهام', () => {
  const m = I.mapColors(['آبی یخی کریستالی', 'سرمه‌ای اقیانوسی', 'آبی تیره'], ['Navy', 'آبی', 'آبی تیره', 'Black']);
  assert.equal(m.pairs.length, 3);
  assert.deepEqual(m.unmatchedSupplier, [3]);
  const amb = I.mapColors(['آبی روشن', 'آبی تیره'], ['آبی']);
  assert.equal(amb.pairs.length, 0);
  assert.equal(amb.ambiguousSupplier.length, 1);
});

test('پیش‌نمایش همگام‌سازی تغییر پیشنهادی می‌دهد اما هیچ فایل داده‌ای را تغییر نمی‌دهد', async () => {
  const p = A57();
  await run([p], { previewSupplier: [{ id: 'preview-1', title: 'Samsung Galaxy A57 5G 12GB RAM 256GB', price: 22000000, stock: 4 }] });
  const files = ['products.json', 'settings.json', 'suppliers.json', 'supplier_match_details.json', 'audit_logs.json', 'supplier_price_stock_history.json'];
  const before = new Map(files.map((f) => {
    const fp = path.join(dir, f);
    return [f, fs.existsSync(fp) ? fs.readFileSync(fp, 'utf8') : null];
  }));
  const preview = await E.executeMultiSupplierSync(undefined, { dryRun: true });
  assert.equal(preview.success, true);
  assert.equal(preview.dryRun, true);
  assert.ok(Array.isArray(preview.plannedChanges));
  for (const f of files) {
    const fp = path.join(dir, f);
    const after = fs.existsSync(fp) ? fs.readFileSync(fp, 'utf8') : null;
    assert.equal(after, before.get(f), `${f} نباید در حالت پیش‌نمایش تغییر کند`);
  }
});
