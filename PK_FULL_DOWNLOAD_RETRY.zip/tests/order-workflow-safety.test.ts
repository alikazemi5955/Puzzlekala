import test from 'node:test';
import assert from 'node:assert/strict';
import { canTransitionOrderStatus, normalizeOrderStatus, isValidOrderAmount, isConsistentOrderTotal } from '../src/orderWorkflowSafety.js';
import { validateOrderItemSnapshot } from '../src/orderSafety.js';

test('order status normalization handles supported Persian and legacy values', () => {
  assert.equal(normalizeOrderStatus('در حال بررسی'), 'review');
  assert.equal(normalizeOrderStatus('تاییدشده'), 'approved');
  assert.equal(normalizeOrderStatus('ارسال‌شده'), 'shipped');
  assert.equal(normalizeOrderStatus('لغو شده'), 'cancelled');
});

test('order workflow rejects backwards or skipped transitions', () => {
  assert.equal(canTransitionOrderStatus('در حال بررسی', 'تأییدشده'), true);
  assert.equal(canTransitionOrderStatus('تأییدشده', 'در حال آماده‌سازی'), true);
  assert.equal(canTransitionOrderStatus('ارسال‌شده', 'تحویل‌شده'), true);
  assert.equal(canTransitionOrderStatus('ارسال‌شده', 'در حال بررسی'), false);
  assert.equal(canTransitionOrderStatus('تحویل‌شده', 'لغو‌شده'), false);
  assert.equal(canTransitionOrderStatus('لغو‌شده', 'ارسال‌شده'), false);
});

test('order monetary snapshots reject invalid and inconsistent amounts', () => {
  for (const n of [-1, Infinity, NaN, 1e16, 'bad']) assert.equal(isValidOrderAmount(n), false);
  assert.equal(isValidOrderAmount(100), true);
  assert.equal(isConsistentOrderTotal(1000, 100, 50, 950), true);
  assert.equal(isConsistentOrderTotal(1000, 1001, 50, 0), false);
  assert.equal(isConsistentOrderTotal(1000, 100, 50, 200), false);
});


test('manual/sync order item snapshots must match subtotal and use valid quantities/prices', () => {
  assert.deepEqual(validateOrderItemSnapshot([{ productId: 'p1', quantity: 2, unitPrice: 500 }], 1000), { valid: true, subtotal: 1000 });
  assert.equal(validateOrderItemSnapshot([{ productId: 'p1', quantity: 2, unitPrice: 500 }], 900).valid, false);
  assert.equal(validateOrderItemSnapshot([{ productId: 'p1', quantity: 0, unitPrice: 500 }], 0).valid, false);
  assert.equal(validateOrderItemSnapshot([{ productId: 'p1', quantity: 1, unitPrice: -1 }], -1).valid, false);
  assert.equal(validateOrderItemSnapshot([], 0).valid, false);
});
