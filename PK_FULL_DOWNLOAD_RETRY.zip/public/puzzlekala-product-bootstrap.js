// نسخه‌ی قبلی این فایل ۳۱ کالای نمونه را در مرورگر هر بازدیدکننده می‌ریخت. از نسخه‌ی 1.9.0 کالاها فقط از سرور می‌آیند؛
// این کد یک‌بار کالاهای نمونه‌ی قدیمیِ ذخیره‌شده در مرورگر را پاک می‌کند.
(function(){try{var k='puzzlekala_products_cleared';if(localStorage.getItem(k)==='1.9.0')return;localStorage.removeItem('puzzlekala_products');localStorage.removeItem('puzzlekala_authoritative_products_version');localStorage.setItem(k,'1.9.0')}catch(e){}})();
